#pragma once

#include <limits>

namespace Kiss
{

    //
    //////////////////////////////////////////////////////////////////
    //
    // DEFAULT IMPLEMENTATION
    //
    //////////////////////////////////////////////////////////////////
    //

    /** @ingroup  Kiss_LinAlg_CWise_Group
        @brief CWise copy
    */
    template <typename DERIVED_DEST, typename DERIVED_SOURCE>
    auto cwise_copy(const CRTP_Base<DERIVED_DEST>& derived_dest, const CRTP_Base<DERIVED_SOURCE>& derived_source)
    {
        return map(
            [](auto& dest, const auto& source)
            {
                dest = source;
            },
            derived_dest.impl(), derived_source.impl());
    }

    /** @ingroup  Kiss_LinAlg_CWise_Group
        @brief CWise filling
    */
    template <typename DERIVED_DEST, typename SOURCE>
    auto cwise_filling(const CRTP_Base<DERIVED_DEST>& derived_dest, const SOURCE& source)
    {
        map(
            [&](auto& dest)
            {
                dest = source;
            },
            derived_dest.impl());
    }

    /** @ingroup  Kiss_LinAlg_CWise_Group
        @brief CWise filling with a linear sequence
    */
    template <typename DERIVED_DEST, typename SCALAR>
    auto cwise_linearSequence(const CRTP_Base<DERIVED_DEST>& derived_dest, SCALAR start, SCALAR stride = 1)
    {
        map(
            [&](auto& dest)
            {
                dest = start;
                start += stride;
            },
            derived_dest.impl());
    }

    /** @ingroup Kiss_LinAlg_CWise_Group
         @brief Returns max element
     */
    template <typename DERIVED_SOURCE>
    auto cwise_min(const CRTP_Base<DERIVED_SOURCE>& derived_source)
    {
        typedef typename DERIVED_SOURCE::ElementType ElementType;
        auto initial_value = std::numeric_limits<ElementType>::max();

        using std::min;

        map(
            [&initial_value](const auto& current)
            {
                if(initial_value > current)
                {
                    initial_value = min(initial_value, current);
                }
            },
            derived_source.impl());

        return initial_value;
    }

    /** @ingroup Kiss_LinAlg_CWise_Group
       @brief Returns max element
   */
    template <typename DERIVED_SOURCE>
    auto cwise_max(const CRTP_Base<DERIVED_SOURCE>& derived_source)
    {
        typedef typename DERIVED_SOURCE::ElementType ElementType;
        auto initial_value = std::numeric_limits<ElementType>::lowest();

        using std::max;

        map(
            [&initial_value](const auto& current)
            {
                if(initial_value < current)
                {
                    initial_value = max(initial_value, current);
                }
            },
            derived_source.impl());

        return initial_value;
    }

    /** @ingroup Kiss_LinAlg_CWise_Group
        @brief Accumulates elements
    */
    template <typename DERIVED_SOURCE>
    auto cwise_sum(const CRTP_Base<DERIVED_SOURCE>& derived_source)
    {
        typedef typename DERIVED_SOURCE::ElementType ElementType;
        ElementType initial_value{0};

        map(
            [&initial_value](const auto& current)
            {
                initial_value += current;
            },
            derived_source.impl());

        return initial_value;
    }
}
