#pragma once
#include <Kiss_LinAlg/Vector/denseVector_implementation.hpp>
#include <Kiss_LinAlg/Matrix/interface_crsMatrix.hpp>
#include <Kiss_LinAlg/Matrix/cxsMatrix_fwd.hpp>
#include <Kiss_LinAlg/Vector/sparseVector_implementation.hpp>

#include <Kiss_LinAlg/Tag/matrixShape.hpp>
#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>

namespace Kiss
{

    template <typename DATA_DENSEVECTOR, typename MATRIXSHAPE_TYPE>
    struct CRTP_TypeTraits<CrsMatrix_Implementation<DATA_DENSEVECTOR, MATRIXSHAPE_TYPE> >
    {
        using ElementType = typename DATA_DENSEVECTOR::ElementType;
        using MatrixShapeType = MATRIXSHAPE_TYPE;
        using MatrixUpLowType = typename MatrixShapeType::MatrixUpLowType;
    };

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Generic implementation of crs matrix
         @extends Interface_CrsMatrix
    */
    template <typename DATA_DENSEVECTOR, typename MATRIXSHAPE_TYPE>
    class CrsMatrix_Implementation final
#ifndef DOXYGEN_DOC
        : public Interface_CrsMatrix<CrsMatrix_Implementation<DATA_DENSEVECTOR, MATRIXSHAPE_TYPE> >
#endif
    {
        using SelfType = CrsMatrix_Implementation;
        using TraitsType = CRTP_TypeTraits<SelfType>;

        static_assert(MatrixShape_Well_Defined<typename TraitsType::MatrixShapeType>, "");

        //================

       public:
        using ElementType = typename TraitsType::ElementType;
        using MatrixUpLowType = typename TraitsType::MatrixUpLowType;

       public:
        /** Default constructor */
        CrsMatrix_Implementation() noexcept : I_size_(0),
                                              J_size_(0),
                                              I_begin_denseVector_(),
                                              J_index_denseVector_(),
                                              data_denseVector_()
        {
        }

        /** Move constructor */
        CrsMatrix_Implementation(const Size_t I_size, const Size_t J_size,
                                 CxS_Index_DenseVector_Const_Type&& I_begin_denseVector,
                                 CxS_Index_DenseVector_Const_Type&& J_index_denseVector,
                                 DATA_DENSEVECTOR&& data_denseVector)
            : I_size_(I_size)
            , J_size_(J_size)
            , I_begin_denseVector_(std::move(I_begin_denseVector))
            , J_index_denseVector_(std::move(J_index_denseVector))
            , data_denseVector_(std::move(data_denseVector))
        {
            assert(check_invariant());
        }

        /** Move constructor */
        CrsMatrix_Implementation(SelfType&& toMove) = default;

        auto nonZero_size() const noexcept { return data_denseVector_.size(); }

        auto I_size() const noexcept { return I_size_; }
        auto J_size() const noexcept { return J_size_; }

        auto& operator[](const Index_t nonZero_idx) const noexcept { return data_denseVector_[nonZero_idx]; };

        auto I_begin(const Index_t idx) const noexcept { return I_begin_denseVector_[idx]; }
        auto J_index(const Index_t idx) const noexcept { return J_index_denseVector_[idx]; }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto& operator=(const SelfType& toCopy) const noexcept
        {
            assert(this != &toCopy);
            assert(I_begin_denseVector_ == toCopy.I_begin_denseVector_);
            assert(J_index_denseVector_ == toCopy.J_index_denseVector_);

            cwise_copy(data_denseVector_, toCopy.data_denseVector_);

            return *this;
        }

        template <typename OTHER_DERIVED>
        auto& operator=(const Interface_CrsMatrix<OTHER_DERIVED>& toCopy) const noexcept
        {
            assert(I_begin_denseVector_ == toCopy.I_begin_denseVector_);
            assert(J_index_denseVector_ == toCopy.J_index_denseVector_);

            cwise_copy(data_denseVector_, toCopy.data_denseVector_);

            return *this;
        }

        auto& operator=(const ElementType& toCopy) const noexcept
        {
            cwise_filling(*this, toCopy);

            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto view(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            const auto indexInterval =
                create_indexInterval_lb_ub(I_begin_denseVector_[I_idx], I_begin_denseVector_[I_idx + 1] - 1);

            return create_sparseVector(J_size() /*FIXME: depends on MatrixShapeType*/,
                                       J_index_denseVector_.view_const(indexInterval),
                                       data_denseVector_.view(indexInterval));
        }
        auto view_const(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            const auto indexInterval =
                create_indexInterval_lb_ub(I_begin_denseVector_[I_idx], I_begin_denseVector_[I_idx + 1] - 1);

            return create_sparseVector(J_size() /*FIXME: depends on MatrixShapeType*/,
                                       J_index_denseVector_.view_const(indexInterval),
                                       data_denseVector_.view_const(indexInterval));
        }
        //
        // Note: view(const PlaceHolder _, const Index_t J_idx) not available, at least this is not a sparseVector type
        //

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto data_view() const noexcept { return data_denseVector_.view(); }
        auto data_view_const() const noexcept { return data_denseVector_.view_const(); }
        auto J_index_view_const() const noexcept { return J_index_denseVector_.view_const(); }
        auto I_begin_view_const() const noexcept { return I_begin_denseVector_.view_const(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // auto transposed_view() const noexcept
        // {
        /* CAVEAT CCS AND NOT CRS */
        //     return TransposedType(std::move(matrixStructure_.transposed()), memoryBlock_.view());
        // }

        // auto transposed_view_const() const noexcept
        // {
        //     return TransposedConstType(std::move(matrixStructure_.transposed()), view_const(memoryBlock_));
        // }

        // //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        // ViewType view() const noexcept { return ViewType(matrixStructure_, memoryBlock_.view()); }
        // ViewConstType view_const() const noexcept { return ViewConstType(matrixStructure_,
        // memoryBlock_.view_const()); }

        // //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //!@{
        /** @name Extra-methods
         */
        //!@}

        bool check_invariant() const noexcept
        {
            bool ok = true;

            const bool is_empty = (I_size_ == 0) && (J_size_ == 0);
            const bool is_not_empty = (I_size_ != 0) && (J_size_ != 0);

            ok &= is_empty || is_not_empty;

            if(ok)
            {
                if(is_empty)
                {
                    ok &= data_denseVector_.size() == 0;
                    ok &= I_begin_denseVector_.size() == 0;
                    ok &= J_index_denseVector_.size() == 0;
                }
                else
                {
                    ok &= (data_denseVector_.size() == J_index_denseVector_.size());
                    ok &= (I_size_ + 1 == I_begin_denseVector_.size());
                    ok &= cwise_min(J_index_denseVector_) >= 0;
                    ok &= cwise_max(J_index_denseVector_) < J_size_;
                    for(Index_t i = 0; i < I_size_; ++i)
                    {
                        if(I_begin_denseVector_[i] > I_begin_denseVector_[i + 1])
                        {
                            return false;
                        }
                    }

                    ok &= I_begin_denseVector_[0] >= 0;
                    ok &= I_begin_denseVector_[I_size_] <= data_denseVector_.size();

                    // TODO check avec shape
                }
            }
            return ok;
        }

       protected:
        Size_t I_size_, J_size_;
        CxS_Index_DenseVector_Const_Type I_begin_denseVector_;
        CxS_Index_DenseVector_Const_Type J_index_denseVector_;
        DATA_DENSEVECTOR data_denseVector_;
    };
}
