#pragma once

#include <Kiss_LinAlg/Matrix/interface_crsMatrix_fwd.hpp>

namespace Kiss
{

    //
    // Note: contrary to denseMatrix there is no need to distinguish
    // various MatrixUpLowType and PreferedIndexOrderInLoop
    //

    template <typename LAMBDA, typename CRSMATRIX_FIRST, typename... CRSMATRIX_TAIL>
    auto map(const LAMBDA& lambda, const Interface_CrsMatrix<CRSMATRIX_FIRST>& crsMatrix_first,
             const Interface_CrsMatrix<CRSMATRIX_TAIL>&... crsMatrix_tail)
    {
        assert(sameStructure(crsMatrix_first, crsMatrix_tail...));

        return map(lambda, crsMatrix_first.data_view(), crsMatrix_tail.data_view()...);
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <typename LAMBDA, typename CRSMATRIX>
    void indexed_map(const LAMBDA& lambda, const Interface_CrsMatrix<CRSMATRIX>& crsMatrix)
    {
        const Size_t I_size = crsMatrix.I_size();

        if(I_size > 0)
        {
            Index_t k_begin, k_end = crsMatrix.I_begin(0);
#pragma omp simd
            for(Index_t i = 0; i < I_size; i++)
            {
                k_begin = k_end;
                k_end = crsMatrix.I_begin(i + 1);

                for(Index_t k = k_begin; k < k_end; ++k)
                {
                    lambda(i, crsMatrix.J_index(k), crsMatrix[k]);
                }
            }
        }
    }
}
