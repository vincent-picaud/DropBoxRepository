/** @ingroup Kiss_XXX
    @file   
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Sat Apr 30 09:00:01 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/Vector/sparseVector_fwd.hpp>
	#include <Kiss_LinAlg/Tag/matrixShape.hpp>

namespace Kiss {
	
	 //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	// A common declaration for dense vector of indices
	//
	// Read comment in SparseVector_Index_DenseVector_Const_Type for explanation
	//
    using CxS_Index_DenseVector_Const_Type = SparseVector_Index_DenseVector_Const_Type;

    // This type is defined for user convenience to allow him
    // to construct (mutable Index_t) the sparsity pattern
    //
    using CxS_Index_DenseVector_Type = SparseVector_Index_DenseVector_Type;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <typename DATA_DENSEVECTOR, typename MATRIXSHAPE_TYPE = MatrixShape_Full>
    class CrsMatrix_Implementation;

	template <typename DATA_DENSEVECTOR, typename MATRIXSHAPE_TYPE = MatrixShape_Full>
    class CcsMatrix_Implementation;


} /* Kiss */
