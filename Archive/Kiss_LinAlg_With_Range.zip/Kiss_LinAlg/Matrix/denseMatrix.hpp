#pragma once

#include <Kiss_LinAlg/Matrix/denseMatrix_implementation.hpp>
#include <Kiss_LinAlg/MemoryStructure/array2_memoryStructure.hpp>
#include <Kiss_LinAlg/MemoryBlock/sharedMemoryBlock.hpp>
//#include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr.hpp>

namespace Kiss
{

    // [[ConstructorAndType]]

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Default type for DenseMatrix
         @relates DenseMatrix_Implementation

         Default type is __ColumnMajor__
    */
    template <typename T, typename MATRIXSHAPE_TYPE = MatrixShape_Full,
              typename = std::enable_if_t<MatrixShape_Well_Defined<MATRIXSHAPE_TYPE>>>
    using Matrix = DenseMatrix_Implementation<std::integral_constant<Size_t, 0>,   // Static offset
                                              Size_t,                              // Dynamic I_size
                                              Size_t,                              // Dynamic J_size
                                              std::integral_constant<Index_t, 1>,  // ColumnMajor
                                              Index_t,                             // Dynamic J_stride,
                                              MATRIXSHAPE_TYPE,                    // MatrixShape
                                              PreferedIndexOrderInLoop_Backward,   // Loop J, then I (for columnMajor)
                                              SharedMemoryBlock<T>                 // Memory block
                                              >;

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Creates a dense matrix from its dimensions
         @relates DenseMatrix_Implementation
    */
    template <typename T, typename MATRIXSHAPE_TYPE = MatrixShape_Full,
              typename = std::enable_if_t<MatrixShape_Well_Defined<MATRIXSHAPE_TYPE>>>
    auto create_matrix(const Size_t I_size, const Size_t J_size)
    {
        // What is important there is that we return the default type!
        //
        using MatrixType = Matrix<T, MATRIXSHAPE_TYPE>;
        using MatrixStructureType = typename MatrixType::MatrixStructureType;
        using MemoryBlockType = typename MatrixType::MemoryBlockType;

        MatrixStructureType matrixStructure(0, I_size, J_size, 1, I_size);
        return MatrixType(matrixStructure, MemoryBlockType(matrixStructure.required_capacity()));
    }
    // [[ConstructorAndType]]

    //================ CopyConstructor

    // [[HowToImplementCopyConstructor]]
    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Dynamic dense matrix deep copy
         @relates DenseMatrix_Implementation

		 @todo Mettre en place methode Create_Copy
    */
    template <typename OFFSET, typename I_STRIDE_TYPE, typename J_STRIDE_TYPE, typename INDEXORDERINLOOP_TYPE,
              typename MATRIXSHAPE_TYPE, typename MEMORY_BLOCK>
    auto create_copy(const DenseMatrix_Implementation<OFFSET, Size_t, Size_t, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                                      MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& toCopy)
    {
        using MatrixType = Matrix<typename MEMORY_BLOCK::ElementType, MATRIXSHAPE_TYPE>;
        using MatrixStructureType = typename MatrixType::MatrixStructureType;
        using MemoryBlockType = typename MatrixType::MemoryBlockType;

        MatrixStructureType matrixStructure(0, toCopy.I_size(), toCopy.J_size(), 1, toCopy.I_size());
        MemoryBlockType memoryBlock(matrixStructure.required_capacity());

        MatrixType toReturn(std::move(matrixStructure), std::move(memoryBlock));

        cwise_copy(toReturn, toCopy);

        return toReturn;
    }
    // [[HowToImplementCopyConstructor]]
}


