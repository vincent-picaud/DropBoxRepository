#pragma once

#include <Kiss_LinAlg/Vector/denseVector_implementation.hpp>

#include <Kiss_LinAlg/Matrix/interface_denseMatrix.hpp>


#include <Kiss_LinAlg/Tag/matrixShape.hpp>
#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>
#include <Kiss_LinAlg/Tag/indexOrderInLoop.hpp>

#include <Kiss_LinAlg/MemoryStructure/array2_memoryStructure.hpp>

namespace Kiss
{
    template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE, typename MEMORY_BLOCK>
    class DenseMatrix_Implementation;

    template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE, typename MEMORY_BLOCK>
    struct CRTP_TypeTraits<DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                                      MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>>
    {
        using ElementType = typename MEMORY_BLOCK::ElementType;
        using MatrixShapeType = MATRIXSHAPE_TYPE;
        using MatrixUpLowType = typename MatrixShapeType::MatrixUpLowType;
        using PreferedIndexOrderInLoop = INDEXORDERINLOOP_TYPE;
    };

    // View
    namespace Internal
    {
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // (I,_)
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_tagged(
            const MatrixUpLow_Irrelevant&,
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {
            static_assert(std::is_same<typename MATRIXSHAPE_TYPE::MatrixUpLowType, MatrixUpLow_Irrelevant>::value, "");

            using ToReturnType = DenseVector_Implementation<Index_t, J_SIZE_TYPE, J_STRIDE_TYPE,
                                                            decltype(denseMatrix.memoryBlock_view())>;

            return ToReturnType(denseMatrix.memoryStructure().offset_index(I_idx, 0),
                                denseMatrix.memoryStructure().J_size(), denseMatrix.memoryStructure().J_stride(),
                                denseMatrix.memoryBlock_view());
        }

        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_tagged(
            const MatrixUpLow_Lower&,
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {
            static_assert(std::is_same<typename MATRIXSHAPE_TYPE::MatrixUpLowType, MatrixUpLow_Lower>::value, "");

            using ToReturnType =
                DenseVector_Implementation<Index_t, Size_t, J_STRIDE_TYPE, decltype(denseMatrix.memoryBlock_view())>;

            return ToReturnType(denseMatrix.memoryStructure().offset_index(I_idx, 0),
                                std::min(denseMatrix.memoryStructure().J_size(), I_idx + 1),
                                denseMatrix.memoryStructure().J_stride(), denseMatrix.memoryBlock_view());
        }
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_tagged(
            const MatrixUpLow_LowerStrict&,
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {
            static_assert(std::is_same<typename MATRIXSHAPE_TYPE::MatrixUpLowType, MatrixUpLow_LowerStrict>::value, "");

            using ToReturnType =
                DenseVector_Implementation<Index_t, Size_t, J_STRIDE_TYPE, decltype(denseMatrix.memoryBlock_view())>;

            return ToReturnType(denseMatrix.memoryStructure().offset_index(I_idx, 0),
                                std::min(denseMatrix.memoryStructure().J_size(), I_idx),
                                denseMatrix.memoryStructure().J_stride(), denseMatrix.memoryBlock_view());
        }
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_tagged(
            const MatrixUpLow_Upper&,
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {
            static_assert(std::is_same<typename MATRIXSHAPE_TYPE::MatrixUpLowType, MatrixUpLow_Upper>::value, "");

            using ToReturnType =
                DenseVector_Implementation<Index_t, Size_t, J_STRIDE_TYPE, decltype(denseMatrix.memoryBlock_view())>;

            return ToReturnType(denseMatrix.memoryStructure().offset_index(I_idx, I_idx),
                                std::max(denseMatrix.memoryStructure().J_size() - I_idx, 0),
                                denseMatrix.memoryStructure().J_stride(), denseMatrix.memoryBlock_view());
        }
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_tagged(
            const MatrixUpLow_UpperStrict&,
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {
            static_assert(std::is_same<typename MATRIXSHAPE_TYPE::MatrixUpLowType, MatrixUpLow_UpperStrict>::value, "");

            using ToReturnType =
                DenseVector_Implementation<Index_t, Size_t, J_STRIDE_TYPE, decltype(denseMatrix.memoryBlock_view())>;

            return ToReturnType(denseMatrix.memoryStructure().offset_index(I_idx, I_idx + 1),
                                std::max(denseMatrix.memoryStructure().J_size() - I_idx - 1, 0),
                                denseMatrix.memoryStructure().J_stride(), denseMatrix.memoryBlock_view());
        }

        //~~~~~~~~~~~~~~~~

        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view(
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder placeHolder) noexcept
        {
            return view_tagged(typename MATRIXSHAPE_TYPE::MatrixUpLowType(), denseMatrix, I_idx, placeHolder);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // (_,J) -> use (I,_) on transposed
        //
        // Maybe not the most efficient, but avoid redundancy
        //
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view(
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const PlaceHolder, const Index_t J_idx) noexcept
        {
            return denseMatrix.transposed_view().view(J_idx, _);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // view_const -> take view_const(view))
        //
        // Maybe not the most efficient, but avoid redundancy
        //
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        //
        template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
                  typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE,
                  typename MEMORY_BLOCK>
        constexpr auto view_const(
            const DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                             MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& denseMatrix,
            const Index_t I_idx, const PlaceHolder) noexcept
        {

            return view(denseMatrix, I_idx, _).view_const();
        }
    }

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Generic implementation of dense matrix
         @extends Interface_DenseMatrix
    */
    template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE, typename MEMORY_BLOCK>
    class DenseMatrix_Implementation final
#ifndef DOXYGEN_DOC
        : public Interface_DenseMatrix<
              DenseMatrix_Implementation<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                         MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>>
#endif
    {
        using SelfType = DenseMatrix_Implementation;
        using TraitsType = CRTP_TypeTraits<SelfType>;

        static_assert(std::is_final<MEMORY_BLOCK>::value, "");
        static_assert(Is_CRTP_Interface<MEMORY_BLOCK, Kiss::Interface_MemoryBlock>::value, "");

        static_assert(MatrixShape_Well_Defined<typename TraitsType::MatrixShapeType>, "");

       public:
        using ElementType = typename TraitsType::ElementType;
        using MatrixUpLowType = typename TraitsType::MatrixUpLowType;

        using MatrixStructureType =
            Array2_MemoryStructure<OFFSET, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                   typename TraitsType::MatrixUpLowType, INDEXORDERINLOOP_TYPE>;
        using MemoryBlockType = MEMORY_BLOCK;

       public:
        /** Default constructor */
        constexpr DenseMatrix_Implementation() noexcept : matrixStructure_(), memoryBlock_()
        {
            assert(check_invariant());
        }

        /** Copy constructor

            @note the memory block is moved!
        */
        DenseMatrix_Implementation(const MatrixStructureType& matrixStructure, MemoryBlockType&& memoryBlock)
            : matrixStructure_(matrixStructure), memoryBlock_(std::move(memoryBlock))
        {
            assert(check_invariant());
        }

        /** Move constructor */
        DenseMatrix_Implementation(SelfType&& toMove) = default;

        /** Mainly for developper */
        constexpr auto memoryBlock_view() const noexcept { return memoryBlock_.view(); };
        /** Mainly for developper */
        constexpr auto memoryBlock_view_const() const noexcept { return memoryBlock_.view_const(); };

        constexpr decltype(auto) operator()(const Index_t I_idx, const Index_t J_idx) const noexcept
        {
            assert(matrixStructure_.check_index(I_idx, J_idx));
            assert(matrixStructure_.offset_index(I_idx, J_idx) < memoryBlock_.capacity());
            return *(memoryBlock_.data() + matrixStructure_.offset_index(I_idx, J_idx));
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto& operator=(const SelfType& toCopy) const noexcept
        {
            assert(this != &toCopy);

            cwise_copy(*this, toCopy);

            return *this;
        }

        template <typename OTHER_DERIVED>
        constexpr auto& operator=(const Interface_DenseMatrix<OTHER_DERIVED>& toCopy) const noexcept
        {
            cwise_copy(*this, toCopy);

            return *this;
        }

        constexpr auto& operator=(const ElementType& toCopy) const noexcept
        {
            cwise_filling(*this, toCopy);

            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr I_SIZE_TYPE I_size() const noexcept { return matrixStructure_.I_size(); }
        constexpr J_SIZE_TYPE J_size() const noexcept { return matrixStructure_.J_size(); }
        constexpr I_STRIDE_TYPE I_stride() const noexcept { return matrixStructure_.I_stride(); }
        constexpr J_STRIDE_TYPE J_stride() const noexcept { return matrixStructure_.J_stride(); }

        //~~~~~~~~~~~~~~~~

        constexpr const auto& memoryStructure() const noexcept { return matrixStructure_; }
        //~~~~~~~~~~~~~~~~

        constexpr bool check_index(Index_t I_idx, Index_t J_idx) const noexcept
        {
            return matrixStructure_.check_index(I_idx, J_idx);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto view(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            return Internal::view(*this, I_idx, _);
        }

        constexpr auto view_const(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            return Internal::view_const(*this, I_idx, _);
        }

        //~~~~~~~~~~~~~~~~

        constexpr auto view(const PlaceHolder _, const Index_t J_idx) const noexcept
        {
            return Internal::view(*this, _, J_idx);
        }

        constexpr auto view_const(const PlaceHolder _, const Index_t J_idx) const noexcept
        {
            return Internal::view_const(*this, _, J_idx);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto transposed_view() const noexcept
        {
            return create_matrix(matrixStructure_.transposed(), typename MATRIXSHAPE_TYPE::TransposedType(),
                                 memoryBlock_.view());
        }

        constexpr auto transposed_view_const() const noexcept
        {
            return create_matrix(matrixStructure_.transposed(), typename MATRIXSHAPE_TYPE::TransposedType(),
                                 memoryBlock_.view_const());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto view() const noexcept
        {
            return create_matrix(matrixStructure_, MATRIXSHAPE_TYPE(), memoryBlock_.view());
        }

        constexpr auto view_const() const noexcept
        {
            return create_matrix(matrixStructure_, MATRIXSHAPE_TYPE(), memoryBlock_.view_const());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr bool check_invariant() const noexcept
        {
            bool ok = true;
            ok &= (matrixStructure_.required_capacity() <= memoryBlock_.capacity());
            return ok;
        }

       protected:
        MatrixStructureType matrixStructure_;
        MemoryBlockType memoryBlock_;
    };

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Constructor
         @relates DenseMatrix_Implementation
    */
    // CAVEAT: for template deduction, we __explicitly__ need the MATRIXSHAPE_TYPE
    template <typename OFFSET_TYPE, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE, typename MEMORY_BLOCK,
              typename = std::enable_if_t<Is_DynStatArgument<Integer_Common_t, OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE,
                                                             I_STRIDE_TYPE, J_STRIDE_TYPE>::value &&
                                          MatrixShape_Well_Defined<MATRIXSHAPE_TYPE> &&
                                          PreferedIndexOrderInLoop_Well_Defined<INDEXORDERINLOOP_TYPE>>>
    constexpr auto create_matrix(const Array2_MemoryStructure<OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE,
                                                              J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE::MatrixUpLowType,
                                                              INDEXORDERINLOOP_TYPE>& matrixStructure,
                                 const MATRIXSHAPE_TYPE, Interface_MemoryBlock<MEMORY_BLOCK>&& memoryBlock) noexcept
    {
        using MatrixType =
            DenseMatrix_Implementation<OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                       MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>;

        return MatrixType(matrixStructure, std::move(memoryBlock.impl()));
    }

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Constructor
         @relates DenseMatrix_Implementation
    */
    template <typename OFFSET_TYPE, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXSHAPE_TYPE, typename INDEXORDERINLOOP_TYPE, typename MEMORY_BLOCK,
              typename = std::enable_if_t<Is_DynStatArgument<Integer_Common_t, OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE,
                                                             I_STRIDE_TYPE, J_STRIDE_TYPE>::value &&
                                          MatrixShape_Well_Defined<MATRIXSHAPE_TYPE> &&
                                          PreferedIndexOrderInLoop_Well_Defined<INDEXORDERINLOOP_TYPE>>>
    constexpr auto create_matrix(const OFFSET_TYPE offset, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                                 const I_STRIDE_TYPE I_stride, const J_STRIDE_TYPE J_stride, const MATRIXSHAPE_TYPE,
                                 const INDEXORDERINLOOP_TYPE,
                                 Interface_MemoryBlock<MEMORY_BLOCK>&& memoryBlock) noexcept
    {
        return create_matrix(create_array2_memoryStructure(offset, I_size, J_size, I_stride, J_stride,
                                                           typename MATRIXSHAPE_TYPE::MatrixUpLowType(),
                                                           INDEXORDERINLOOP_TYPE()),
                             MATRIXSHAPE_TYPE(), std::move(memoryBlock.impl()));
    }
}
