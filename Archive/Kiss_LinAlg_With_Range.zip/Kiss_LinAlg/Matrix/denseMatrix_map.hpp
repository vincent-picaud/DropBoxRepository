#pragma once

#include <Kiss_LinAlg/Matrix/interface_denseMatrix_fwd.hpp>
#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>
#include <Kiss_LinAlg/Tag/indexOrderInLoop.hpp>

#include <algorithm> // pour min, lourd!

namespace Kiss
{

        //////////////////////////////
        // VARIADIC WITHOUT INDICES //
        //////////////////////////////

        ////////////////////////////////////////////////////////////////// USE TAG

        //================================================================ MatrixUpLow_Irrelevant,
        // PreferedIndexOrderInLoop_Backward

        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const MatrixUpLow_Irrelevant&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                 const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            assert(sameStructure(denseMatrix_first, denseMatrix_tail...));

            const Size_t i_size = denseMatrix_first.I_size();
            const Size_t j_size = denseMatrix_first.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = 0; i < i_size; ++i)
                {
                    lambda(denseMatrix_first(i, j), denseMatrix_tail(i, j)...);
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const MatrixUpLow_Lower&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                 const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            assert(sameStructure(denseMatrix_first, denseMatrix_tail...));

            const Size_t i_size = denseMatrix_first.I_size();
            const Size_t j_size = denseMatrix_first.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = j; i < i_size; ++i)
                {
                    lambda(denseMatrix_first(i, j), denseMatrix_tail(i, j)...);
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const MatrixUpLow_LowerStrict&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                 const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            assert(sameStructure(denseMatrix_first, denseMatrix_tail...));

            const Size_t i_size = denseMatrix_first.I_size();
            const Size_t j_size = denseMatrix_first.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = j + 1; i < i_size; ++i)
                {
                    lambda(denseMatrix_first(i, j), denseMatrix_tail(i, j)...);
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const MatrixUpLow_UpperStrict&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                 const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            assert(sameStructure(denseMatrix_first, denseMatrix_tail...));

            const Size_t i_size = denseMatrix_first.I_size();
            const Size_t j_size = denseMatrix_first.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                const Size_t i_end = std::min(j, i_size);
                for(Index_t i = 0; i < i_end; ++i)
                {
                    lambda(denseMatrix_first(i, j), denseMatrix_tail(i, j)...);
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const MatrixUpLow_Upper&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                 const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            assert(sameStructure(denseMatrix_first, denseMatrix_tail...));

            const Size_t i_size = denseMatrix_first.I_size();
            const Size_t j_size = denseMatrix_first.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                const Size_t i_end = std::min(j + 1, i_size);
                for(Index_t i = 0; i < i_end; ++i)
                {
                    lambda(denseMatrix_first(i, j), denseMatrix_tail(i, j)...);
                }
            }
        }

        //================================================================ PreferedIndexOrderInLoop_Forward
        //                                                                 -> we use transposed_view

        template <typename MATRIXUPLOW, typename LAMBDA, typename... DENSEMATRIX>
        std::enable_if_t<MatrixUpLow_Well_Defined<MATRIXUPLOW>>
            map(const MATRIXUPLOW&, const PreferedIndexOrderInLoop_Forward&, LAMBDA lambda,
                const Interface_DenseMatrix<DENSEMATRIX>&... denseMatrix)
        {
            map(typename MATRIXUPLOW::TransposedType(), PreferedIndexOrderInLoop_Backward(), lambda,
                denseMatrix.transposed_view()...);
        }

        ////////////////////////////////////////////////////////////////// DO NOT USE TAG

        /** @ingroup Kiss_LinAlg_Matrix_Group
            @brief Maps a lambda
        */
        template <typename LAMBDA, typename DENSEMATRIX_FIRST, typename... DENSEMATRIX_TAIL>
        void map(const LAMBDA lambda, const Interface_DenseMatrix<DENSEMATRIX_FIRST>& denseMatrix_first,
                 const Interface_DenseMatrix<DENSEMATRIX_TAIL>&... denseMatrix_tail)
        {
            map(typename Interface_DenseMatrix<DENSEMATRIX_FIRST>::MatrixUpLowType(),
                typename Interface_DenseMatrix<DENSEMATRIX_FIRST>::PreferedIndexOrderInLoop(), lambda,
                denseMatrix_first, denseMatrix_tail...);
        }

        //////////////////////////
        // ONE ARG WITH INDICES //
        //////////////////////////
        //
        // Lambda (i,j,&m_ij)
        //
        ////////////////////////////////////////////////////////////////// USE TAG

        //================================================================ MatrixUpLow_Irrelevant,
        // PreferedIndexOrderInLoop_Backward

        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const MatrixUpLow_Irrelevant&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                         const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {

            const Size_t i_size = denseMatrix.I_size();
            const Size_t j_size = denseMatrix.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = 0; i < i_size; ++i)
                {
                    lambda(i, j, denseMatrix(i, j));
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const MatrixUpLow_Lower&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                         const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {

            const Size_t i_size = denseMatrix.I_size();
            const Size_t j_size = denseMatrix.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = j; i < i_size; ++i)
                {
                    lambda(i, j, denseMatrix(i, j));
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const MatrixUpLow_LowerStrict&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                         const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {

            const Size_t i_size = denseMatrix.I_size();
            const Size_t j_size = denseMatrix.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                for(Index_t i = j + 1; i < i_size; ++i)
                {
                    lambda(i, j, denseMatrix(i, j));
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const MatrixUpLow_UpperStrict&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                         const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {

            const Size_t i_size = denseMatrix.I_size();
            const Size_t j_size = denseMatrix.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                const Size_t i_end = std::min(j, i_size);
                for(Index_t i = 0; i < i_end; ++i)
                {
                    lambda(i, j, denseMatrix(i, j));
                }
            }
        }

        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const MatrixUpLow_Upper&, const PreferedIndexOrderInLoop_Backward&, LAMBDA lambda,
                         const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {

            const Size_t i_size = denseMatrix.I_size();
            const Size_t j_size = denseMatrix.J_size();

#pragma omp simd
            for(Index_t j = 0; j < j_size; ++j)
            {
                const Size_t i_end = std::min(j + 1, i_size);
                for(Index_t i = 0; i < i_end; ++i)
                {
                    lambda(i, j, denseMatrix(i, j));
                }
            }
        }

        //================================================================ PreferedIndexOrderInLoop_Forward
        //                                                                 -> we use transposed_view

        template <typename MATRIXUPLOW, typename LAMBDA, typename DENSEMATRIX>
        std::enable_if_t<MatrixUpLow_Well_Defined<MATRIXUPLOW>>
            indexed_map(const MATRIXUPLOW&, const PreferedIndexOrderInLoop_Forward&, LAMBDA lambda,
                        const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {
            indexed_map(typename MATRIXUPLOW::TransposedType(), PreferedIndexOrderInLoop_Backward(), lambda,
                        denseMatrix.transposed_view());
        }

        ////////////////////////////////////////////////////////////////// DO NOT USE TAG

        /** @ingroup Kiss_LinAlg_Matrix_Group
            @brief Maps a lambda
        */
        template <typename LAMBDA, typename DENSEMATRIX>
        void indexed_map(const LAMBDA lambda, const Interface_DenseMatrix<DENSEMATRIX>& denseMatrix)
        {
            indexed_map(typename Interface_DenseMatrix<DENSEMATRIX>::MatrixUpLowType(),
                        typename Interface_DenseMatrix<DENSEMATRIX>::PreferedIndexOrderInLoop(), lambda, denseMatrix);
        }
}
