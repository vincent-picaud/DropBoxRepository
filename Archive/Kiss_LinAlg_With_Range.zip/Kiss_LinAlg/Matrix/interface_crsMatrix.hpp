#pragma once

#include <Kiss_LinAlg/Matrix/interface_sparseMatrix.hpp>
#include <Kiss_LinAlg/Matrix/crsMatrix_map.hpp>
#include <Kiss_LinAlg/Meta/placeHolder.hpp>

#include <Kiss_LinAlg/Matrix/denseMatrix.hpp>  // Only for << (screen Print)

#include <ostream>
#include <iomanip>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief  matrix Interface
         @extends Interface_Matrix
    */
    template <typename DERIVED>
    class Interface_CrsMatrix
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_CrsMatrix, DERIVED, Interface_SparseMatrix>
#endif
    {
        using TraitsType = CRTP_TypeTraits<DERIVED>;
        using SelfType = Interface_CrsMatrix;

       public:
        using ElementType = typename TraitsType::ElementType;
        using MatrixShapeType = typename TraitsType::MatrixShapeType;
        using MatrixUpLowType = typename TraitsType::MatrixUpLowType;

       public:
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto J_index(const Index_t nonZero_idx) const noexcept { return SelfType::impl().J_index(nonZero_idx); }
        auto I_begin(const Index_t I_idx) const noexcept { return SelfType::impl().I_begin(I_idx); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto& operator=(const SelfType& toCopy) const noexcept { return SelfType::impl() = toCopy.impl(); }

        auto& operator=(const ElementType& toCopy) const noexcept { return SelfType::impl() = toCopy; }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @brief Returns view on the data vector */
        auto data_view() const noexcept { return SelfType::impl().data_view(); }
        /** @brief Returns view on the data const vector */
        auto data_view_const() const noexcept { return SelfType::impl().data_view_const(); }

        /** @brief Returns view on the I_begin const vector */
        auto I_begin_view_const() const noexcept { return SelfType::impl().I_begin_view_const(); }
        /** @brief Returns view on the J_index const vector */
        auto J_index_view_const() const noexcept { return SelfType::impl().J_index_view_const(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @brief Transposed view */
        auto transposed_view() const noexcept { return SelfType::impl().transposed_view(); }

        /** @brief Constant transposed view */
        auto transposed_view_const() const noexcept { return SelfType::impl().transposed_view_const(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @brief Returns a view(i,_) */
        auto view(const Index_t I_idx, const PlaceHolder _) const noexcept { return SelfType::impl().view(I_idx, _); }

        /** @brief Returns a constant view(i,_) */
        auto view_const(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            return SelfType::impl().view_const(I_idx, _);
        }
    };

    //////////////////////////////////////////////////////////////////

    MACRO_DEFINE_CWISE_INPLACE_OP_ALL(Interface_CrsMatrix);

    //////////////////////////////////////////////////////////////////

    //################################################################

    template <typename D1, typename... DN>
    constexpr bool sameStructure(const Interface_CrsMatrix<D1>& d1, const Interface_CrsMatrix<DN>&... dn) noexcept
    {
        return (Conjunction<std::is_same<typename D1::MatrixUpLowType, typename DN::MatrixUpLowType>...>::value) &&
               conjunction((d1.J_index_view_const() == dn.J_index_view_const())...) &&
               conjunction((d1.I_begin_view_const() == dn.I_begin_view_const())...);
    }

    //################################################################

    /** @ingroup Kiss_LinAlg_Matrix_Group
        @brief Matrix screen print
        @relates Interface_CrsMatrix

        @attention we use a DenseMatrix as temporary storage...
        This only works for __small__ sparse matrices
    */
    template <typename DERIVED>
    auto& operator<<(std::ostream& out, const Interface_CrsMatrix<DERIVED>& toPrint)
    {
        using ElementType = std::remove_cv_t<typename Interface_CrsMatrix<DERIVED>::ElementType>;
        using MatrixShapeType = std::remove_cv_t<typename Interface_CrsMatrix<DERIVED>::MatrixShapeType>;

        auto denseCopy = create_matrix<ElementType, MatrixShapeType>(toPrint.I_size(), toPrint.J_size());

        denseCopy = ElementType(0);

        indexed_map(
            [&](const Index_t i, const Index_t j, const auto& toPrint_ij)
            {
                denseCopy(i, j) = toPrint_ij;
            },
            toPrint);

        out << denseCopy;

        return out;
    }
}
