#pragma once

#include <Kiss_LinAlg/Matrix/interface_denseMatrix_fwd.hpp>
#include <Kiss_LinAlg/Matrix/interface_matrix.hpp>
#include <Kiss_LinAlg/Matrix/denseMatrix_map.hpp>
#include <Kiss_LinAlg/Meta/placeHolder.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>  // For sameStructure

#include <cassert>
#include <ostream>
#include <iomanip>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief  matrix Interface
         @extends Interface_Matrix
    */
    template <typename DERIVED>
    class Interface_DenseMatrix
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_DenseMatrix, DERIVED, Interface_Matrix>
#endif
    {
        using TraitsType = CRTP_TypeTraits<DERIVED>;
        using SelfType = Interface_DenseMatrix;

       public:
        using ElementType = typename TraitsType::ElementType;
        using MatrixShapeType = typename TraitsType::MatrixShapeType;
        using MatrixUpLowType = typename TraitsType::MatrixUpLowType;
        using PreferedIndexOrderInLoop = typename TraitsType::PreferedIndexOrderInLoop;

       protected:
        Interface_DenseMatrix() = default;

       public:
        /** Read mode access to components */
        constexpr decltype(auto) operator()(Index_t I_idx, Index_t J_idx) const noexcept
        {
            return SelfType::impl()(I_idx, J_idx);
        }

        /** Transposed view */
        constexpr auto transposed_view() const noexcept { return SelfType::impl().transposed_view(); }

        /** Constant transposed view */
        constexpr auto transposed_view_const() const noexcept { return SelfType::impl().transposed_view_const(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** Returns a view(i,_) */
        constexpr auto view(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            return SelfType::impl().view(I_idx, _);
        }

        /** Returns a constant view(i,_) */
        constexpr auto view_const(const Index_t I_idx, const PlaceHolder _) const noexcept
        {
            return SelfType::impl().view_const(I_idx, _);
        }

        /** Returns a view(_,j) */
        constexpr auto view(const PlaceHolder _, const Index_t J_idx) const noexcept
        {
            return SelfType::impl().view(_, J_idx);
        }

        /** Returns a view_const(_,j) */
        constexpr auto view_const(const PlaceHolder _, const Index_t J_idx) const noexcept
        {
            return SelfType::impl().view_const(_, J_idx);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** Check index */
        constexpr auto check_index(const Index_t I_idx, const Index_t J_idx) const noexcept
        {
            return SelfType::impl().check_index(I_idx, J_idx);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    };

    //////////////////////////////////////////////////////////////////

	MACRO_DEFINE_CWISE_INPLACE_OP_ALL(Interface_DenseMatrix)

	//################################################################
	
    /** @ingroup Kiss_LinAlg_Matrix_Group
        @brief Check matrix dimensions
        @relates Interface_DenseMatrix

    */
    template <typename DERIVED_FIRST, typename... DERIVED_TAIL>
    constexpr bool sameStructure(const Interface_DenseMatrix<DERIVED_FIRST>& denseMatrix_first,
                                 const Interface_DenseMatrix<DERIVED_TAIL>&... denseMatrix_tail) noexcept
    {
        return (Conjunction<std::is_same<typename DERIVED_FIRST::MatrixUpLowType,
                                         typename DERIVED_TAIL::MatrixUpLowType>...>::value) &&
               sameDimension(denseMatrix_first, denseMatrix_tail...);
    }

  //################################################################
  
    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Matrix Screen Print
         @relates Interface_DenseMatrix
    */
    template <typename DERIVED>
    std::ostream& operator<<(std::ostream& out, const Interface_DenseMatrix<DERIVED>& matrix)
    {
        // Note: in future maybe use range
        const Size_t _I_size = matrix.I_size();
        const Size_t _J_size = matrix.J_size();

        for(Index_t i = 0; i < _I_size; ++i)
        {
            out << "\n";
            for(Index_t j = 0; j < _J_size; ++j)
            {
                out << std::setw(20);
                if(matrix.check_index(i, j))
                {
                    out << matrix(i, j) << " ";
                }
                else
                {
                    out << "*"
                        << " ";
                }
            }
        }

        return out;
    }
}
