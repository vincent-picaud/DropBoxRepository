#pragma once

#include <Kiss_LinAlg/Matrix/interface_matrix_fwd.hpp>

#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Matrix
         @extends CRTP_Base
    */
    template <typename DERIVED>
    class Interface_Matrix
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Matrix, DERIVED, CRTP_Base>
#endif
    {
       public:
        using SelfType = Interface_Matrix;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        /** Element type */
        using ElementType = typename TraitsType::ElementType;

        // using ViewType = typename TraitsType::ViewType;
        // using ViewConstType = typename TraitsType::ViewConstType;

       protected:
        Interface_Matrix() = default;

       public:
        constexpr auto I_size() const noexcept { return SelfType::impl().I_size(); }
        constexpr auto J_size() const noexcept { return SelfType::impl().J_size(); }

        /** Matrix deep copy */
        auto& operator=(const SelfType& toCopy) { return SelfType::impl() = toCopy; }

        /** Fill matrix with a constant */
        auto& operator=(const ElementType& toCopy) const { return SelfType::impl() = toCopy; }

        /** view */
        constexpr auto view() const noexcept { return SelfType::impl().view(); }

        /** Constant view */
        constexpr auto view_const() const noexcept { return SelfType::impl().view_const(); }
    };

    //////////////////////////////////////////////////////////////////

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    MACRO_DECLARE_CWISE_INPLACE_OP_ALL(Interface_Matrix)

    //################################################################

    template <typename DERIVED>
    constexpr auto sameDimension(const Interface_Matrix<DERIVED>&) noexcept
    {
        return true;
    }

    /** @ingroup Kiss_LinAlg_Matrix_Group
        @brief Check matrix dimensions
        @relates Interface_Matrix

        @note also works for any number of matrices

    */
    template <typename D1, typename D2>
    constexpr auto sameDimension(const Interface_Matrix<D1>& d1, const Interface_Matrix<D2>& d2) noexcept
    {
        return (d1.I_size() == d2.I_size()) && (d1.J_size() == d2.J_size());
    }

    template <typename D1, typename D2, typename... DN>
    constexpr auto sameDimension(const Interface_Matrix<D1>& d1, const Interface_Matrix<D2>& d2,
                                 const Interface_Matrix<DN>&... dn) noexcept
    {
        return sameDimension(d1.impl(), d2.impl()) && sameDimension(d2.impl(), dn.impl()...);
    }

    //################################################################

    template <typename DERIVED>
    constexpr auto sameStructure(const Interface_Matrix<DERIVED>&) noexcept
    {
        return true;
    }

    /** @ingroup Kiss_LinAlg_Matrix_Group
        @brief Check matrix structure
        @relates Interface_Matrix

        @note also works for any number of matrixs
    */
    template <typename D1, typename D2>
    constexpr auto sameStructure(const Interface_Matrix<D1>& d1, const Interface_Matrix<D2>& d2) noexcept
    {
        /** Default is false */
        return false;
    }

    template <typename D1, typename D2, typename... DN>
    constexpr auto sameStructure(const Interface_Matrix<D1>& d1, const Interface_Matrix<D2>& d2,
                                 const Interface_Matrix<DN>&... dn) noexcept
    {
        return sameStructure(d1, d2) && sameStructure(d2, dn...);
    }

    //################################################################

    // /** @ingroup Kiss_LinAlg_Matrix_Group
    //     @brief Check matrix dimensions
    //     @relates Interface_Matrix

    //     @note also works for any number of matrices
    // */
    // template <typename DERIVED_1, typename DERIVED_2>
    // constexpr bool
    //     sameDimension(const Interface_Matrix<DERIVED_1>& matrix_1, const Interface_Matrix<DERIVED_2>& matrix_2)
    //     noexcept
    // {
    //     return (matrix_1.I_size() == matrix_2.I_size()) && (matrix_1.J_size() == matrix_2.J_size());
    // }

    // // Variadic template version
    // template <typename DERIVED_1, typename DERIVED_2, typename... DERIVED_TAIL>
    // constexpr bool
    //     sameDimension(const Interface_Matrix<DERIVED_1>& matrix_1, const Interface_Matrix<DERIVED_2>& matrix_2,
    //                   const Interface_Matrix<DERIVED_TAIL>&... matrix_tail) noexcept
    // {
    //     return sameDimenion(matrix_1, matrix_2) && sameDimenion(matrix_2, matrix_tail...);
    // }

    // //
    // // CAVEAT: Unary version (NEEDED BY map(M) FOR INSTANCE)
    // //
    // template <typename DERIVED>
    // constexpr bool sameDimension(const Interface_Matrix<DERIVED>&) noexcept
    // {
    //     return true;
    // }
}
