#pragma once

#include <Kiss_LinAlg/Matrix/interface_matrix.hpp>
#include <Kiss_LinAlg/Meta/placeHolder.hpp>

#include <cassert>
#include <ostream>
#include <iomanip>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief  matrix Interface
         @extends Interface_Matrix
    */
    template <typename DERIVED>
    class Interface_SparseMatrix
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_SparseMatrix, DERIVED, Interface_Matrix>
#endif
    {
        using TraitsType = CRTP_TypeTraits<DERIVED>;
        using SelfType = Interface_SparseMatrix;

       public:
        using ElementType = typename TraitsType::ElementType;

       public:
        auto nonZero_size() const noexcept { return SelfType::impl().nonZero_size(); }
        auto& operator[](const Index_t nonZero_idx) const noexcept { return SelfType::impl()[nonZero_idx]; }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto& operator=(const SelfType& toCopy) const noexcept { return SelfType::impl() = toCopy.impl(); }

        auto& operator=(const ElementType& toCopy) const noexcept { return SelfType::impl() = toCopy; }
    };
}
