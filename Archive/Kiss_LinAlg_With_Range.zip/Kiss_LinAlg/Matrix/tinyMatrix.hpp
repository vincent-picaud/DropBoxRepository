#pragma once

#include <Kiss_LinAlg/Matrix/denseMatrix_implementation.hpp>
#include <Kiss_LinAlg/MemoryStructure/array2_memoryStructure.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_rawPtr.hpp>

namespace Kiss
{
    ////////////////////////////////////////////////////////////////// TinyMatrix

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Default type for TinyMatrix
         @relates DenseMatrix_Implementation

         Default type is __ColumnMajor__
    */
    template <typename T, Size_t I_SIZE, Size_t J_SIZE, typename MATRIXSHAPE_TYPE = MatrixShape_Full>
    using TinyMatrix =
        DenseMatrix_Implementation<std::integral_constant<Size_t, 0>,        // Static offset
                                   std::integral_constant<Size_t, I_SIZE>,   // Static I_size
                                   std::integral_constant<Size_t, J_SIZE>,   // Static J_size
                                   std::integral_constant<Index_t, 1>,       // ColumnMajor
                                   std::integral_constant<Index_t, I_SIZE>,  //
                                   MATRIXSHAPE_TYPE,                         // MatrixShape
                                   PreferedIndexOrderInLoop_Backward,        // Loop J, then I (for columnMajor)
                                   TinyMemoryBlock<T, I_SIZE * J_SIZE>       // Memory block
                                   >;

    /**  @ingroup Kiss_LinAlg_Matrix_Group
         @brief Default copy constructor for TinyMatrix
         @relates DenseMatrix_Implementation
    */
    template <typename OFFSET, Size_t I_SIZE, Size_t J_SIZE, typename I_STRIDE_TYPE, typename J_STRIDE_TYPE,
              typename INDEXORDERINLOOP_TYPE, typename MATRIXSHAPE_TYPE, typename MEMORY_BLOCK>
    constexpr auto create_copy(const DenseMatrix_Implementation<
        OFFSET, std::integral_constant<Size_t, I_SIZE>, std::integral_constant<Size_t, J_SIZE>, I_STRIDE_TYPE,
        J_STRIDE_TYPE, MATRIXSHAPE_TYPE, INDEXORDERINLOOP_TYPE, MEMORY_BLOCK>& toCopy) noexcept
    {
        // What is important there is that we return the default type!
        //
        TinyMatrix<typename MEMORY_BLOCK::ElementType, I_SIZE, J_SIZE, MATRIXSHAPE_TYPE> toReturn;

        cwise_copy(toReturn, toCopy);

        return toReturn;
    }
}
