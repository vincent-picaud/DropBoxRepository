#pragma once

#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock_fwd.hpp>  // hints: only use fwd from here
#include <Kiss_LinAlg/crtp.hpp>

#include <Kiss_LinAlg/Range/array_range.hpp>
#include <Kiss_LinAlg/Meta/as_const_pointer.hpp>

#include <iostream>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief MemoryBlock Interface
         @extends CRTP_Base
    */
    template <typename DERIVED>
    class Interface_MemoryBlock
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_MemoryBlock, DERIVED, CRTP_Base>
#endif
    {
       public:
        using SelfType = Interface_MemoryBlock;

        using TraitsType = CRTP_TypeTraits<DERIVED>;

        /** @brief Stored ElementType */
        using ElementType = typename TraitsType::ElementType;

        /** @brief Associated storable memory block
         */
        using StorableType = typename TraitsType::StorableType;
        //    static_assert(Is_CRTP_Interface<StorableType, Interface_MemoryBlock>::value, "");

        /** @brief Associated memory block view
         */
        using ViewType = typename TraitsType::ViewType;
        //    static_assert(Is_CRTP_Interface<ViewType, Interface_MemoryBlock>::value, "");

        /** @brief Associated memory block const view
         */
        using ViewConstType = typename TraitsType::ViewConstType;
        //    static_assert(Is_CRTP_Interface<ViewConstType, Interface_MemoryBlock>::value, "");

       public:
        /**  MemoryBlock capacity */
        constexpr auto capacity() const noexcept { return SelfType::impl().capacity(); }

        constexpr auto data() const noexcept { return SelfType::impl().data(); }

        /** Returns a view on @b constant data */
        constexpr auto view_const() const noexcept { return SelfType::impl().view_const(); }

        /** Returns a view on data */
        constexpr auto view() const noexcept { return SelfType::impl().view(); }

        typedef Array_Range<ElementType, std::integral_constant<Index_t, 1> > RangeType;

        /** Return a range */
        constexpr auto range() const noexcept { return RangeType(data(), capacity(), 1); }

        typedef Array_Range<const ElementType, std::integral_constant<Index_t, 1> > RangeConstType;

        /** Return a range */
        constexpr RangeConstType range_const() const noexcept { return RangeConstType(data(), capacity(), 1); }
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Comparison operator
         @relates Interface_MemoryBlock
    */
    template <typename D1, typename D2>
    constexpr auto operator==(const Interface_MemoryBlock<D1>& d1, const Interface_MemoryBlock<D2>& d2) noexcept
    {
        return (d1.capacity() == d2.capacity()) && ((void*)d1.data() == (void*)d2.data());
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /////////////
    // GENERIC //
    /////////////

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Performs a cwise copy deepcopy
         @relates Interface_MemoryBlock
    */
    template <typename DERIVED_DEST, typename DERIVED_SOURCE>
    void cwise_copy(const Interface_MemoryBlock<DERIVED_DEST>& memoryBlock_dest,
                    const Interface_MemoryBlock<DERIVED_SOURCE>& memoryBlock_source)
    {
        cwise_copy(memoryBlock_dest.range(), memoryBlock_source.range());
    }

    //--------------------------------------------------

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Screen print
         @relates Interface_MemoryBlock
    */
    template <typename DERIVED>
    std::ostream& operator<<(std::ostream& out, const Interface_MemoryBlock<DERIVED>& toPrint)
    {
        out << "\nMemory block data= " << std::hex << toPrint.data() << " capacity: " << std::dec << toPrint.capacity();
        out << toPrint.range_const();

        return out;
    }
}
