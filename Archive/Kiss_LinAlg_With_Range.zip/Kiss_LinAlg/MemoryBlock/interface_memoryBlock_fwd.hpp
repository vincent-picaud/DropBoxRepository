#pragma once

#include <Kiss_LinAlg/crtp.hpp>
#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
  template <typename DERIVED = CRTP_NoDerivedClassTag>
  class Interface_MemoryBlock;

  /** @ingroup Kiss_LinAlg_MemoryBlock_Group
      @brief Static check
  */
  template <typename DERIVED>
  struct MemoryBlock_Well_Defined
      : std::integral_constant<bool, (std::is_final<DERIVED>::value) &&
                                         (Is_CRTP_Interface<DERIVED, Kiss::Interface_MemoryBlock>::value)>
  {
  };

}
