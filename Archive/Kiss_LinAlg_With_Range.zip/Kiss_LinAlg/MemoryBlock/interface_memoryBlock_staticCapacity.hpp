#pragma once

#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock.hpp>

namespace Kiss
{

  /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
       @brief Static capacity memory block interface
       @extends Interface_MemoryBlock
  */
  template <typename DERIVED>
  class Interface_MemoryBlock_StaticCapacity
#ifndef DOXYGEN_DOC
      : public CRTP_Find_BaseType<Interface_MemoryBlock_StaticCapacity, DERIVED, Interface_MemoryBlock>
#endif
  {
   public:
    typedef CRTP_TypeTraits<DERIVED> TraitsType;

    static_assert(is_integral_constant<typename TraitsType::Capacity>::value, "Must define a static capacity");
    static_assert(TraitsType::Capacity::value >= 0, "Capacity must be positive");

    typedef typename TraitsType::Capacity Capacity;

   protected:
    Interface_MemoryBlock_StaticCapacity() = default;
  };

  ///////////////////////////
  // INTERFACE OVERLOADING //
  ///////////////////////////

  template <typename DERIVED>
  constexpr Size_t capacity(const Interface_MemoryBlock_StaticCapacity<DERIVED>& memoryBlock) noexcept
  {
    return Interface_MemoryBlock_StaticCapacity<DERIVED>::Capacity::value;
  }
}
