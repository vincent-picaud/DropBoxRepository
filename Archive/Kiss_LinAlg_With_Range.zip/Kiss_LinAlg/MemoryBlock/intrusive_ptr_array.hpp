#pragma once

#include <Kiss_LinAlg/indexType.hpp>

#include <boost/config.hpp>
#include <boost/serialization/array.hpp>
#include <boost/serialization/split_free.hpp>
#include <boost/serialization/version.hpp>
#include <boost/serialization/tracking.hpp>
#include <boost/serialization/nvp.hpp>

#include <boost/smart_ptr/intrusive_ptr.hpp>

namespace Kiss
{

    namespace Internal
    {

        template <typename T>
        struct MemoryChunkWithCounter
        {
            using SelfType = MemoryChunkWithCounter;

            MemoryChunkWithCounter() noexcept = default;
            explicit MemoryChunkWithCounter(const Size_t capacity) : counter_(0), toExport_{capacity, new T[capacity]}
            {
            }
            ~MemoryChunkWithCounter() { delete[] toExport_.data_; };

            MemoryChunkWithCounter(const SelfType&) = delete;
            MemoryChunkWithCounter(SelfType&&) = delete;
            SelfType& operator=(const SelfType&) = delete;
            SelfType& operator=(SelfType&&) = delete;

            Size_t counter_{0};
            struct ToExport
            {
                Size_t capacity_{0};
                T* data_{nullptr};
            } toExport_;

            template <typename ARCHIVE>
            void save(ARCHIVE& ar, const unsigned int version) const
            {
                // counter is not serialized because internaly managed during the
                // serialization process
                // -> NO "ar& BOOST_SERIALIZATION_NVP(counter_);"

                (void)version;
                ar << BOOST_SERIALIZATION_NVP(toExport_.capacity_);
                ar << boost::serialization::make_array(toExport_.data_, toExport_.capacity_);
            }
            template <typename ARCHIVE>
            void load(ARCHIVE& ar, const unsigned int version)
            {
                (void)version;
                ar >> BOOST_SERIALIZATION_NVP(toExport_.capacity_);
                if(toExport_.capacity_)
                {
                    using mutable_T = std::remove_cv_t<T>;
                    mutable_T* p = new mutable_T[toExport_.capacity_];
                    ar >> boost::serialization::make_array(p, toExport_.capacity_);
                    toExport_.data_ = p;
                }
                else
                {
                    toExport_.data_ = nullptr;
                }
            }
            template <class Archive>
            void serialize(Archive& ar, const unsigned int file_version)
            {
                boost::serialization::split_member(ar, *this, file_version);
            }
        };

        template <typename T>
        inline void intrusive_ptr_add_ref(MemoryChunkWithCounter<T>* x)
        {
            ++x->counter_;
        }
        template <typename T>
        inline void intrusive_ptr_release(MemoryChunkWithCounter<T>* x)
        {
            if(--x->counter_ == 0) delete x;
        }
    }
}

#define BOOST_SERIALIZATION_INTRUSIVE_PTR(T)          \
    BOOST_CLASS_VERSION(::boost::intrusive_ptr<T>, 1) \
    BOOST_CLASS_TRACKING(::boost::intrusive_ptr<T>, ::boost::serialization::track_never) /**/

namespace boost
{
    namespace serialization
    {
        template <typename Archive, typename T>
        BOOST_FORCEINLINE void save(Archive& ar, boost::intrusive_ptr<T> const& t, unsigned int const)
        {
            // The most common cause of trapping here would be serializing
            // something like intrusive_ptr<int>. This occurs because int
            // is never tracked by default. Wrap int in a trackable type
            BOOST_STATIC_ASSERT((tracking_level<T>::value != track_never));
            T const* ptr = t.get();
            ar << BOOST_SERIALIZATION_NVP(ptr);
        }
        template <typename Archive, typename T>
        BOOST_FORCEINLINE void load(Archive& ar, boost::intrusive_ptr<T>& t, const unsigned int)
        {
            // The most common cause of trapping here would be serializing
            // something like intrusive_ptr<int>. This occurs because int
            // is never tracked by default. Wrap int in a trackable type
            BOOST_STATIC_ASSERT((tracking_level<T>::value != track_never));
            T* ptr;
            ar >> BOOST_SERIALIZATION_NVP(ptr);
            t.reset(ptr);
        }

        template <typename Archive, typename T>
        BOOST_FORCEINLINE void serialize(Archive& ar, boost::intrusive_ptr<T>& t, unsigned int const version)
        {
            // correct intrusive_ptr serialization depends upon object tracking
            // being used.
            BOOST_STATIC_ASSERT(tracking_level<T>::value != track_never);
            boost::serialization::split_free(ar, t, version);
        }
    }
}

//    boost::intrusive_ptr<X> x(new X);
//
//    std::cout << x->name << std::endl;
