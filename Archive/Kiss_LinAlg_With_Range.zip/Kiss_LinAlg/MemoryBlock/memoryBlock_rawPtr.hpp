#pragma once

#include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock.hpp>

namespace Kiss
{
    template <typename T>
    struct CRTP_TypeTraits<MemoryBlock_RawPtr<T>>
    {
        typedef T ElementType;
        typedef UniqueMemoryBlock<std::remove_cv_t<T>> StorableType;
        typedef MemoryBlock_RawPtr<T> ViewType;
        typedef MemoryBlock_RawPtr<const T> ViewConstType;
    };

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Raw pointer view
         @extends Interface_MemoryBlock
    */
    template <typename T>
    class MemoryBlock_RawPtr final
#ifndef DOXYGEN_DOC
        : public Interface_MemoryBlock<MemoryBlock_RawPtr<T>>
#endif
    {
        using SelfType = MemoryBlock_RawPtr;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        constexpr MemoryBlock_RawPtr() noexcept = default;
        MemoryBlock_RawPtr(const Size_t required_capacity) noexcept = delete;
        constexpr MemoryBlock_RawPtr(T* data, const Size_t capacity) noexcept : capacity_(capacity), data_(data){};

        constexpr Size_t capacity() const noexcept { return capacity_; }
        constexpr T* data() const noexcept { return data_; }

        constexpr auto view_const() const noexcept { return typename TraitsType::ViewConstType(capacity_, data_); }

        constexpr auto view() const noexcept { return typename TraitsType::ViewType(capacity_, data_); }

        bool check_invariant() const noexcept { return ((capacity_ > 0) && (data_ != nullptr)) || (capacity_ == 0); };

       protected:
        Size_t capacity_;
        T* data_;

       private:
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Serialization: not serializable
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        template <typename ARCHIVE>
        void serialize(ARCHIVE&, const unsigned int) = delete;
    };
}
