#pragma once

#include <Kiss_LinAlg/MemoryBlock/sharedMemoryBlock_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock.hpp>

#include <Kiss_LinAlg/MemoryBlock/intrusive_ptr_array.hpp>

namespace Kiss
{

    template <typename T>
    struct CRTP_TypeTraits<SharedMemoryBlock<T>>
    {
        typedef T ElementType;
        typedef SharedMemoryBlock<std::remove_cv_t<T>> StorableType;
        typedef SharedMemoryBlock<T> ViewType;
        typedef SharedMemoryBlock<const T> ViewConstType;
    };

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Concrete static size memory block using std::array
         @extends Interface_MemoryBlock
    */
    template <typename T>
    class SharedMemoryBlock final
#ifndef DOXYGEN_DOC
        : public Interface_MemoryBlock<SharedMemoryBlock<T>>
#endif
    {
        using SelfType = SharedMemoryBlock;
        using TraitsType = CRTP_TypeTraits<SelfType>;
        // Mandatory to manage in the same way const T and T
        using MemoryChunk = Internal::MemoryChunkWithCounter<std::remove_cv_t<T>>;
        using Shared_Data_ToExport_Type = typename MemoryChunk::ToExport;
        using Shared_Data_Type = boost::intrusive_ptr<MemoryChunk>;
        friend class SharedMemoryBlock<std::remove_cv_t<T>>;

       protected:
        SharedMemoryBlock(const Shared_Data_Type& shared_data, const Shared_Data_ToExport_Type& exported) noexcept
            : shared_data_(shared_data),
              exported_(exported)
        {
            assert(check_invariant());
        };

        SharedMemoryBlock<T>& operator=(const SharedMemoryBlock<T>& toCopy) noexcept = delete;

       public:
        SharedMemoryBlock() noexcept = default;

        explicit SharedMemoryBlock(const Size_t required_capacity)
            : shared_data_((required_capacity > 0) ? new MemoryChunk(required_capacity) : nullptr)
            , exported_((required_capacity > 0) ? shared_data_.get()->toExport_ : Shared_Data_ToExport_Type{})
        {
            assert(check_invariant());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        SharedMemoryBlock(SharedMemoryBlock<T>&& toMove) noexcept : shared_data_(toMove.shared_data_),
                                                                    exported_(toMove.exported_)
        {
            assert(check_invariant());
        };

        SharedMemoryBlock<T>& operator=(SharedMemoryBlock<T>&& toMove) noexcept
        {
            shared_data_ = toMove.shared_data_;
            exported_ = toMove.toExport_;

            assert(check_invariant());

            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Extra methods
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        Size_t use_count() const noexcept
        {
            return (shared_data_.get() == nullptr) ? 0 : shared_data_.get()->counter_;
        };

        void reset() noexcept
        {
            shared_data_.reset();
            exported_ = Shared_Data_ToExport_Type{};
            assert(check_invariant());
        }

        bool check_invariant() const noexcept
        {
            bool ok = true;

            if(shared_data_.get() == nullptr)
            {
                ok &= (exported_.capacity_ == 0);
                ok &= (exported_.data_ == nullptr);
            }
            else
            {
                ok &= (exported_.capacity_ == shared_data_.get()->toExport_.capacity_);
                ok &= (exported_.data_ == shared_data_.get()->toExport_.data_);
            };
            return ok;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Interface
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr Size_t capacity() const noexcept { return exported_.capacity_; }
        constexpr T* data() const noexcept { return exported_.data_; }

        constexpr auto view_const() const noexcept
        {
            return typename TraitsType::ViewConstType(shared_data_, exported_);
        }

        constexpr auto view() const noexcept { return typename TraitsType::ViewType(shared_data_, exported_); }

       protected:
        Shared_Data_Type shared_data_;
        // Avoid one indirection
        Shared_Data_ToExport_Type exported_;

       private:
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Serialization
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        friend class boost::serialization::access;
        template <typename ARCHIVE>
        void save(ARCHIVE& ar, const unsigned int version) const
        {
            (void)version;
            ar << BOOST_SERIALIZATION_NVP(shared_data_);
        }
        template <typename ARCHIVE>
        void load(ARCHIVE& ar, const unsigned int version)
        {
            (void)version;
            ar >> BOOST_SERIALIZATION_NVP(shared_data_);

            if(shared_data_.get() == nullptr)
            {
                exported_ = Shared_Data_ToExport_Type{};
            }
            else
            {
                exported_ = shared_data_.get()->toExport_;
            };
        }
        template <class Archive>
        void serialize(Archive& ar, const unsigned int file_version)
        {
            boost::serialization::split_member(ar, *this, file_version);
        }
    };
}
