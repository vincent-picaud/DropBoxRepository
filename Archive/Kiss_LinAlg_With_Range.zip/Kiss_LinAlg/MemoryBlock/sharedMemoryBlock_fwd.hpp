#pragma once

#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
  template <typename T>
  class SharedMemoryBlock;
}
