#pragma once

#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock_staticCapacity.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_rawPtr.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>
#include <array>

namespace Kiss
{

    //! [[CaveatTypeTraitsView]]
    template <typename T, Size_t CAPACITY>
    struct CRTP_TypeTraits<TinyMemoryBlock<T, CAPACITY> >
    {
        typedef T ElementType;
        typedef TinyMemoryBlock<std::remove_cv_t<T>, CAPACITY> StorableType;
        typedef TinyMemoryBlock_RawPtr<T, CAPACITY> ViewType;
        typedef TinyMemoryBlock_RawPtr<const T, CAPACITY> ViewConstType;

        typedef std::integral_constant<Size_t, CAPACITY> Capacity;
    };
    //! [[CaveatTypeTraitsView]]

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Concrete static size memory block using std::array
         @extends Interface_MemoryBlock_StaticCapacity
    */
    template <typename T, Size_t CAPACITY>
    class TinyMemoryBlock final
#ifndef DOXYGEN_DOC
        : public Interface_MemoryBlock_StaticCapacity<TinyMemoryBlock<T, CAPACITY> >
#endif
    {
        using SelfType = TinyMemoryBlock;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        /** @brief Default constructor

            @attention this constructor must stay @b "default" otherwise
            this object is not a literal anymore (forbid @b constexpr use)
        */
        TinyMemoryBlock() noexcept = default;
        TinyMemoryBlock(const Size_t required_capacity) noexcept
        {
            assert((required_capacity >= 0) && (required_capacity <= CAPACITY));
        }
        TinyMemoryBlock(const T* p, const T* p_end) noexcept
        {
            assert(p_end - p <= CAPACITY);
            std::copy(p, p_end, data_.data());
        }

        constexpr auto capacity() const noexcept { return Static_Integer<CAPACITY>; }

        T* data() const noexcept { return data_.data(); }

        constexpr auto view_const() const noexcept { return typename TraitsType::ViewConstType(data_.data()); }

        constexpr auto view() const noexcept { return typename TraitsType::ViewType(data_.data()); }

       protected:
        // CAVEAT: Mutable because we want to mimic pointer:
        // method: data() const
        // must return "T*" and not "const T*"
        //
        typedef std::array<std::remove_cv_t<T>, CAPACITY> DataType;
        mutable DataType data_{};
    };
}
