#pragma once

#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_rawPtr_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_fwd.hpp>

#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock_staticCapacity.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>
#include <array>

namespace Kiss
{
    template <typename T, Size_t CAPACITY>
    struct CRTP_TypeTraits<TinyMemoryBlock_RawPtr<T, CAPACITY> >
    {
        typedef T ElementType;
        typedef TinyMemoryBlock<std::remove_cv_t<T>, CAPACITY> StorableType;
        typedef TinyMemoryBlock_RawPtr<T, CAPACITY> ViewType;
        typedef TinyMemoryBlock_RawPtr<const T, CAPACITY> ViewConstType;

        typedef std::integral_constant<Size_t, CAPACITY> Capacity;
    };

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Raw pointer view
         @extends Interface_MemoryBlock_StaticCapacity
    */
    template <typename T, Size_t CAPACITY>
    class TinyMemoryBlock_RawPtr final
#ifndef DOXYGEN_DOC
        : public Interface_MemoryBlock_StaticCapacity<TinyMemoryBlock_RawPtr<T, CAPACITY> >
#endif
    {
        static_assert(CAPACITY >= 0, "");

        using SelfType = TinyMemoryBlock_RawPtr;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        constexpr TinyMemoryBlock_RawPtr() noexcept = default;
        constexpr TinyMemoryBlock_RawPtr(const Size_t required_capacity) noexcept
        {
            assert(required_capacity <= CAPACITY);
        }
        TinyMemoryBlock_RawPtr(T* data) noexcept : data_(data){};

        constexpr T* data() const noexcept { return data_; }
        constexpr auto capacity() const noexcept { return Static_Integer<CAPACITY>; }

        constexpr auto view_const() const noexcept { return typename TraitsType::ViewConstType(data_); }

        constexpr auto view() const noexcept { return typename TraitsType::ViewType(data_); }

       protected:
        T* data_;

        //==================================================
        // Interface overloading
        //==================================================

        // friend typename TraitsType::StorableType storable(const SelfType& self) noexcept
        // {
        //   return typename TraitsType::StorableType(self.data_, self.data_ + CAPACITY);
        // }
    };
}
