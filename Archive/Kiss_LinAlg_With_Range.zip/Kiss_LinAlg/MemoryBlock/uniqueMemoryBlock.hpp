#pragma once

#include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock.hpp>

#include <boost/serialization/array.hpp>

//#include <memory>

namespace Kiss
{

    template <typename T>
    struct CRTP_TypeTraits<UniqueMemoryBlock<T>>
    {
        typedef T ElementType;
        typedef UniqueMemoryBlock<std::remove_cv_t<T>> StorableType;
        typedef MemoryBlock_RawPtr<T> ViewType;
        typedef MemoryBlock_RawPtr<const T> ViewConstType;
    };

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Concrete static size memory block using std::array
         @extends Interface_MemoryBlock
    */
    template <typename T>
    class UniqueMemoryBlock final
#ifndef DOXYGEN_DOC
        : public Interface_MemoryBlock<UniqueMemoryBlock<T>>
#endif
    {
        using SelfType = UniqueMemoryBlock;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        UniqueMemoryBlock() noexcept : capacity_{0}, data_{nullptr} {}

        explicit UniqueMemoryBlock(const Size_t required_capacity)
            : capacity_(required_capacity), data_(new std::remove_cv_t<T>[required_capacity])
        {
            assert(required_capacity >= 0);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** Copy is not allowed!!! */
        UniqueMemoryBlock(const UniqueMemoryBlock<T>& toCopy) = delete;
        UniqueMemoryBlock<T>& operator=(const UniqueMemoryBlock<T>& toCopy) = delete;

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        UniqueMemoryBlock(UniqueMemoryBlock<T>&& toMove)
        {
            data_ = toMove.data_;
            capacity_ = toMove.capacity_;

            toMove.capacity_ = 0;
            toMove.data_ = nullptr;

            assert(check_invariant());
        }

        UniqueMemoryBlock<T>& operator=(UniqueMemoryBlock<T>&& toMove)
        {
            delete[] data_;
            data_ = toMove.data_;
            capacity_ = toMove.capacity_;

            toMove.capacity_ = 0;
            toMove.data_ = nullptr;

            assert(check_invariant());
            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        ~UniqueMemoryBlock()
        {
            delete[] data_;
            capacity_ = 0;
            data_ = nullptr;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr Size_t capacity() const noexcept { return capacity_; }
        constexpr T* data() const noexcept { return data_; }

        constexpr auto view_const() const noexcept { return typename TraitsType::ViewConstType(data_, capacity_); }

        constexpr auto view() const noexcept { return typename TraitsType::ViewType(data_, capacity_); }

        bool check_invariant() const { return ((capacity_ > 0) && (data_ != nullptr)) || (capacity_ == 0); }

       protected:
        Size_t capacity_;
        T* data_;

       private:
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Serialization
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        friend class boost::serialization::access;

        template <typename ARCHIVE>
        void save(ARCHIVE& ar, const unsigned int version) const
        {
            (void)version;
            ar << BOOST_SERIALIZATION_NVP(capacity_);
            ar << boost::serialization::make_array(data_, capacity_);
        }
        template <typename ARCHIVE>
        void load(ARCHIVE& ar, const unsigned int version)
        {
            (void)version;
            ar >> BOOST_SERIALIZATION_NVP(capacity_);
            if(capacity_)
            {
                using mutable_T = std::remove_cv_t<T>;
                mutable_T* p = new mutable_T[capacity_];
                ar >> boost::serialization::make_array(p, capacity_);
                data_ = p;
            }
            else
            {
                data_ = nullptr;
            }
        }
        template <class Archive>
        void serialize(Archive& ar, const unsigned int file_version)
        {
            boost::serialization::split_member(ar, *this, file_version);
        }
    };
}
