#pragma once

#include <Kiss_LinAlg/MemoryStructure/array2_memoryStructure_fwd.hpp>

#include <Kiss_LinAlg/MemoryStructure/interface_array2_memoryStructure.hpp>
#include <Kiss_LinAlg/Range/array_range.hpp>

namespace Kiss
{

    template <typename OFFSET_TYPE, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXUPLOW_TYPE, typename INDEXORDERINLOOP_TYPE>
    struct CRTP_TypeTraits<Array2_MemoryStructure<OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                                  MATRIXUPLOW_TYPE, INDEXORDERINLOOP_TYPE>>
    {
        // Offset
        typedef DynStatValue<OFFSET_TYPE> Offset_Type;

        // Size & Stride
        typedef DynStatValue<I_SIZE_TYPE> I_Size_Type;
        typedef DynStatValue<J_SIZE_TYPE> J_Size_Type;

        typedef DynStatValue<I_STRIDE_TYPE> I_Stride_Type;
        typedef DynStatValue<J_STRIDE_TYPE> J_Stride_Type;

        // IndexOrder
        typedef INDEXORDERINLOOP_TYPE IndexOrderInLoopType;

        // UpLow
        typedef MATRIXUPLOW_TYPE MatrixUpLowType;

        using TransposedType = Array2_MemoryStructure<OFFSET_TYPE, J_SIZE_TYPE, I_SIZE_TYPE, J_STRIDE_TYPE,
                                                      I_STRIDE_TYPE, typename MATRIXUPLOW_TYPE::TransposedType,
                                                      typename INDEXORDERINLOOP_TYPE::TransposedType>;
    };

    /**  @ingroup Kiss_LinAlg_MatrixStructure_Group
         @brief Regular matrix structure implementation
         @extends Interface_Array2_MemoryStructure
    */
    template <typename OFFSET_TYPE, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXUPLOW_TYPE, typename INDEXORDERINLOOP_TYPE>
    class Array2_MemoryStructure final
#ifndef DOXYGEN_DOC
        : public Interface_Array2_MemoryStructure<
              Array2_MemoryStructure<OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                     MATRIXUPLOW_TYPE, INDEXORDERINLOOP_TYPE>>
#endif
    {
        using SelfType = Array2_MemoryStructure;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        using Offset_Type = typename TraitsType::Offset_Type;
        using I_Size_Type = typename TraitsType::I_Size_Type;
        using J_Size_Type = typename TraitsType::J_Size_Type;

        using I_Stride_Type = typename TraitsType::I_Stride_Type;
        using J_Stride_Type = typename TraitsType::J_Stride_Type;

        using TransposedType = typename TraitsType::TransposedType;

       public:
        constexpr Array2_MemoryStructure() noexcept : offset_(), I_size_(), J_size_(), I_stride_(), J_stride_()
        {
            assert(check_invariant());
        }

        constexpr Array2_MemoryStructure(const Index_t offset, const Size_t I_size, const Size_t J_size,
                                         const Size_t I_stride, const Size_t J_stride) noexcept : offset_(offset),
                                                                                                  I_size_(I_size),
                                                                                                  J_size_(J_size),
                                                                                                  I_stride_(I_stride),
                                                                                                  J_stride_(J_stride)
        {
            assert(check_invariant());
        }

        constexpr Array2_MemoryStructure(const SelfType& toCopy) noexcept = default;

        //~~~~~~~~~~~~~~~~

        constexpr OFFSET_TYPE offset() const noexcept { return offset_; }

        constexpr I_SIZE_TYPE I_size() const noexcept { return I_size_; }
        constexpr J_SIZE_TYPE J_size() const noexcept { return J_size_; }
        constexpr I_STRIDE_TYPE I_stride() const noexcept { return I_stride_; }
        constexpr J_STRIDE_TYPE J_stride() const noexcept { return J_stride_; }

        constexpr TransposedType transposed() const noexcept
        {
            return TransposedType(offset_(), J_size_(), I_size_(), J_stride_(), I_stride_());
        }

        constexpr bool check_invariant() const noexcept
        {
            bool ok = true;
            const bool is_empty = (I_size_ == 0) && (J_size_ == 0);
            const bool is_not_empty = (I_size_ != 0) && (J_size_ != 0);

            ok &= is_empty || is_not_empty;
            ok &= (is_empty && (I_stride_ >= 0) && (J_stride_ >= 0)) ||
                  (is_not_empty && ((I_stride_ >= J_size_ * J_stride_) || (J_stride_ >= I_size_ * I_stride_)));
            return ok;
        }

       protected:
        Offset_Type offset_;
        I_Size_Type I_size_;
        J_Size_Type J_size_;
        I_Stride_Type I_stride_;
        J_Stride_Type J_stride_;
    };

    /**  @ingroup Kiss_LinAlg_MatrixStructure_Group
         @brief Create a Interface_Array2_MemoryStructure
         @extends Interface_Array2_MemoryStructure
    */
    template <typename OFFSET_TYPE, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXUPLOW_TYPE, typename INDEXORDERINLOOP_TYPE,
              typename = std::enable_if_t<Is_DynStatArgument<Integer_Common_t, OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE,
                                                             I_STRIDE_TYPE, J_STRIDE_TYPE>::value &&
                                          MatrixUpLow_Well_Defined<MATRIXUPLOW_TYPE> &&
                                          PreferedIndexOrderInLoop_Well_Defined<INDEXORDERINLOOP_TYPE>>>
    constexpr auto create_array2_memoryStructure(const OFFSET_TYPE offset, const I_SIZE_TYPE I_size,
                                                 const J_SIZE_TYPE J_size, const I_STRIDE_TYPE I_stride,
                                                 const J_STRIDE_TYPE J_stride, const MATRIXUPLOW_TYPE,
                                                 const INDEXORDERINLOOP_TYPE) noexcept
    {
        return Array2_MemoryStructure<OFFSET_TYPE, I_SIZE_TYPE, J_SIZE_TYPE, I_STRIDE_TYPE, J_STRIDE_TYPE,
                                      MATRIXUPLOW_TYPE, INDEXORDERINLOOP_TYPE>(offset, I_size, J_size, I_stride,
                                                                               J_stride);
    }
};
