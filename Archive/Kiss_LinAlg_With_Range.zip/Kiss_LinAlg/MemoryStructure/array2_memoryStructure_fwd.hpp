// This forward declaration is used by array2_range
//
#pragma once

#include <Kiss_LinAlg/Tag/indexOrderInLoop.hpp>
#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>

namespace Kiss
{
    template <typename OFFSET, typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_STRIDE_TYPE,
              typename J_STRIDE_TYPE, typename MATRIXUPLOW_TYPE = MatrixUpLow_Irrelevant,
              typename INDEXORDERINLOOP_TYPE = PreferedIndexOrderInLoop_Backward>
    class Array2_MemoryStructure;
}
