#pragma once

#include <Kiss_LinAlg/MemoryStructure/array_memoryStructure_fwd.hpp>

#include <Kiss_LinAlg/MemoryStructure/interface_array_memoryStructure.hpp>
#include <Kiss_LinAlg/Range/array_range.hpp>

#include <Kiss_LinAlg/Meta/integral_constant_manip.hpp>

namespace Kiss
{
    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE>
    struct CRTP_TypeTraits<Array_MemoryStructure<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE> >
    {
    };

    /**  @ingroup Kiss_LinAlg_MatrixStructure_Group
         @brief Regular matrix structure implementation
         @extends Interface_Array_MemoryStructure
    */
    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE>
    class Array_MemoryStructure final
#ifndef DOXYGEN_DOC
        : public Interface_Array_MemoryStructure<Array_MemoryStructure<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE> >
#endif
    {
       public:
        using SelfType = Array_MemoryStructure;
        using TraitsType = CRTP_TypeTraits<SelfType>;

       public:
        constexpr Array_MemoryStructure() noexcept : offset_(), size_(), stride_() { assert(check_invariant()); }

        constexpr Array_MemoryStructure(const Index_t offset, const Size_t size, const Size_t stride) noexcept
            : offset_(offset),
              size_(size),
              stride_(stride)
        {
            assert(check_invariant());
        }

        constexpr Array_MemoryStructure(const SelfType& toCopy) noexcept = default;

        constexpr bool check_invariant() const noexcept
        {
            bool ok = true;

            ok &= (size_ == 0) || ((size_ >= 0) && (stride_() > 0));

            return ok;
        }

        // CAVEAT: for these functions are important to explictly defines return type
        // (we do not want DynStatValue<OFFSET_TYPE> nor DynStatValue<OFFSET_TYPE>::value_type,
        //  but the original OFFSET_TYPE type )
        //
        constexpr OFFSET_TYPE offset() const noexcept { return offset_; }
        constexpr SIZE_TYPE size() const noexcept { return size_; };
        constexpr STRIDE_TYPE stride() const noexcept { return stride_; }

       protected:
        DynStatValue<OFFSET_TYPE> offset_;
        DynStatValue<SIZE_TYPE> size_;
        DynStatValue<STRIDE_TYPE> stride_;
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <typename OFFSET_1_TYPE, typename SIZE_1_TYPE, typename STRIDE_1_TYPE, typename OFFSET_2_TYPE,
              typename SIZE_2_TYPE, typename STRIDE_2_TYPE>
    constexpr bool operator==(const Array_MemoryStructure<OFFSET_1_TYPE, SIZE_1_TYPE, STRIDE_1_TYPE>& d1,
                              const Array_MemoryStructure<OFFSET_2_TYPE, SIZE_2_TYPE, STRIDE_2_TYPE>& d2) noexcept
    {
        return (d1.size() == d2.size()) && (d1.stride() == d2.stride()) && (d1.offset() == d2.offset());
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    // Maybe uncomment

    // template <typename T, typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE>
    // constexpr auto create_range(
    //     T* p, const Array_MemoryStructure<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE>& array_memoryStructure) noexcept
    // {
    //     typedef Array_Range<T, STRIDE_TYPE> Range_To_Return;

    //     return Range_To_Return(p + array_memoryStructure)
    //         .offset_index(size(array_memoryStructure), stride(array_memoryStructure));
    // }
};
