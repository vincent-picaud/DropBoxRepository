// This forward declaration is used by array_range
//
#pragma once

namespace Kiss
{
  template <typename OFFSET, typename SIZE_TYPE, typename STRIDE_TYPE>
  class Array_MemoryStructure;
}
