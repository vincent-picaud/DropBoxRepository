#pragma once

#include <Kiss_LinAlg/MemoryStructure/interface_memoryStructure.hpp>
#include <Kiss_LinAlg/Meta/placeHolder.hpp>
#include <Kiss_LinAlg/Tag/indexOrderInLoop.hpp>
#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>

#include <Kiss_LinAlg/Meta/dynStatValue.hpp>  // for static_integer

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_MemoryStructure_Group
         @brief Regular 2D-Array
         @extends Interface_MemoryStructure
    */
    template <typename DERIVED>
    class Interface_Array2_MemoryStructure
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Array2_MemoryStructure, DERIVED, Interface_MemoryStructure>
#endif
    {
        using SelfType = Interface_Array2_MemoryStructure;
        using TraitsType = CRTP_TypeTraits<DERIVED>;

       public:
        //!@{
        /** @name Define Size and Strides dynamic/static specialization
         */
        using Offset_Type = typename TraitsType::Offset_Type;

        using I_Size_Type = typename TraitsType::I_Size_Type;
        using J_Size_Type = typename TraitsType::J_Size_Type;

        using I_Stride_Type = typename TraitsType::I_Stride_Type;
        using J_Stride_Type = typename TraitsType::J_Stride_Type;
        //!@}

        /** Define index order in loop
         */
        typedef typename TraitsType::IndexOrderInLoopType IndexOrderInLoopType;
        static_assert(std::is_base_of<PreferedIndexOrderInLoop_Base, IndexOrderInLoopType>::value, "");

        /** Define UpLow specialization
         */
        typedef typename TraitsType::MatrixUpLowType MatrixUpLowType;
        static_assert(std::is_same<MatrixUpLowType, MatrixUpLow_Lower>::value ||
                          std::is_same<MatrixUpLowType, MatrixUpLow_LowerStrict>::value ||
                          std::is_same<MatrixUpLowType, MatrixUpLow_Upper>::value ||
                          std::is_same<MatrixUpLowType, MatrixUpLow_UpperStrict>::value ||
                          std::is_same<MatrixUpLowType, MatrixUpLow_Irrelevant>::value,
                      "Unsupported type");

        constexpr auto offset() const noexcept { return SelfType::impl().offset(); }

        template <typename I_INDEX_TYPE, typename J_INDEX_TYPE,
                  typename = SFINEA_DynStatArgument<Integer_Common_t, I_INDEX_TYPE, J_INDEX_TYPE> >
        constexpr auto offset_index(const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) const noexcept
        {
            return offset() + I_idx * I_stride() + J_idx * J_stride();
        }
        constexpr auto I_size() const noexcept { return SelfType::impl().I_size(); }
        constexpr auto J_size() const noexcept { return SelfType::impl().J_size(); }
        constexpr auto I_stride() const noexcept { return SelfType::impl().I_stride(); }
        constexpr auto J_stride() const noexcept { return SelfType::impl().J_stride(); }

        constexpr auto transposed() const noexcept { return SelfType::impl().transposed(); }

        constexpr bool check_index(const Index_t I_idx, const Index_t J_idx) const noexcept
        {
            return Kiss::check_index(MatrixUpLowType(), I_size(), J_size(), I_idx, J_idx);
        }

        constexpr auto required_capacity() const noexcept
        {
            return integral_constant_max(Static_Integer<0>,
                                         offset_index(I_size() - Static_Integer<1>,
                                                      J_size() - Static_Integer<1>)+Static_Integer<1>);
        }
    };
}
