#pragma once

#include <Kiss_LinAlg/MemoryStructure/interface_memoryStructure.hpp>
#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_MemoryStructure_Group
         @brief Regular 1D-Array
         @extends Interface_MemoryStructure
    */
    template <typename DERIVED>
    class Interface_Array_MemoryStructure
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Array_MemoryStructure, DERIVED, Interface_MemoryStructure>
#endif
    {
        using SelfType = Interface_Array_MemoryStructure;
        using TraitsType = CRTP_TypeTraits<DERIVED>;

       public:
        /** Offset */
        constexpr auto offset() const noexcept { return SelfType::impl().offset(); }
        /** Offset */
        template <typename INDEX_TYPE, typename = SFINEA_DynStatArgument<Integer_Common_t, INDEX_TYPE> >
        constexpr auto offset_index(const INDEX_TYPE idx) const noexcept
        {
            return offset() + idx * stride();
        }

        /** Size */
        constexpr auto size() const noexcept { return SelfType::impl().size(); }
        /** Stride */
        constexpr auto stride() const noexcept { return SelfType::impl().stride(); }

        template <typename INDEX_TYPE, typename = SFINEA_DynStatArgument<Index_t, INDEX_TYPE> >
        constexpr auto check_index(const INDEX_TYPE idx) const noexcept
        {
            return (idx >= Static_Integer<0>) && (idx < size());
        }

        constexpr auto required_capacity() const noexcept
        {
            return integral_constant_max(Static_Integer<0>, offset_index(size() - Static_Integer<1>) + Static_Integer<1>);
        }
    };

    //
    //////////////////////////////////////////////////////////////////
    //  MULTIPLE-DISPATCH
    //////////////////////////////////////////////////////////////////
    //

    template <typename T, typename DERIVED>
    constexpr auto create_range(T* p, const Interface_Array_MemoryStructure<DERIVED>& memoryStructure) noexcept
    {
        return create_range(p, memoryStructure.impl());
    }
}
