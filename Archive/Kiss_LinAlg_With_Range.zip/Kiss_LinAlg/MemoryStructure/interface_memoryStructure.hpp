#pragma once

#include <Kiss_LinAlg/crtp.hpp>
#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_MemoryStructure_Group
         @brief Memory structure interace

         # Role

         Define how data is stored into memory. To be used later in
         conjuction with an Interface_MemoryBlock.
    */
    template <typename DERIVED = CRTP_NoDerivedClassTag>
    class Interface_MemoryStructure
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_MemoryStructure, DERIVED, CRTP_Base>
#endif
    {
       public:
        using SelfType = Interface_MemoryStructure;

       protected:
        constexpr Interface_MemoryStructure() noexcept = default;

       public:
        /** @brief Returns required capacity needed to store data
         */
        constexpr auto required_capacity() const noexcept { return SelfType::required_capacity(); }
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**  @ingroup Kiss_LinAlg_MemoryStructure_Group
         @brief Comparison operator
         @relates Interface_MemoryStructure
    */
    template <typename D1, typename D2>
    constexpr auto operator==(const Interface_MemoryStructure<D1>& d1, const Interface_MemoryStructure<D2>& d2) noexcept
    {
        return d1.impl() == d2.impl();
    }

}
