#pragma once

namespace Kiss
{
  // C++17
  // http://en.cppreference.com/w/cpp/utility/as_const
  //
  template <class T>
  constexpr std::add_const_t<T>& as_const(T& t) noexcept
  {
    return t;
  }

  template <class T>
  void as_const(const T&&) = delete;
}
