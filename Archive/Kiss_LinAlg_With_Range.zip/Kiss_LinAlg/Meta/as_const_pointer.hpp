#pragma once

namespace Kiss
{

  template <class T>
  constexpr const T* as_const_pointer(const T* t) noexcept
  {
    return t;
  }
  
  template <class T>
  constexpr const T* as_const_pointer(T* t) noexcept
  {
    return t;
  }
}
