#pragma once

#include <type_traits>

namespace Kiss
{
    template <typename ANY_CLASS>
    struct DifferedFalse : std::integral_constant<bool, false>
    {
    };
}
