#pragma once

#include <Kiss_LinAlg/Meta/is_integral_constant.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>

// CAVEAT:
// This include is really important because it modifies the semantic of:
// std::integral_constant<Index_t, 3>  + std::integral_constant<Index_t, 3>
// which is, after including integral_constant_manip.hpp
// std::integral_constant<Index_t, 6>
// (otherwise implicit conversion is used and the type of
//  std::integral_constant<Index_t, 3>  + std::integral_constant<Index_t, 3>
//  is Index_t)
//
#include <Kiss_LinAlg/Meta/integral_constant_manip.hpp>

#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
//////////////////////////////////////////////////////////////////

#ifdef DOXYGEN_DOC
    /** @ingroup Kiss_LinAlg_Meta_DynStat_Group
        @brief Check if a type is allowed to be used in conjunction with DynStatValue
        @relates DynStatValue

        @returns
        - **true** if TO_TEST = LITERAL_TYPE or std::integral_constant<LITERAL_TYPE, VALUE>
        - **false** otherwise
     */
    template <typename LITERAL_TYPE, typename TO_TEST>
    struct DynStatArgument_Well_Defined;
#else
    template <typename LITERAL_TYPE, typename TO_TEST>
    struct DynStatArgument_Well_Defined : std::false_type
    {
    };

    template <typename LITERAL_TYPE>
    struct DynStatArgument_Well_Defined<LITERAL_TYPE, LITERAL_TYPE>
        : std::integral_constant<bool, std::is_literal_type<LITERAL_TYPE>::value>
    {
    };

    template <typename LITERAL_TYPE, LITERAL_TYPE VALUE>
    struct DynStatArgument_Well_Defined<LITERAL_TYPE, std::integral_constant<LITERAL_TYPE, VALUE> > : std::true_type
    {
    };
#endif

#ifdef DOXYGEN_DOC
    /** @ingroup Kiss_LinAlg_Meta_DynStat_Group
        @brief Contains a static or a dynamic value

        Two kinds of specialization:
        - static value specialization: DynStatValue<std::integral_constant<TYPE, VALUE> >
        - dynamic value specialization: DynStatValue<TYPE>

        Examples:
        @code
        DynStatValue<std::integral_constant<Index_t, 3> > static_index;
        DynStatValue<Index_t> dynamic_index;
        @endcode
    */
    template <typename DYNSTAT_TYPE>
    class DynStatValue
    {
        static_assert(DynStatArgument_Well_Defined<DYNSTAT_TYPE>::value, "");

       public:
        typedef value_type;  //!< value type
        typedef is_static;   //!< std::false_type or std::true_type

        /** @brief Implicit conversion operator */
        constexpr operator value_type() const noexcept;
        /** @brief Access value */
        constexpr value_type operator()() const noexcept;

        /** @brief Default constructor

            @note if dynamic value, the __value{}__ default constructor is
            used (zero filling for an integer)
         */
        constexpr DynStatValue() noexcept : value_() {}

        /** @brief Build from a given value

            For __static__ case, copy constructor is remplaced by

            @code assert(value == VALUE); @endcode
        */
        constexpr DynStatValue(const value_type& value) noexcept;
    };
#else

    template <typename DYNSTAT_TYPE>
    class DynStatValue
    {
       public:
        using value_type = typename is_integral_constant<DYNSTAT_TYPE>::value_type;
        using is_static = std::false_type;

        constexpr operator value_type() const noexcept { return value_; }
        constexpr value_type operator()() const noexcept { return value_; }

        // Fake constructor use for unification with the static case
        constexpr DynStatValue() noexcept : value_() {}
        // Default constructor
        constexpr DynStatValue(const value_type& value) noexcept : value_(value) {}

       protected:
        value_type value_;
    };

    template <typename DYNSTAT_TYPE, DYNSTAT_TYPE VALUE>
    class DynStatValue<std::integral_constant<DYNSTAT_TYPE, VALUE> >
        : public std::integral_constant<DYNSTAT_TYPE, VALUE>
    {
       public:
        using value_type = typename std::integral_constant<DYNSTAT_TYPE, VALUE>::value_type;
        using is_static = std::true_type;

       public:
        // Default constructor
        constexpr DynStatValue() noexcept = default;
        // Fake constructor use for unification with the dynamic case
        constexpr DynStatValue(const value_type& value) noexcept { assert(value == VALUE); }
    };
#endif

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    // Used by SFINEA
    //
    template <typename TYPE, typename... TO_TEST>
    using Is_DynStatArgument = Conjunction<DynStatArgument_Well_Defined<TYPE, TO_TEST>...>;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <typename TYPE, typename... TO_TEST>
    using SFINEA_DynStatArgument = std::enable_if_t<Is_DynStatArgument<TYPE, TO_TEST...>::value>;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <bool V>
    void dynStat_assert(const std::integral_constant<bool, V>&)
    {
        static_assert(V, "");
    }

    void dynStat_assert(const bool v) { assert(v); }
}
