/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Fri Apr 29 15:39:57 CEST 2016
*/

#pragma once

#include <type_traits>

namespace Kiss
{
    template <typename... D>
    using ElementType_t = std::common_type_t<typename D::ElementType...>;

    template <typename... D>
    using No_CV_ElementType_t = std::remove_cv_t<ElementType_t<D...>>;

} /* Kiss */
