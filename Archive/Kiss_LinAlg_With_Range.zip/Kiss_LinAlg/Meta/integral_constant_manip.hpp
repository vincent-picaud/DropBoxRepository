/** 
 * @ingroup Kiss_LinAlg_Meta_DynStat_Group
 * @file
 * @brief Defines "static" arithmetic
 */

#pragma once

#include <Kiss_LinAlg/indexType.hpp>

#include <type_traits>

namespace Kiss
{

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    // CAVEAT: expressions like "5 + std::integral_constant<int, 2>()" already behave as expected
    //         the only required specialization is:
    //         std::integral_constant<int, 2> + std::integral_constant<int, 2> -> std::integral_constant<int, 4>
    //         in order to preserve the "compile time" constant semantic
    // Note: if not specialization is provided we have:
    //       std::integral_constant<int, 2> + std::integral_constant<int, 2> -> int
    //

    //~~~~~~~~~~~~~~~~ Unary Op

    template <typename T1, T1 V1>
    constexpr auto operator!(const std::integral_constant<T1, V1>&)
    {
        return std::integral_constant<T1, !V1>();
    }
    template <typename T1, T1 V1>
    constexpr auto operator-(const std::integral_constant<T1, V1>&)
    {
        return std::integral_constant<T1, -V1>();
    }
    template <typename T1, T1 V1>
    constexpr auto operator++(const std::integral_constant<T1, V1>&)
    {
        return std::integral_constant<T1, ++V1>();
    }
    template <typename T1, T1 V1>
    constexpr auto operator--(const std::integral_constant<T1, V1>&)
    {
        return std::integral_constant<T1, --V1>();
    }
    template <typename T1, T1 V1>
    constexpr auto operator++(const std::integral_constant<T1, V1>&, int)
    {
        return std::integral_constant<T1, V1++>();
    }
    template <typename T1, T1 V1>
    constexpr auto operator--(const std::integral_constant<T1, V1>&, int)
    {
        return std::integral_constant<T1, V1-->();
    }

    //~~~~~~~~~~~~~~~~ Binary Op
    // Note: a priori operators "+=" do not make sense, because it would
    // change type <Index_t,2> to <Index_t,3> for instance

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator+(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<typename std::common_type<T1, T2>::type, V1 + V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator-(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<typename std::common_type<T1, T2>::type, V1 - V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator*(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<typename std::common_type<T1, T2>::type, V1 * V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator/(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<typename std::common_type<T1, T2>::type, V1 / V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator==(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, V1 == V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator!=(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, V1 != V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator<(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant < bool, V1<V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator<=(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, V1 <= V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator>=(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, V1 >= V2>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator>(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, (V1 > V2)>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator&&(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, (V1 && V2)>();
    }

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto operator||(const std::integral_constant<T1, V1>&, const std::integral_constant<T2, V2>&) noexcept
    {
        return std::integral_constant<bool, (V1 || V2)>();
    }

    //~~~~~~~~~~~~~~~~

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto integral_constant_min(const std::integral_constant<T1, V1>&,
                                         const std::integral_constant<T2, V2>&) noexcept
    {
        using std::min;
        return std::integral_constant<typename std::common_type<T1, T2>::type, min(V1, V2)>();
    }

    template <typename T1, typename T2, T2 V2>
    constexpr auto integral_constant_min(const T1& v1, const std::integral_constant<T2, V2>&) noexcept
    {
        using std::min;
        return min(v1, V2);
    }

    template <typename T1, T1 V1, typename T2>
    constexpr auto integral_constant_min(const std::integral_constant<T1, V1>&, const T2& v2) noexcept
    {
        using std::min;
        return min(V1, v2);
    }

    template <typename T1, typename T2>
    constexpr auto integral_constant_min(const T1& v1, const T2& v2) noexcept
    {
        using std::min;
        return min(v1, v2);
    }

    //~~~~~~~~~~~~~~~~

    template <typename T1, T1 V1, typename T2, T2 V2>
    constexpr auto integral_constant_max(const std::integral_constant<T1, V1>&,
                                         const std::integral_constant<T2, V2>&) noexcept
    {
        using std::max;
        return std::integral_constant<typename std::common_type<T1, T2>::type, max(V1, V2)>();
    }

    template <typename T1, typename T2, T2 V2>
    constexpr auto integral_constant_max(const T1& v1, const std::integral_constant<T2, V2>&) noexcept
    {
        using std::max;
        return max(v1, V2);
    }

    template <typename T1, T1 V1, typename T2>
    constexpr auto integral_constant_max(const std::integral_constant<T1, V1>&, const T2& v2) noexcept
    {
        using std::max;
        return max(V1, v2);
    }

    template <typename T1, typename T2>
    constexpr auto integral_constant_max(const T1& v1, const T2& v2) noexcept
    {
        using std::max;
        return max(v1, v2);
    }

    //
    // Do not try to define a specialization for std::common_type
    //
    // The reasons are twofold:
    //
    // 1/ The  standard says:
    //
    // ""Custom specializations of the type trait std::common_type are
    // allowed, as long as at least one parameter is a user-defined type
    // (note that the behavior of a program that adds a specialization
    // to any other class from <type_traits> is ***undefined***).""
    //
    // 2/ We can not define common type for:  std::integral_constant<T1,V1>, std::integral_constant<T2,V2>
    //    -> because it depends on the operation we have to perform (V1+V2, V1-V2 ????)
    //

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <Integer_Common_t K>
    constexpr auto Static_Integer = std::integral_constant<Integer_Common_t, K>();
}
