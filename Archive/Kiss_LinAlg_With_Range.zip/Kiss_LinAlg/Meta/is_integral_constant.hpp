#pragma once

#include <type_traits>

namespace Kiss
{
/** @ingroup Kiss_LinAlg_Meta_DynStat_Group
    @brief Static type check for std::integral_constant

    @snippet test/Meta/check_is_integral_constant.cpp Basic
*/
#ifdef DOXYGEN_DOC
  template <typename TYPE>
  struct is_integral_constant
  {
    /** Associated value_type */
    typedef _IMPLEMENTATION_ value_type;
  };
#else
  template <typename TYPE, typename ENABLE = void>
  struct is_integral_constant : std::integral_constant<bool, false>
  {
    typedef TYPE value_type;
  };

  template <typename TYPE, TYPE VALUE>
  struct is_integral_constant<std::integral_constant<TYPE, VALUE> > : std::integral_constant<bool, true>
  {
    typedef TYPE value_type;
  };
#endif
}
