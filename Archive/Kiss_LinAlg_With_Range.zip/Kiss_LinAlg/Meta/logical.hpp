#pragma once

#include <type_traits>

namespace Kiss
{
    // From C++17 Standard
    //
    template <class...>
    struct Conjunction : std::true_type
    {
    };
    template <class B1>
    struct Conjunction<B1> : B1
    {
    };
    template <class B1, class... Bn>
    struct Conjunction<B1, Bn...> : std::conditional_t<B1::value != false, Conjunction<Bn...>, B1>
    {
    };

    template <class...>
    struct Disjunction : std::false_type
    {
    };
    template <class B1>
    struct Disjunction<B1> : B1
    {
    };
    template <class B1, class... Bn>
    struct Disjunction<B1, Bn...> : std::conditional_t<B1::value != false, B1, Disjunction<Bn...> >
    {
    };

    template <bool B>
    using Static_Boolean = std::integral_constant<bool, B>;

    template <class B>
    struct Negation : Static_Boolean<!B::value>
    {
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @todo maybe upgrade to use DynStat */

    constexpr bool conjunction() noexcept { return true; }
    constexpr bool conjunction(bool b) noexcept { return b; }

    template <typename B1, typename B2, typename... Bn>
    constexpr std::enable_if_t<
        Conjunction<std::is_same<bool, B1>, std::is_same<bool, B2>, std::is_same<bool, Bn>...>::value, bool>
        conjunction(B1 b1, B2 b2, Bn... bn) noexcept
    {
        return b1 && conjunction(b2, bn...);
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    constexpr bool disjunction() noexcept { return false; }
    constexpr bool disjunction(bool b) noexcept { return b; }

    template <typename B1, typename B2, typename... Bn>
    constexpr std::enable_if_t<
        Disjunction<std::is_same<bool, B1>, std::is_same<bool, B2>, std::is_same<bool, Bn>...>::value, bool>
        disjunction(B1 b1, B2 b2, Bn... bn) noexcept
    {
        return b1 || disjunction(b2, bn...);
    }
}
