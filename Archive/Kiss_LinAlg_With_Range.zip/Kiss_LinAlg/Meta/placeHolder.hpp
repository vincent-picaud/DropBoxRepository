#pragma once

namespace Kiss
{
  struct PlaceHolder {};
  constexpr PlaceHolder _{};
}
