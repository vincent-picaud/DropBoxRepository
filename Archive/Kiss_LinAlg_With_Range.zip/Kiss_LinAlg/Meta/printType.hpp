#pragma once

#include <iostream>

namespace Kiss
{
    template <typename T>
    void printType()
    {
        std::cerr << "\n" << __PRETTY_FUNCTION__ << "\n";
    };

    template <typename T>
    void printType(const T&)
    {
        std::cerr << "\n" << __PRETTY_FUNCTION__ << "\n";
    };
}
