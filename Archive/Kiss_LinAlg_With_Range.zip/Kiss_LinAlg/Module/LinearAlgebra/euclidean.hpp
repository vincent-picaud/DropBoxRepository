/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Fri Apr 29 15:39:57 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/Scalar/euclidean.hpp>
#include <Kiss_LinAlg/Meta/elementType_t.hpp>

#include <Kiss_LinAlg/Vector/interface_denseVector.hpp>
#include <Kiss_LinAlg/Vector/interface_sparseVector.hpp>

namespace Kiss
{
    //
    // NOTE: CONJUGATE_TAG allows reuse to define  matrix-vector product
    //

    /** @private
     *  @brief Default implementation (2 vectors)
     */
    template <typename D1, typename D2, typename CONJUGATE_TAG>
    auto dot(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2, const CONJUGATE_TAG& tag)
    {
        decltype(dot(std::declval<ElementType_t<D1>>(), std::declval<ElementType_t<D2>>(), tag)) res_dot{0};

        map(
            [&](const auto& d1_i, const auto& d2_i)
            {
                res_dot += dot(d1_i, d2_i);
            },
            d1, d2);

        return res_dot;
    }

    /** @private
     *  @brief Specialization for 1 denseVector & 1 sparseVector
     */
    template <typename D1, typename D2, typename CONJUGATE_TAG>
    auto dot(const Interface_DenseVector<D1>& d1, const Interface_SparseVector<D2>& d2, const CONJUGATE_TAG& tag)
    {
        assert(sameDimension(d1, d2));

        decltype(dot(std::declval<ElementType_t<D1>>(), std::declval<ElementType_t<D2>>(), tag)) res_dot{0};

        indexed_map(
            [&](const Index_t d2_idx, const auto& d2_i)
            {
                res_dot += dot(d1[d2_idx], d2_i);
            },
            d2);

        return res_dot;
    }

    /** @private
     *  @brief Specialization for 1 sparseVector & 1 denseVector
     */
    template <typename D1, typename D2, typename CONJUGATE_TAG>
    auto dot(const Interface_SparseVector<D1>& d1, const Interface_DenseVector<D2>& d2, const CONJUGATE_TAG& tag)
    {
        assert(sameDimension(d1, d2));

        decltype(dot(std::declval<ElementType_t<D1>>(), std::declval<ElementType_t<D2>>(), tag)) res_dot{0};

        indexed_map(
            [&](const Index_t d1_idx, const auto& d1_i)
            {
                res_dot += dot(d1_i, d2[d1_idx]);
            },
            d1);

        return res_dot;
    }

    /** @private
     *  @brief Specialization for 2 sparseVectors
     */
    template <typename D1, typename D2, typename CONJUGATE_TAG>
    auto dot(const Interface_SparseVector<D1>& d1, const Interface_SparseVector<D2>& d2, const CONJUGATE_TAG& tag)
    {
        // Check struture is performed by the **map** function

        decltype(dot(std::declval<ElementType_t<D1>>(), std::declval<ElementType_t<D2>>(), tag)) res_dot{0};

        map(
            [&](const auto& d1_i, const auto& d2_i)
            {
                res_dot += dot(d1_i, d2_i);
            },
            d1, d2);

        return res_dot;
    }

    //
    // NOTE: Generic version with default CONJUGATE_TAG
    //
    template <typename D1, typename D2>
    auto dot(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2)
    {
        return dot(d1.impl(), d2.impl(), ConjugateTag_Conjugate());
    }

} /* Kiss */
