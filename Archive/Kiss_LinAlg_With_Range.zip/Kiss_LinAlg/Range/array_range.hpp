#pragma once

#include <Kiss_LinAlg/Range/interface_finite_range.hpp>
#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

namespace Kiss
{
  // By default all dynamic!
  template <typename T, typename STRIDE_TYPE = Index_t>
  class Array_Range;

  template <typename T, typename STRIDE_TYPE>
  struct CRTP_TypeTraits<Array_Range<T, STRIDE_TYPE>>
  {
    using ElementType = T;

    using DirectionTag = DirectionTag_Forward;

    using ReadWriteTag = std::conditional_t<std::is_const<T>::value, ReadWriteTag_Read,
                                                        ReadWriteTag_ReadWrite>;

    typedef DynStatValue<STRIDE_TYPE> Stride_Type;
  };

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief A range associated to a pointer, a stride and a size
      @implements Interface_Finite_Range<>
  */
  template <typename T, typename STRIDE_TYPE>
  class Array_Range final
#ifndef DOXYGEN_DOC
      : public Interface_Finite_Range<Array_Range<T, STRIDE_TYPE>>
#endif

  {
    static_assert(DynStatArgument_Well_Defined<Index_t, STRIDE_TYPE>::value, "");

   protected:
    using SelfType = Array_Range;
    using TraitsType = CRTP_TypeTraits<Array_Range>;

   public:
    using Stride_Type = typename TraitsType::Stride_Type;

   protected:
    Array_Range(){};  // prevent imcomplete construction

   public:
    constexpr Array_Range(T* p, Size_t size, Index_t stride) noexcept : p_(p),
                                                                        p_end_(p + size * stride),
                                                                        stride_(stride)
    {
      assert(check_invariant());
    }

    constexpr Array_Range(const SelfType& toCopy) noexcept = default;

    constexpr bool check_invariant() const noexcept { return (p_ <= p_end_) && (stride_() > 0); }

   protected:
    T* p_;
    const T* const p_end_;
    const Stride_Type stride_;

    //
    //////////////////////////////////////////////////////////////////
    // INTERFACE OVERLOADING
    //////////////////////////////////////////////////////////////////
    //

    friend constexpr bool is_empty(const SelfType& self) noexcept { return self.p_ >= self.p_end_; };

    friend constexpr auto& front(const SelfType& self) noexcept
    {
      assert((!is_empty(self)) && (self.p_ != nullptr));

      return *self.p_;
    }

    friend constexpr void popFront(SelfType& self) noexcept
    {
      assert(!is_empty(self));

      self.p_ += self.stride_();
    }
  };

  //
  // For Loop Unrolling it is __important__ for Range to be of literal type
  //
  static_assert(std::is_literal_type<Array_Range<int, Index_t>>::value,
                "Can not be used in constexpr! (loop unrolling)");
  static_assert(std::is_literal_type<Array_Range<int, std::integral_constant<Index_t, 1>>>::value,
                "Can not be used in constexpr! (loop unrolling)");

  //
  //////////////////////////////////////////////////////////////////
  // CONSTRUCTOR
  //////////////////////////////////////////////////////////////////
  //
  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Create a range associated to a pointer & a size
      @relates Array_Range
  */
  template <typename T, typename STRIDE_TYPE,
            typename = std::enable_if_t<DynStatArgument_Well_Defined<Index_t, STRIDE_TYPE>::value>>
  constexpr auto create_array_range(T* p, Size_t size, const STRIDE_TYPE& stride) noexcept
  {
    return Array_Range<T, STRIDE_TYPE>(p, size, stride);
  }

} /* Kiss */
