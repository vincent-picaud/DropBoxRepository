#pragma once

#include <Kiss_LinAlg/Range/interface_finite_range_fwd.hpp>
#include <Kiss_LinAlg/Range/interface_range.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Range_Group
         @brief Finite range interface
         @extends Interface_Range
    */
    template <typename DERIVED>
    class Interface_Finite_Range
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Finite_Range, DERIVED, Interface_Range>
#endif
    {
       protected:
        Interface_Finite_Range() = default;
    };
}
