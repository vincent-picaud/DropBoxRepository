#pragma once

#include <Kiss_LinAlg/Range/interface_infinite_range_fwd.hpp>
#include <Kiss_LinAlg/Range/interface_range.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_Range_Group
         @brief Range interface
         @extends Interface_Range
    */
    template <typename DERIVED>
    class Interface_Infinite_Range
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Infinite_Range, DERIVED, Interface_Range>
#endif
    {
       protected:
        Interface_Infinite_Range() = default;
    };
}
