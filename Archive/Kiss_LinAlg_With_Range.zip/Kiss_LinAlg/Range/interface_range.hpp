#pragma once

#include <Kiss_LinAlg/Range/interface_range_fwd.hpp>
#include <Kiss_LinAlg/Range/range_map.hpp>

#include <Kiss_LinAlg/Meta/logical.hpp>

namespace Kiss
{
  template <typename DERIVED>
  class Interface_Range;

  //////////////////////////////////////////////////////////////////

  /**  @ingroup Kiss_LinAlg_Details_Range_Group
       @defgroup Kiss_LinAlg_Details_Range_DirectionProperty_Group Direction Property
       @brief Direction Property
  */

  /**  @ingroup Kiss_LinAlg_Details_Range_DirectionProperty_Group
       @brief Interface_Range Direction Property
  */
  struct DirectionTag_Base
  {
  };

  /**  @ingroup Kiss_LinAlg_Details_Range_DirectionProperty_Group
       @brief Tag Forward Range
  */
  struct DirectionTag_Forward : DirectionTag_Base
  {
  };
  /**  @ingroup Kiss_LinAlg_Details_Range_DirectionProperty_Group
       @brief Tag Backward Range
  */
  struct DirectionTag_Backward : DirectionTag_Base
  {
  };
  /**  @ingroup Kiss_LinAlg_Details_Range_DirectionProperty_Group
       @brief Tag BiDirectional Range
  */
  struct DirectionTag_BiDirectional : DirectionTag_Backward, DirectionTag_Forward
  {
  };

  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
     @brief Check if an object is a direction property tag
*/
  template <typename TYPE>
  using Is_Defined_DirectionTag = std::integral_constant<bool, (std::is_base_of<DirectionTag_Base, TYPE>::value) &&
                                                                   (!std::is_same<DirectionTag_Base, TYPE>::value)>;

  //////////////////////////////////////////////////////////////////

  /**  @ingroup Kiss_LinAlg_Details_Range_Group
       @defgroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group Read/Write Property
       @brief Read/Write Property
  */

  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
       @brief Interface_Range Read/Write Property
  */
  struct ReadWriteTag_Base
  {
  };

  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
       @brief Tag Read Interface_Range
  */
  struct ReadWriteTag_Read : ReadWriteTag_Base
  {
  };
  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
       @brief Tag Write Interface_Range
  */
  struct ReadWriteTag_Write : ReadWriteTag_Base
  {
  };
  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
       @brief Tag Read/Write Interface_Range
  */
  struct ReadWriteTag_ReadWrite : ReadWriteTag_Write, ReadWriteTag_Read
  {
  };

  /**  @ingroup Kiss_LinAlg_Details_Range_ReadWriteProperty_Group
       @brief Check if an object is a Read/Write property tage
  */
  template <typename TYPE>
  using ReadWriteTag_Well_Defined = std::integral_constant<bool, (std::is_base_of<ReadWriteTag_Base, TYPE>::value) &&
                                                                     (!std::is_same<ReadWriteTag_Base, TYPE>::value)>;

  template <typename TYPE>
  using ReadWriteTag_Has_Read = std::integral_constant<bool, std::is_base_of<ReadWriteTag_Read, TYPE>::value>;

  template <typename TYPE>
  using ReadWriteTag_Has_Write = std::integral_constant<bool, std::is_base_of<ReadWriteTag_Write, TYPE>::value>;

  template <typename TYPE>
  using ReadWriteTag_Has_ReadWrite = std::integral_constant<bool, std::is_base_of<ReadWriteTag_ReadWrite, TYPE>::value>;

  //////////////////////////////////////////////////////////////////

  /**  @ingroup Kiss_LinAlg_Range_Group
       @brief Range interface
       @extends CRTP_Base

       @attention front, back, popFront etc... must stay __friend__
       because not all object have such methods (depend on Range
       type and can not be implemented thanks to inherance because
       of Diamond inherance diagramm of properties such that
       forward/backward/bidirectional and read/write/readWrite.
  */
  template <typename DERIVED>
  class Interface_Range
#ifndef DOXYGEN_DOC
      : public CRTP_Find_BaseType<Interface_Range, DERIVED, CRTP_Base>
#endif
  {
   public:
    using SelfType = Interface_Range;
    using TraitsType = CRTP_TypeTraits<DERIVED>;

    //--------------------------------------------------

    /** @brief Element type */
    typedef typename TraitsType::ElementType ElementType;

    /** @brief Define DirectionTag_Base */
    typedef typename TraitsType::DirectionTag DirectionTag;

    /** @brief Check DirectionTag_Forward */
    static constexpr bool Is_Forward_Range() noexcept
    {
      return std::is_base_of<DirectionTag_Forward, DirectionTag>::value;
    };

    /** @brief Check DirectionTag_Backward */
    static constexpr bool Is_Backward_Range() noexcept
    {
      return std::is_base_of<DirectionTag_Backward, DirectionTag>::value;
    };

    typedef typename TraitsType::ReadWriteTag ReadWriteTag;

    static constexpr bool Is_Read_Range() noexcept { return std::is_base_of<ReadWriteTag_Read, ReadWriteTag>::value; };
    static constexpr bool Is_Write_Range() noexcept
    {
      return std::is_base_of<ReadWriteTag_Write, ReadWriteTag>::value;
    };

   public:
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @brief Clone range

        @note Mandatory as a range object must be easy to copy
    */
    constexpr auto clone() const noexcept { return DERIVED(SelfType::impl()); };
  };

  //==================================================
  // Interface
  //==================================================
  //

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Empty range?
      @relates Interface_Range
  */
  template <typename RANGE>
  bool is_empty(const Interface_Range<RANGE>& range)
  {
    return is_empty(range.impl());
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Mutable access to range front
      @relates Interface_Range

      @attention @b range param is constant. The availability of
      Read/Write mode is governed by @ref ReadWriteTag_Base
  */
  template <typename RANGE>
  auto& front(const Interface_Range<RANGE>& range)
  {
    static_assert(Interface_Range<RANGE>::Is_Forward_Range(), "");

    return front(range.impl());
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Mutable access to range back
      @relates Interface_Range

      @attention @b range param is constant. The availability of
      Read/Write mode is governed by @ref ReadWriteTag_Base
  */
  template <typename RANGE>
  auto& back(const Interface_Range<RANGE>& range)
  {
    static_assert(Interface_Range<RANGE>::Is_Backward_Range(), "");

    return back(range.impl());
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Interface_Range popFront
      @relates Interface_Range
  */
  template <typename RANGE>
  void popFront(Interface_Range<RANGE>& range)
  {
    static_assert(Interface_Range<RANGE>::Is_Forward_Range(), "");
    return popFront(range.impl());
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Interface_Range popBack
      @relates Interface_Range
  */
  template <typename RANGE>
  void popBack(Interface_Range<RANGE>& range)
  {
    static_assert(Interface_Range<RANGE>::Is_Backward_Range(), "");
    return popBack(range.impl());
  }

  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  /** @ingroup Kiss_LinAlg_Range_CWise_Group
      @brief Prints range components
  */
  template <typename DERIVED>
  std::ostream& operator<<(std::ostream& out, const Interface_Range<DERIVED>& toPrint)
  {
    map(
        [&out](const auto& toPrint_i)
        {
          out << "\n" << toPrint_i;
        },
        toPrint);

    return out;
  }

  //==================================================
  // Generic
  //==================================================
  //

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief All ranges are empty?
      @relates Interface_Range

      Generalize @ref is_empty() to several ranges

      @note: there is a std::is_empty that leads to some ambiguities when used with using namespace std;
  */
  template <typename RANGE_FIRST, typename... RANGE_TAIL>
  bool is_empty(const Interface_Range<RANGE_FIRST>& range_first, const Interface_Range<RANGE_TAIL>&... range_tail)
  {
    return is_empty(range_first) && is_empty(range_tail...);
  }

  //-------------------------

  template <typename RANGE_FIRST>
  bool at_least_one_is_empty(const Interface_Range<RANGE_FIRST>& range_first)
  {
    return is_empty(range_first);
  }

  template <typename RANGE_FIRST, typename... RANGE_TAIL>
  bool at_least_one_is_empty(const Interface_Range<RANGE_FIRST>& range_first,
                             const Interface_Range<RANGE_TAIL>&... range_tail)
  {
    return is_empty(range_first) || at_least_one_is_empty(range_tail...);
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief popFront a list of ranges
      @relates Interface_Range
  */
  template <typename RANGE_FIRST, typename... RANGE_TAIL>
  void popFront(Interface_Range<RANGE_FIRST>& range_first, Interface_Range<RANGE_TAIL>&... range_tail)
  {
    popFront(range_first);
    popFront(range_tail...);
  }

  //--------------------------------------------------

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief popBack a list of ranges
      @relates Interface_Range
  */
  template <typename RANGE_FIRST, typename... RANGE_TAIL>
  void popBack(Interface_Range<RANGE_FIRST>& range_first, Interface_Range<RANGE_TAIL>&... range_tail)
  {
    popBack(range_first);
    popBack(range_tail...);
  }

  //--------------------------------------------------

  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // CAVEAT: always use references otherwise object slicing!
  // //
  // void const_map(const LAMBDA& lambda, Interface_Range<RANGE_FIRST>& range_first,
  // Interface_Range<RANGE_TAIL>&... range_tail)    //
  // is a bad idea
  // //
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //
  //   /** @ingroup Kiss_LinAlg_Range_Group
  //         @brief Map a lambda to a list of ranges
  //         @relates Interface_Range

  //         Modify the first element:

  //         The lambda prototype must be:
  //         @code
  //         void lambda(auto&, const auto&, const auto& ...)
  //         @endcode

  //         @todo URGENT add is_empty at the end + use popFront to the first non empty
  //     */
  //     template <typename LAMBDA, typename RANGE_FIRST, typename... RANGE_TAIL>
  // #ifndef DOXYGEN_DOC
  //     std::enable_if_t<
  //         std::conjunction<Is_CRTP_Interface<std::remove_reference_t<RANGE_FIRST>, Interface_Range>,
  //                          Is_CRTP_Interface<std::remove_reference_t<RANGE_TAIL>, Interface_Range>...>::value>
  // #endif
  //         map(const LAMBDA& lambda, RANGE_FIRST&& range_first, RANGE_TAIL&&... range_tail)
  //     {
  // #pragma omp simd
  //         while(!is_empty(range_first))
  //         {
  //             lambda(front(range_first), front(range_tail)...);
  //             popFront(range_first, range_tail...);
  //         }
  //     }
}
