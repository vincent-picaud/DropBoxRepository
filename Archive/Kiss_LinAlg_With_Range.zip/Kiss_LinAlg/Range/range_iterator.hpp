#pragma once

#include <Kiss_LinAlg/Range/interface_finite_range.hpp>
#include <Kiss_LinAlg/indexType.hpp>

#include <iterator>

#warning TODO: range_iterator to clean!

namespace Kiss
{
  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY, typename ENABLE = void>
  class Range_Iterator;

  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY>
  struct CRTP_TypeTraits<Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>>
  {
    typedef typename std::iterator_traits<ITER>::value_type ElementType;

    typedef RANGE_DIRECTION_PROPERTY DirectionTag;

    typedef RANGE_READWRITE_PROPERTY ReadWriteTag;
  };

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Wraps STL iterators
      @implements Interface_Finite_Range
  */
  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY>
#ifndef DOXYGEN_DOC
  class Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY,
                       std::enable_if_t<(Is_Defined_DirectionTag<RANGE_DIRECTION_PROPERTY>::value) &&
                                        (ReadWriteTag_Well_Defined<RANGE_READWRITE_PROPERTY>::value)>> final
      : public Interface_Finite_Range<Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>>
#else
  class Range_Iterator final
#endif
  {

   public:
    typedef CRTP_TypeTraits<Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>> TraitsType;

   protected:
    Range_Iterator(){};  // prevent imcomplete construction

   public:
    Range_Iterator(const ITER iter_begin, const ITER iter_end) : iter_begin_(iter_begin), iter_end_(iter_end)
    {
      assert(check_invariant());
    }
    Range_Iterator(const Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>& toCopy)
        : iter_begin_(toCopy.iter_begin_), iter_end_(toCopy.iter_end_)
    {
      assert(check_invariant());
    }

    bool is_empty() const { return iter_begin_ >= iter_end_; }

    void popFront()
    {
      assert(!is_empty());

      ++iter_begin_;
    }

    auto& front() const
    {
      assert(!is_empty());

      return *iter_begin_;
    }

    bool check_invariant() const { return true; }

   protected:
    ITER iter_begin_, iter_end_;
  };

  //==================================================
  // Some creation function
  //==================================================
  //
  template <typename T, std::size_t N>
  auto create_range(const std::array<T, N>& array)
  {
    return Range_Iterator<typename std::array<T, N>::const_iterator, DirectionTag_Forward,
                          ReadWriteTag_Read>(array.begin(), array.end());
  }

  template <typename T, std::size_t N>
  auto create_range(std::array<T, N>& array)
  {
    return Range_Iterator<typename std::array<T, N>::iterator, DirectionTag_Forward,
                          ReadWriteTag_ReadWrite>(array.begin(), array.end());
  }

  //-------------------------

  template <typename T, std::size_t N>
  auto create_reverse_range(const std::array<T, N>& array)
  {
    return Range_Iterator<typename std::array<T, N>::const_reverse_iterator, DirectionTag_Forward,
                          ReadWriteTag_Read>(array.rbegin(), array.rend());
  }

  template <typename T, std::size_t N>
  auto create_reverse_range(std::array<T, N>& array)
  {
    return Range_Iterator<typename std::array<T, N>::reverse_iterator, DirectionTag_Forward,
                          ReadWriteTag_ReadWrite>(array.rbegin(), array.rend());
  }

  //--------------------------------------------------

  template <typename T>
  auto create_range(const std::vector<T>& vector)
  {
    return Range_Iterator<typename std::vector<T>::const_iterator, DirectionTag_Forward,
                          ReadWriteTag_Read>(vector.begin(), vector.end());
  }

  template <typename T>
  auto create_range(std::vector<T>& vector)
  {
    return Range_Iterator<typename std::vector<T>::iterator, DirectionTag_Forward,
                          ReadWriteTag_ReadWrite>(vector.begin(), vector.end());
  }

  //-------------------------

  template <typename T>
  auto create_reverse_range(const std::vector<T>& array)
  {
    return Range_Iterator<typename std::vector<T>::const_reverse_iterator, DirectionTag_Forward,
                          ReadWriteTag_Read>(array.rbegin(), array.rend());
  }

  template <typename T>
  auto create_reverse_range(std::vector<T>& array)
  {
    return Range_Iterator<typename std::vector<T>::reverse_iterator, DirectionTag_Forward,
                          ReadWriteTag_ReadWrite>(array.rbegin(), array.rend());
  }

  //==================================================
  // Overloading
  //==================================================
  //

  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY>
  bool is_empty(const Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>& range)
  {
    return range.is_empty();
  }

  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY>
  auto& front(const Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>& range)
  {
    return range.front();
  }

  template <typename ITER, typename RANGE_DIRECTION_PROPERTY, typename RANGE_READWRITE_PROPERTY>
  void popFront(Range_Iterator<ITER, RANGE_DIRECTION_PROPERTY, RANGE_READWRITE_PROPERTY>& range)
  {
    return range.popFront();
  }

} /* Kiss */
