#pragma once

#include <Kiss_LinAlg/Range/interface_range_fwd.hpp>
//#include <Kiss_LinAlg/CWise/cwise_base.hpp>

namespace Kiss
{
    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (v_i,w_i....)
    //
    //////////////////////////////////////////////////////////////////
    //

    /** @ingroup Kiss_LinAlg_Range_Group
         @brief Map a lambda to a list of ranges
         @relates Interface_Range
     */
    template <typename LAMBDA, typename RANGE_FIRST, typename... RANGE_TAIL>
    void map(const LAMBDA& lambda, const Interface_Range<RANGE_FIRST>& range_first,
             const Interface_Range<RANGE_TAIL>&... range_tail)
    {

        auto use_range_cpy =
            [&](Interface_Range<RANGE_FIRST>&& range_cpy_first, Interface_Range<RANGE_TAIL>&&... range_cpy_tail)
        {
#pragma omp simd
            while(!is_empty(range_cpy_first))
            {
                lambda(front(range_cpy_first), front(range_cpy_tail)...);
                popFront(range_cpy_first, range_cpy_tail...);
            }
        };

        use_range_cpy(range_first.clone(), range_tail.clone()...);
    }
}
