#pragma once

#include <Kiss_LinAlg/Range/interface_infinite_range.hpp>
#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Meta/differedFalse.hpp>

namespace Kiss
{
  template <typename ELEMENTTYPE>
  class Range_OneElement;

  template <typename ELEMENTTYPE>
  struct CRTP_TypeTraits<Range_OneElement<ELEMENTTYPE>>
  {
    typedef std::decay_t<ELEMENTTYPE> ElementType;  // Decay because must handle const & reference

    typedef DirectionTag_BiDirectional DirectionTag;

    typedef ReadWriteTag_Read ReadWriteTag;
  };

  /**  @ingroup Kiss_LinAlg_Range_Group
       @brief A range one one element
       @extends Interface_Infinite_Range

       Implementation detail: we have chosen to define read mode
       only Reason: front(const& range) would require a const_cast
       (here we store element& and not element*)
  */
  template <typename ELEMENTTYPE>
  class Range_OneElement final
#ifndef DOXYGEN_DOC
      : public Interface_Infinite_Range<Range_OneElement<ELEMENTTYPE>>
#endif
  {

   public:
    typedef CRTP_TypeTraits<Range_OneElement<ELEMENTTYPE>> TraitsType;

   protected:
    Range_OneElement(){};  // prevent imcomplete construction

   public:
    constexpr Range_OneElement(const ELEMENTTYPE& element) noexcept : element_(element) {}
    constexpr Range_OneElement(const Range_OneElement<ELEMENTTYPE>& toCopy) noexcept : element_(toCopy.element_) {}

   protected:
    ELEMENTTYPE element_;

    //==================================================
    // INTERFACE OVERLOADING
    //==================================================
    //
    friend bool is_empty(const Range_OneElement<ELEMENTTYPE>& range) { return false; }
    friend constexpr bool is_finite(const Range_OneElement<ELEMENTTYPE>& range) { return false; }

    friend const auto& front(const Range_OneElement<ELEMENTTYPE>& range) { return range.element_; }

    friend void popFront(Range_OneElement<ELEMENTTYPE>& range)
    {
      // Nothing to do
    }
    friend const auto& back(const Range_OneElement<ELEMENTTYPE>& range) { return range.element_; }

    friend void popBack(Range_OneElement<ELEMENTTYPE>& range)
    {
      // Nothing to do
    }
  };

  //==================================================
  // Some creation function
  //==================================================
  //

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Creates range from element, by value
      @relates Range_OneElement

      See
      @snippet test/Range/check_range_oneElement.cpp Value_vs_Ref
  */
  template <typename ELEMENTTYPE>
  auto create_range_oneElement(const ELEMENTTYPE& element)
  {
    return Range_OneElement<const ELEMENTTYPE>(element);
  }

  /** @ingroup Kiss_LinAlg_Range_Group
      @brief Creates range from element, by reference
      @relates Range_OneElement

      See
      @snippet test/Range/check_range_oneElement.cpp Value_vs_Ref
  */
  template <typename ELEMENTTYPE>
  auto create_range_oneElement_reference(const ELEMENTTYPE& element)
  {
    return Range_OneElement<const ELEMENTTYPE&>(element);
  }

} /* Kiss */
