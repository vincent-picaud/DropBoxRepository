#pragma once

#include <Kiss_LinAlg/Range/interface_finite_range.hpp>
#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Meta/differedFalse.hpp>

namespace Kiss
{
    template <typename STORED_RANGE>
    class Range_Take;

    template <typename STORED_RANGE>
    struct CRTP_TypeTraits<Range_Take<STORED_RANGE> >
    {
        typedef typename CRTP_TypeTraits<STORED_RANGE>::ElementType ElementType;

        typedef typename CRTP_TypeTraits<STORED_RANGE>::DirectionTag DirectionTag;

        typedef typename CRTP_TypeTraits<STORED_RANGE>::ReadWriteTag ReadWriteTag;
    };

    //==================================================

    /** @ingroup Kiss_LinAlg_Range_Group
        @brief A range that takes n element of another range
        @implements Interface_Finite_Range
    */
    template <typename STORED_RANGE>
    class Range_Take final
#ifndef DOXYGEN_DOC
        : public Interface_Finite_Range<Range_Take<STORED_RANGE> >
#endif
    {
        static_assert(std::is_final<STORED_RANGE>::value, "");

       protected:
        Range_Take(){};  // prevent imcomplete construction

       public:
        Range_Take(const Size_t N, const STORED_RANGE& stored_range) : count_(N), stored_range_(stored_range)
        {
            assert(check_invariant());
        }
        Range_Take(const Range_Take<STORED_RANGE>& toCopy)
            : count_(toCopy.count_), stored_range_(toCopy.stored_range_)
        {
            assert(check_invariant());
        }

        bool check_invariant() const { return count_ >= 0; }

       protected:
        Size_t count_;
        STORED_RANGE stored_range_;

        //================================================================
        // INTERFACE
        //================================================================

        friend bool is_empty(const Range_Take<STORED_RANGE>& range)
        {
            assert(range.count_ >= 0);
            return range.count_ == 0;
        }

        friend decltype(auto) const_front(const Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));

            return const_front(range.stored_range_);
        }

        friend decltype(auto) front(const Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));

            return front(range.stored_range_);
        }

        friend void popFront(Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));
            --range.count_;
            popFront(range.stored_range_);
        }

        friend decltype(auto) const_back(const Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));

            return const_back(range.stored_range_);
        }

        friend decltype(auto) back(const Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));

            return back(range.stored_range_);
        }

        friend void popBack(Range_Take<STORED_RANGE>& range)
        {
            assert(!is_empty(range));
            --range.count_;
            popBack(range.stored_range_);
        }
    };

    //================================================================
    // CONSTRUCTOR
    //================================================================
    //

    /** @ingroup Kiss_LinAlg_Range_Group
       @brief A range that takes n element of another range
       @relates Range_Take<>
   */
    template <typename DERIVED>
    auto take(const Size_t N, const Interface_Range<DERIVED>& range)
    {
      return Range_Take<DERIVED>(N, range.impl());
    }

} /* Kiss */
