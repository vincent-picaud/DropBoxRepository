/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Fri Apr 29 15:39:57 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/Scalar/is_registred_scalar.hpp>
#include <Kiss_LinAlg/Tag/conjugateTag.hpp>

namespace Kiss
{
    //################################################################ Conjugate

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ With user tag

    // Real or other
    //
    template <typename S1, typename CONJUGATE_TAG,
              typename = std::enable_if_t<is_registred_real_scalar<S1>::value &&
                                          ConjugateTag_Well_Defined<CONJUGATE_TAG>::value>>
    constexpr decltype(auto) conj(const S1& l1, const CONJUGATE_TAG&) noexcept
    {
        return l1;
    }

    // std:: complex specialization
    //
    template <typename S1, typename = std::enable_if_t<is_registred_real_scalar<S1>::value>>
    constexpr decltype(auto) conj(const std::complex<S1>& l1, const ConjugateTag_Identity&) noexcept
    {
        return l1;
    }
    template <typename S1, typename = std::enable_if_t<is_registred_real_scalar<S1>::value>>
    constexpr decltype(auto) conj(const std::complex<S1>& l1, const ConjugateTag_Conjugate&) noexcept
    {
        return std::conj(l1);
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Usual function

    template <typename S1>
    constexpr decltype(auto) conj(const S1& l1) noexcept
    {
        return conj(l1, ConjugateTag_Conjugate());
    }

    //################################################################ Dot
    //
    // CAVEAT: our choice is <a,b> = conjugate(a).b (and not a.conjugate(b))
    //

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ With tag

    template <typename S1, typename S2, typename CONJUGATE_TAG,
              typename = std::enable_if_t<is_registred_scalar<S1>::value && is_registred_scalar<S2>::value &&
                                          ConjugateTag_Well_Defined<CONJUGATE_TAG>::value>>
    constexpr auto dot(const S1& s1, const S2& s2, const CONJUGATE_TAG& tag) noexcept
    {
        return conj(s1, tag) * s2;
    }

    template <typename S1, typename S2,
              typename = std::enable_if_t<is_registred_scalar<S1>::value && is_registred_scalar<S2>::value>>
    constexpr auto dot(const S1& s1, const S2& s2) noexcept
    {
        return dot(s1, s2, ConjugateTag_Conjugate());
    }

} /* Kiss */
