/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Fri Apr 29 15:39:57 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/indexType.hpp>

#include <type_traits>
#include <ccomplex>

namespace Kiss
{
    ////////////////////////////////////////////////////////////////// "REAL" scalars

    template <typename SCALAR, typename ENABLE = void>
    struct is_registred_real_scalar : std::false_type
    {
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Registered "real" scalars

  template <>
    struct is_registred_real_scalar<Integer_Common_t> : std::true_type
    {
    };
  
    template <>
    struct is_registred_real_scalar<float> : std::true_type
    {
    };
    template <>
    struct is_registred_real_scalar<double> : std::true_type
    {
    };

    ////////////////////////////////////////////////////////////////// "REAL" & "COMPLEX" scalars

  //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Include REAL scalars
    template <typename SCALAR, typename ENABLE = void>
    struct is_registred_scalar : is_registred_real_scalar<SCALAR> 
    {
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Add std::complex<REAL> 

    template <typename SCALAR>
    struct is_registred_scalar<std::complex<SCALAR>, std::enable_if_t<is_registred_real_scalar<SCALAR>::value>>
        : std::true_type
    {
    };

} /* Kiss */
