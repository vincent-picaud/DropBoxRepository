/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Thu May 05 09:18:43 CEST 2016
*/

#pragma once

#include <type_traits>

namespace Kiss
{

    struct ConjugateTag_Base
    {
    };
    struct ConjugateTag_Conjugate : ConjugateTag_Base
    {
    };
    struct ConjugateTag_Identity : ConjugateTag_Base
    {
    };

    template <typename OBJ>
    using ConjugateTag_Well_Defined =
        std::integral_constant<bool, (!std::is_same<ConjugateTag_Base, OBJ>::value) &&
                                         (std::is_base_of<ConjugateTag_Base, OBJ>::value)>;

} /* Kiss */
