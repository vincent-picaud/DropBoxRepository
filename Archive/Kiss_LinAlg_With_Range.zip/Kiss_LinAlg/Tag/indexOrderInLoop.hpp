#pragma once

namespace Kiss
{
  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define loop order for multidimensional arrays

      For (i,j,k) index

      Alternative:
      - Loop i,j,k : which is @ref PreferedIndexOrderInLoop_Forward "forward"
      - Loop k,j,i : which is @ref PreferedIndexOrderInLoop_Backward "backward"

      Note: do not confound with RowMajor, ColMajor, which are defined by J_stride=1, I_stride=1

      However efficient association is:
      - RowMajor with @ref PreferedIndexOrderInLoop_Forward "forward"
      - ColumnMajor with @ref PreferedIndexOrderInLoop_Backward "backward"
  */
  struct PreferedIndexOrderInLoop_Base
  {
    /** @brief Transposed type */
    typedef PreferedIndexOrderInLoop_Base TransposedType;
  };

  // Forward Declarations required by TransposedType
  //
  struct PreferedIndexOrderInLoop_Forward;
  struct PreferedIndexOrderInLoop_Backward;

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define forward loop order for multidimensional arrays

      @see @ref PreferedIndexOrderInLoop_Base
  */
  struct PreferedIndexOrderInLoop_Backward : PreferedIndexOrderInLoop_Base
  {
    /** @brief Transposed type */
    typedef PreferedIndexOrderInLoop_Forward TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define backward loop order for multidimensional arrays

      @see @ref PreferedIndexOrderInLoop_Base
  */
  struct PreferedIndexOrderInLoop_Forward : PreferedIndexOrderInLoop_Base
  {
    /** @brief Transposed type */
    typedef PreferedIndexOrderInLoop_Backward TransposedType;
  };

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Check if the IndexOrderInLoop is well formed
      @relates PreferedIndexOrderInLoop_Base
  */
  template <typename OBJ>
  constexpr bool PreferedIndexOrderInLoop_Well_Defined = (!std::is_same<PreferedIndexOrderInLoop_Base, OBJ>::value) &&
                                                         (std::is_base_of<PreferedIndexOrderInLoop_Base, OBJ>::value);
}
