/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Thu May 05 09:23:32 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/Tag/conjugateTag.hpp>

namespace Kiss
{

    struct MatrixOpTag_Base
    {
    };

    // Forward declaration
    struct MatrixOpTag_Transpose;
    struct MatrixOpTag_Conjugate;
    struct MatrixOpTag_TransConjugate;
    struct MatrixOpTag_Identity;

    struct MatrixOpTag_Transpose : MatrixOpTag_Base
    {
        using TransposedDimension = std::true_type;
        using Conjugation = ConjugateTag_Identity;
        using Conjugated = MatrixOpTag_TransConjugate;
        using Transposed = MatrixOpTag_Identity;
    };
    struct MatrixOpTag_Conjugate : MatrixOpTag_Base
    {
        using TransposedDimension = std::false_type;
        using Conjugation = ConjugateTag_Conjugate;
        using Conjugated = MatrixOpTag_Identity;
        using Transposed = MatrixOpTag_TransConjugate;
    };
    struct MatrixOpTag_TransConjugate : MatrixOpTag_Base
    {
        using TransposedDimension = std::true_type;
        using Conjugation = ConjugateTag_Conjugate;
        using Conjugated = MatrixOpTag_Transpose;
        using Transposed = MatrixOpTag_Conjugate;
    };
    struct MatrixOpTag_Identity : MatrixOpTag_Base
    {
        using TransposedDimension = std::false_type;
        using Conjugation = ConjugateTag_Identity;
        using Conjugated = MatrixOpTag_Conjugate;
        using Transposed = MatrixOpTag_Transpose;
    };

    template <typename OBJ>
    constexpr bool MatrixOpTag_Well_Defined = (!std::is_same<MatrixOpTag_Base, OBJ>::value) &&
                                              (std::is_base_of<MatrixOpTag_Base, OBJ>::value);

    constexpr auto _MatrixOp_Identity_ = MatrixOpTag_Identity();
    constexpr auto _MatrixOp_Conjugate_ = MatrixOpTag_Conjugate();
    constexpr auto _MatrixOp_Transpose_ = MatrixOpTag_Transpose();
    constexpr auto _MatrixOp_TransConjugate_ = MatrixOpTag_TransConjugate();
} /* Kiss */
