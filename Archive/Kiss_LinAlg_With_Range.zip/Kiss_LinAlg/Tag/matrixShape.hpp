#pragma once

#include <Kiss_LinAlg/Tag/matrixUpLow.hpp>

namespace Kiss
{
  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape

      See @ref MatrixShape_Well_Defined
  */
  struct MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Base MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Base TransposedType;
  };

  // Forward Declarations required by TransposedType
  //
  struct MatrixShape_Full;
  struct MatrixShape_Symmetric;
  struct MatrixShape_Symmetric_UpperStorage;
  struct MatrixShape_Symmetric_LowerStorage;
  struct MatrixShape_Hermitian;
  struct MatrixShape_Hermitian_UpperStorage;
  struct MatrixShape_Hermitian_LowerStorage;
  struct MatrixShape_Triangular;
  struct MatrixShape_UpperTriangular;
  struct MatrixShape_LowerTriangular;
  struct MatrixShape_UnitTriangular;
  struct MatrixShape_UpperUnitTriangular;
  struct MatrixShape_LowerUnitTriangular;

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Full final : MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Irrelevant MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Full TransposedType;
  };

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Symmetric : MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Base MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Base TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Symmetric_UpperStorage final : MatrixShape_Symmetric
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Upper MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Symmetric_LowerStorage TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Symmetric_LowerStorage final : MatrixShape_Symmetric
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Lower MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Symmetric_UpperStorage TransposedType;
  };

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Hermitian : MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Base MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Base TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Hermitian_UpperStorage final : MatrixShape_Hermitian
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Upper MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Hermitian_LowerStorage TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Hermitian_LowerStorage final : MatrixShape_Hermitian
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Lower MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Hermitian_UpperStorage TransposedType;
  };

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_Triangular : MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Base MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Base TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_UpperTriangular final : MatrixShape_Triangular
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Upper MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_LowerTriangular TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_LowerTriangular final : MatrixShape_Triangular
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Lower MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_UpperTriangular TransposedType;
  };

  //================================================================

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_UnitTriangular : MatrixShape_Base
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_Base MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_Base TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_UpperUnitTriangular final : MatrixShape_UnitTriangular
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_UpperStrict MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_LowerUnitTriangular TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Define matrix shape
  */
  struct MatrixShape_LowerUnitTriangular final : MatrixShape_UnitTriangular
  {
    /** @brief Associated UpLow */
    typedef MatrixUpLow_LowerStrict MatrixUpLowType;

    /** @brief Associated TransposedType */
    typedef MatrixShape_UpperUnitTriangular TransposedType;
  };

  /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
      @brief Check if the MatrixShape is well formed
      @relates MatrixShape_Base
  */
  template <typename OBJ>
  constexpr bool MatrixShape_Well_Defined = (!std::is_same<MatrixShape_Base, OBJ>::value) &&
                                            (std::is_base_of<MatrixShape_Base, OBJ>::value);
}
