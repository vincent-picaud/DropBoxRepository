#pragma once

#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

namespace Kiss
{
    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage

        Available storage:
        - @ref MatrixUpLow_Irrelevant "Irrelevant"
        - @ref MatrixUpLow_Lower "Lower"
        - @ref MatrixUpLow_LowerStrict "LowerStrict"
        - @ref MatrixUpLow_Upper "Upper"
        - @ref MatrixUpLow_UpperStrict "UpperStrict"

        See @ref MatrixShape_Well_Defined
    */
    struct MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_Base TransposedType;
    };

    // Forward Declarations required by TransposedType
    //
    struct MatrixUpLow_Irrelevant;
    struct MatrixUpLow_Lower;
    struct MatrixUpLow_LowerStrict;
    struct MatrixUpLow_Upper;
    struct MatrixUpLow_UpperStrict;

    //================================================================

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage
    */
    struct MatrixUpLow_Irrelevant : MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_Irrelevant TransposedType;
    };

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage
    */
    struct MatrixUpLow_Lower : MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_Upper TransposedType;
    };

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage
    */
    struct MatrixUpLow_LowerStrict : MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_UpperStrict TransposedType;
    };

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage
    */
    struct MatrixUpLow_Upper : MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_Lower TransposedType;
    };

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Define storage
    */
    struct MatrixUpLow_UpperStrict : MatrixUpLow_Base
    {
        /** @brief Transposed type */
        typedef MatrixUpLow_LowerStrict TransposedType;
    };

    //================================================================

    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Check if the MatrixUpLow is well formed
        @relates MatrixUpLow_Base
    */
    template <typename OBJ>
    constexpr bool MatrixUpLow_Well_Defined = (!std::is_same<MatrixUpLow_Base, OBJ>::value) &&
                                              (std::is_base_of<MatrixUpLow_Base, OBJ>::value);

    //////////////////////////////////////////////////////////////////

    template <typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_INDEX_TYPE, typename J_INDEX_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, I_SIZE_TYPE, J_SIZE_TYPE, I_INDEX_TYPE, J_INDEX_TYPE>>
    constexpr auto check_index(const MatrixUpLow_Irrelevant&, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                               const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) noexcept
    {
        return (I_idx >= 0) && (I_idx < I_size) && (J_idx >= 0) && (J_idx < J_size);
    }

    template <typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_INDEX_TYPE, typename J_INDEX_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, I_SIZE_TYPE, J_SIZE_TYPE, I_INDEX_TYPE, J_INDEX_TYPE>>
    constexpr auto check_index(const MatrixUpLow_Lower&, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                               const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) noexcept
    {
        return check_index(MatrixUpLow_Irrelevant(), I_size, J_size, I_idx, J_idx) && (I_idx >= J_idx);
    }

    template <typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_INDEX_TYPE, typename J_INDEX_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, I_SIZE_TYPE, J_SIZE_TYPE, I_INDEX_TYPE, J_INDEX_TYPE>>
    constexpr auto check_index(const MatrixUpLow_LowerStrict&, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                               const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) noexcept
    {
        return check_index(MatrixUpLow_Irrelevant(), I_size, J_size, I_idx, J_idx) && (I_idx > J_idx);
    }

    template <typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_INDEX_TYPE, typename J_INDEX_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, I_SIZE_TYPE, J_SIZE_TYPE, I_INDEX_TYPE, J_INDEX_TYPE>>
    constexpr auto check_index(const MatrixUpLow_Upper&, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                               const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) noexcept
    {
        return check_index(MatrixUpLow_Irrelevant(), I_size, J_size, I_idx, J_idx) && (I_idx <= J_idx);
    }

    template <typename I_SIZE_TYPE, typename J_SIZE_TYPE, typename I_INDEX_TYPE, typename J_INDEX_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, I_SIZE_TYPE, J_SIZE_TYPE, I_INDEX_TYPE, J_INDEX_TYPE>>
    constexpr auto check_index(const MatrixUpLow_UpperStrict&, const I_SIZE_TYPE I_size, const J_SIZE_TYPE J_size,
                               const I_INDEX_TYPE I_idx, const J_INDEX_TYPE J_idx) noexcept
    {
        return check_index(MatrixUpLow_Irrelevant(), I_size, J_size, I_idx, J_idx) && (I_idx < J_idx);
    }

#ifdef DOXYGEN_DOC
    /** @ingroup Kiss_LinAlg_Tag_And_Enum_Group
        @brief Check index knowing MatrixUpLow
        @relates MatrixUpLow_Base
    */
    template <typename MATRIXUPLOW, typename = std::enable_if_t<MatrixUpLow_Well_Defined<MATRIXUPLOW>>>
    constexpr auto check_index(const MATRIXUPLOW& tag, const Size_t I_size, const Size_t J_size, const Index_t I_idx,
                               const Index_t J_idx) noexcept;
#endif
}
