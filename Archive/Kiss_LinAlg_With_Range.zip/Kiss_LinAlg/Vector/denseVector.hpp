#pragma once

#include <Kiss_LinAlg/Vector/denseVector_implementation.hpp>
#include <Kiss_LinAlg/MemoryBlock/sharedMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr.hpp>

namespace Kiss
{
  // Note: no real advantage to use create_vector from denseVector_implementation
  //       -> the resulting code is longer
  
  
    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Default Vector Type
         @relates DenseVector_Implementation
    */
    template <typename T>
    using Vector =
        DenseVector_Implementation<Index_t, Size_t, std::integral_constant<Index_t, 1>, SharedMemoryBlock<T> >;

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Create a dynamic vector from its size
         @relates DenseVector_Implementation
    */
    template <typename T>
    Vector<T> create_vector(const Size_t size)
    {
        using VectorType = Vector<T>;
        using VectorStructureType = typename VectorType::VectorStructureType;
        using MemoryBlockType = typename VectorType::MemoryBlockType;

        VectorStructureType vectorStructure(0, size, 1);

        return VectorType(vectorStructure, MemoryBlockType(vectorStructure.required_capacity()));
    }
}
