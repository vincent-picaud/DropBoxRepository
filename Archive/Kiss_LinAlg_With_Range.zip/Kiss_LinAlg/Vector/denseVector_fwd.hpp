/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Sat Apr 30 09:05:52 CEST 2016
*/

#pragma once

namespace Kiss
{

    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE, typename MEMORY_BLOCK,
              typename ENABLE = void>
    class DenseVector_Implementation;

} /* Kiss */
