#pragma once

#include <Kiss_LinAlg/Vector/denseVector_fwd.hpp>
#include <Kiss_LinAlg/Vector/denseVector_map.hpp>
#include <Kiss_LinAlg/Vector/interface_denseVector.hpp>
#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

#include <Kiss_LinAlg/MemoryBlock/interface_memoryBlock_fwd.hpp>
#include <Kiss_LinAlg/MemoryStructure/array_memoryStructure.hpp>

#include <Kiss_LinAlg/Range/array_range.hpp>

#include <Kiss_LinAlg/CWise/cwise_base.hpp>

namespace Kiss
{

    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE, typename MEMORY_BLOCK>
    struct CRTP_TypeTraits<DenseVector_Implementation<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE, MEMORY_BLOCK>>
    {
        static_assert(Is_DynStatArgument<Integer_Common_t, OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE>::value, "");

        using ElementType = typename MEMORY_BLOCK::ElementType;
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Constructor
         @relates DenseVector_Implementation
    */
    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE, typename MEMORY_BLOCK,
              typename = SFINEA_DynStatArgument<Integer_Common_t, OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE>>
    constexpr auto create_vector(const OFFSET_TYPE offset, const SIZE_TYPE size, const STRIDE_TYPE stride,
                                 Interface_MemoryBlock<MEMORY_BLOCK>&& memoryBlock)
    {
        using ToReturnType = DenseVector_Implementation<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE, MEMORY_BLOCK>;
        using MemoryStructureType = typename ToReturnType::VectorStructureType;

        return ToReturnType(MemoryStructureType(offset, size, stride), std::move(memoryBlock.impl()));
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Dense vector Implementation
         @extends Interface_DenseVector
    */
    template <typename OFFSET_TYPE, typename SIZE_TYPE, typename STRIDE_TYPE, typename MEMORY_BLOCK>
        class DenseVector_Implementation < OFFSET_TYPE,
        SIZE_TYPE, STRIDE_TYPE, MEMORY_BLOCK,
        std::enable_if_t<Is_DynStatArgument<Integer_Common_t, OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE>::value &&
                         MemoryBlock_Well_Defined<MEMORY_BLOCK>::value>> final
#ifndef DOXYGEN_DOC
        : public Interface_DenseVector<DenseVector_Implementation<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE, MEMORY_BLOCK>>
#endif
    {
       public:
        using SelfType = DenseVector_Implementation;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        using ElementType = typename TraitsType::ElementType;

        using VectorStructureType = Array_MemoryStructure<OFFSET_TYPE, SIZE_TYPE, STRIDE_TYPE>;
        using MemoryBlockType = MEMORY_BLOCK;
        static_assert(MemoryBlock_Well_Defined<MemoryBlockType>::value, "");

       public:
        /** Default constructor */
        DenseVector_Implementation() : vectorStructure_(), memoryBlock_() { assert(check_invariant()); }

        /** Copy constructor

            @note the memory block is moved!
        */
        DenseVector_Implementation(const VectorStructureType& vectorStructure, MemoryBlockType&& memoryBlock)
            : vectorStructure_(vectorStructure), memoryBlock_(std::move(memoryBlock))
        {
            assert(check_invariant());
        }

        /** Duplicate VectorStructureType constructor

            Role: avoid to retrieve VectorStructureType
        */
        DenseVector_Implementation(const Index_t offset, const Size_t size, const Size_t stride,
                                   MemoryBlockType&& memoryBlock)
            : DenseVector_Implementation(VectorStructureType(offset, size, stride), std::move(memoryBlock))
        {
        }

        /** Move constructor */
        DenseVector_Implementation(SelfType&& toMove) = default;

        /** Initialization with a given size

            # Caveat

            This constructor is deleted because there is no obvious
            way to initialize stride which can be of dynamic or static
            type etc.. This would need some specialization which can
            not be easily implemented as a "method" -> simpler to use
            an external function @ref create_vector()

            Another advantage @ref create_vector() is that you can use
            it as a "factory" to define to __default__ type for @ref
            Vector

        */
        explicit DenseVector_Implementation(const Size_t size) = delete;

        //~~~~~~~~~~~~~~~~

        constexpr auto size() const noexcept { return vectorStructure_.size(); }

        template <typename INDEX_TYPE, typename = SFINEA_DynStatArgument<Integer_Common_t, INDEX_TYPE>>
        constexpr decltype(auto) operator[](const INDEX_TYPE idx) const noexcept
        {
            dynStat_assert((idx >= Static_Integer<0>)&&(idx < size()));

            assert(vectorStructure_.offset_index(idx) < memoryBlock_.capacity());
            return *(memoryBlock_.data() + vectorStructure_.offset_index(idx));
        }

        constexpr auto& operator=(const SelfType& toCopy) const noexcept
        {
            assert(this != &toCopy);

            cwise_copy(*this, toCopy);

            return *this;
        }

        template <typename OTHER_DERIVED>
        constexpr auto& operator=(const Interface_DenseVector<OTHER_DERIVED>& toCopy) const noexcept
        {
            cwise_copy(*this, toCopy);

            return *this;
        }

        constexpr auto& operator=(const ElementType& toCopy) const noexcept
        {
            cwise_filling(*this, toCopy);

            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto data() const noexcept { return memoryBlock_.data() + vectorStructure_.offset(); }
        constexpr auto stride() const noexcept { return vectorStructure_.stride(); }

        //~~~~~~~~~~~~~~~~

        constexpr auto range() const noexcept
        {
            return Array_Range<ElementType, STRIDE_TYPE>(data(), size(), stride());
        }

        constexpr auto range_const() const noexcept
        {
            return Array_Range<const ElementType, STRIDE_TYPE>(data(), size(), stride());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr auto view() const noexcept
        {
            return create_vector(vectorStructure_.offset(), size(), stride(), memoryBlock_.view());
        }

        constexpr auto view_const() const noexcept
        {
            return create_vector(vectorStructure_.offset(), size(), stride(), memoryBlock_.view_const());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        template <typename INTERVAL_LB, typename INTERVAL_SIZE>
        constexpr auto view(const IndexInterval<INTERVAL_LB, INTERVAL_SIZE> indexInterval) const noexcept
        {
            return create_vector(vectorStructure_.offset_index(indexInterval.lowerBound()), indexInterval.size(),
                                 stride(), memoryBlock_.view());
        }

        template <typename INTERVAL_LB, typename INTERVAL_SIZE>
        constexpr auto view_const(const IndexInterval<INTERVAL_LB, INTERVAL_SIZE> indexInterval) const noexcept
        {
            return create_vector(vectorStructure_.offset_index(indexInterval.lowerBound()), indexInterval.size(),
                                 stride(), memoryBlock_.view_const());
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        constexpr bool check_invariant() const noexcept
        {
            bool ok = true;
            ok &= (vectorStructure_.required_capacity() <= memoryBlock_.capacity());
            return ok;
        }

       protected:
        VectorStructureType vectorStructure_;
        MemoryBlockType memoryBlock_;
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    template <typename OFFSET_1_TYPE, typename SIZE_1_TYPE, typename STRIDE_1_TYPE, typename MEMORY_BLOCK_1,
              typename OFFSET_2_TYPE, typename SIZE_2_TYPE, typename STRIDE_2_TYPE, typename MEMORY_BLOCK_2>
    constexpr bool
        operator==(const DenseVector_Implementation<OFFSET_1_TYPE, SIZE_1_TYPE, STRIDE_1_TYPE, MEMORY_BLOCK_1>& d1,
                   const DenseVector_Implementation<OFFSET_2_TYPE, SIZE_2_TYPE, STRIDE_2_TYPE, MEMORY_BLOCK_2>& d2)
    {
        if(d1.size() == d2.size())
        {
            if((void*)d1.data() == (void*)d2.data())
            {
                return (d1.stride() == d2.stride());
            }
            else
            {
                // Loop over element
                return conditional_map(
                    [](const auto& d1_i, const auto& d2_i)
                    {
                        return d1_i == d2_i;
                    },
                    d1, d2);
            }
        }

        return false;  // size !=
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
}
