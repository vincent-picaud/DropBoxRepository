#pragma once

#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Vector/interface_denseVector_fwd.hpp>

namespace Kiss
{

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (v_i,w_i....)
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename DENSEVECTOR_FIRST, typename... DENSEVECTOR_TAIL>
    void map(const LAMBDA& lambda, const Interface_DenseVector<DENSEVECTOR_FIRST>& denseVector_first,
             const Interface_DenseVector<DENSEVECTOR_TAIL>&... denseVector_tail)
    {
        assert(sameStructure(denseVector_first, denseVector_tail...));

        const Size_t size = denseVector_first.size();

#pragma omp simd
        for(Index_t i = 0; i < size; ++i)
        {
            lambda(denseVector_first[i], denseVector_tail[i]...);
        }
    }

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (v_i,w_i....) -> bool
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename DENSEVECTOR_FIRST, typename... DENSEVECTOR_TAIL>
    bool conditional_map(const LAMBDA& lambda, const Interface_DenseVector<DENSEVECTOR_FIRST>& denseVector_first,
                         const Interface_DenseVector<DENSEVECTOR_TAIL>&... denseVector_tail)
    {
        assert(sameStructure(denseVector_first, denseVector_tail...));

        const Size_t size = denseVector_first.size();

        for(Index_t i = 0; i < size; ++i)
        {
            if(!lambda(denseVector_first[i], denseVector_tail[i]...)) return false;
        }
        return true;
    }

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (i,v_i) -> void
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename DENSEVECTOR>
    void indexed_map(const LAMBDA& lambda, const Interface_DenseVector<DENSEVECTOR>& denseVector)
    {
        const Size_t size = denseVector.size();

#pragma omp simd
        for(Index_t i = 0; i < size; ++i)
        {
            lambda(i, denseVector[i]);
        }
    }

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (i,v_i) -> bool
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename DENSEVECTOR>
    bool conditional_indexed_map(const LAMBDA& lambda, const Interface_DenseVector<DENSEVECTOR>& denseVector)
    {
        const Size_t size = denseVector.size();

        for(Index_t i = 0; i < size; ++i)
        {
            if(!lambda(i, denseVector[i])) return false;
        }
        return true;
    }
}
