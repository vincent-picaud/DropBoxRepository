#pragma once

#include <Kiss_LinAlg/Vector/interface_denseVector_fwd.hpp>
#include <Kiss_LinAlg/Vector/interface_vector.hpp>
#include <Kiss_LinAlg/Vector/denseVector_map.hpp>

#include <Kiss_LinAlg/indexInterval.hpp>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Dense vector Interface
         @extends Interface_Vector
    */
    template <typename DERIVED>
    class Interface_DenseVector
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_DenseVector, DERIVED, Interface_Vector>
#endif
    {
       public:
        using SelfType = Interface_DenseVector;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        using ElementType = typename TraitsType::ElementType;

       public:
        /** Component access

            @note this method is constant, read/write access is taken into
            account by type: DenseVector<T> or DenseVector<const T>
            accessible through views
         */
        template <typename INDEX_TYPE, typename = SFINEA_DynStatArgument<Integer_Common_t, INDEX_TYPE> >
        constexpr decltype(auto) operator[](const INDEX_TYPE idx) const noexcept
        {
            return SelfType::impl()[idx];
        }

        constexpr auto& operator=(const SelfType& toCopy) const noexcept { return SelfType::impl() = toCopy.impl(); }

        template <typename OTHER_DERIVED>
        constexpr auto& operator=(const Interface_DenseVector<OTHER_DERIVED>& toCopy) const noexcept
        {
            return SelfType::impl() = toCopy.impl();
        }

        constexpr auto& operator=(const ElementType& toCopy) const noexcept { return SelfType::impl() = toCopy; }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @brief View from an IndexInterval */
        template <typename INTERVAL_LB, typename INTERVAL_SIZE>
        constexpr auto view(const IndexInterval<INTERVAL_LB, INTERVAL_SIZE> indexInterval) const noexcept
        {
            return SelfType::impl().view(indexInterval);
        }

        /** @brief View_Const from an IndexInterval */
        template <typename INTERVAL_LB, typename INTERVAL_SIZE>
        constexpr auto view_const(const IndexInterval<INTERVAL_LB, INTERVAL_SIZE> indexInterval) const noexcept
        {
            return SelfType::impl().view_const(indexInterval);
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** Including offset! */
        constexpr auto data() const noexcept { return SelfType::impl().data(); }
        constexpr auto stride() const noexcept { return SelfType::impl().stride(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        friend std::ostream& operator<<(std::ostream& out, const SelfType& vector)
        {
            map(
                [&](const auto& vector_i)
                {
                    out << "\n" << vector_i;
                },
                vector);

            return out;
        }
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //MACRO_DEFINE_CWISE_INPLACE_OP_ALL(Interface_DenseVector)

    //################################################################

    template <typename D1, typename D2>
    constexpr bool sameStructure(const Interface_DenseVector<D1>& d1, const Interface_DenseVector<D2>& d2) noexcept
    {
        // no extra constraint
        return sameDimension(d1, d2);
    }
}
