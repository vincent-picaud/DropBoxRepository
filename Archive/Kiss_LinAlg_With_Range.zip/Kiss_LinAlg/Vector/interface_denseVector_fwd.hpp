#pragma once

#include <Kiss_LinAlg/crtp.hpp>

namespace Kiss
{
    template <typename DERIVED = CRTP_NoDerivedClassTag>
    class Interface_DenseVector;

    template <typename DERIVED>
    struct DenseVector_Well_Defined
        : std::integral_constant<bool, (std::is_final<DERIVED>::value) &&
                                           (Is_CRTP_Interface<DERIVED, Kiss::Interface_DenseVector>::value)>
    {
    };
} /* Kiss */
