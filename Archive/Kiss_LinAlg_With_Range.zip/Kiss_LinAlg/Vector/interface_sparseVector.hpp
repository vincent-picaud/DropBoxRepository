#pragma once

#include <Kiss_LinAlg/Vector/interface_sparseVector_fwd.hpp>
#include <Kiss_LinAlg/Vector/interface_vector.hpp>
#include <Kiss_LinAlg/Vector/sparseVector_map.hpp>
#include <Kiss_LinAlg/Vector/denseVector.hpp>

namespace Kiss
{

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Sparse vector Interface
         @extends Interface_Vector
    */
    template <typename DERIVED>
    class Interface_SparseVector
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_SparseVector, DERIVED, Interface_Vector>
#endif
    {
       public:
        using SelfType = Interface_SparseVector;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        using ElementType = typename TraitsType::ElementType;

       public:
        constexpr auto nonZero_size() const noexcept { return SelfType::impl().nonZero_size(); }

        /** Returns "mathematical" index of the non-zero component */
        constexpr auto index(const Index_t nonZero_idx) const noexcept { return SelfType::impl().index(nonZero_idx); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** Component access

            @note this method is constant, read/write access is taken into
            account by type: SparseVector<T> or SparseVector<const T>
            accessible through views

            @attention nonZero_idx is the index of the non-zero element!
        */
        constexpr auto& operator[](const Index_t nonZero_idx) const noexcept { return SelfType::impl()[nonZero_idx]; }

        //~~~~~~~~~~~~~~~~

        constexpr auto& operator=(const SelfType& toCopy) const noexcept { return SelfType::impl() = toCopy.impl(); }

        template <typename OTHER_DERIVED>
        constexpr auto& operator=(const Interface_SparseVector<OTHER_DERIVED>& toCopy) const noexcept
        {
            return SelfType::impl() = toCopy.impl();
        }

        constexpr auto& operator=(const ElementType& toCopy) const noexcept { return SelfType::impl() = toCopy; }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @brief Returns view on the data vector */
        auto data_view() const noexcept { return SelfType::impl().data_view(); }
        /** @brief Returns view on the data const vector */
        auto data_view_const() const noexcept { return SelfType::impl().data_view_const(); }

        /** @brief Returns view on the index const vector */
        auto index_view_const() const noexcept { return SelfType::impl().index_view_const(); }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        friend std::ostream& operator<<(std::ostream& out, const SelfType& vector)
        {
            const Size_t nz_size = vector.nonZero_size();

            for(Index_t i = 0; i < nz_size; i++)
            {
                out << "\n" << vector.index(i) << " -> " << vector[i];
            }

            return out;
        }
    };

    //################################################################

    template <typename D1, typename D2>
    constexpr auto sameStructure(const Interface_SparseVector<D1>& d1, const Interface_SparseVector<D2>& d2) noexcept
    {
        return (d1.size() == d2.size()) && (d1.index_view_const() == d2.index_view_const());
    }
}
