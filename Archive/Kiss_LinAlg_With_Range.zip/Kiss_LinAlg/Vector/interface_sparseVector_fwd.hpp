#pragma once

#include <Kiss_LinAlg/crtp.hpp>

namespace Kiss
{
  template <typename DERIVED = CRTP_NoDerivedClassTag>
  class Interface_SparseVector;

} /* Kiss */
