#pragma once

#include <Kiss_LinAlg/Vector/interface_vector_fwd.hpp>
#include <Kiss_LinAlg/Vector/vector_map.hpp>
#include <Kiss_LinAlg/macro.hpp>

#include <Kiss_LinAlg/Range/interface_range_fwd.hpp>

#include <iostream>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Vector
         @extends CRTP_Base
    */
    template <typename DERIVED>
    class Interface_Vector
#ifndef DOXYGEN_DOC
        : public CRTP_Find_BaseType<Interface_Vector, DERIVED, CRTP_Base>
#endif
    {
       public:
        using SelfType = Interface_Vector;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        /** Element type */
        using ElementType = typename TraitsType::ElementType;

       public:
        /** Vector size */
        constexpr auto size() const noexcept { return SelfType::impl().size(); }

        /** Vector deep copy */
        constexpr auto& operator=(const SelfType& toCopy) noexcept { return SelfType::impl() = toCopy; }

        /** Fill vector with a constant */
        constexpr auto& operator=(const ElementType& toCopy) const noexcept { return SelfType::impl() = toCopy; }

        /** Range */
        constexpr auto range() const noexcept { return SelfType::impl().range(); };
        /** Const range */
        constexpr auto range_const() const noexcept { return SelfType::impl().range_const(); };

        /**  View */
        constexpr auto view() const noexcept { return SelfType::impl().view(); };

        /**  Const View */
        constexpr auto view_const() const noexcept { return SelfType::impl().view_const(); };

        //~~~~~~~~~~~~~~~~

        friend auto& operator<<(std::ostream& out, const SelfType& vector) { return (out << vector.impl()); }
    };

    //
    //////////////////////////////////////////////////////////////////
    // MULTI-DISPATCH
    //////////////////////////////////////////////////////////////////
    //

    /**  @ingroup Kiss_LinAlg_MemoryBlock_Group
         @brief Comparison operator
         @relates Interface_Vector
    */
    template <typename D1, typename D2>
    constexpr auto operator==(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2) noexcept
    {
        return (d1.impl() == d1.impl());
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //   MACRO_DECLARE_CWISE_INPLACE_OP_ALL(Interface_Vector)
    MACRO_DEFINE_CWISE_INPLACE_OP_ALL(Interface_Vector)

    //################################################################

    template <typename DERIVED>
    constexpr auto sameDimension(const Interface_Vector<DERIVED>&) noexcept
    {
        return true;
    }

    /** @ingroup Kiss_LinAlg_Vector_Group
        @brief Check vector dimensions
        @relates Interface_Vector

        @note also works for any number of vectors
    */
    template <typename D1, typename D2>
    constexpr auto sameDimension(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2) noexcept
    {
        /** @note no need for futher overloading */
        return d1.size() == d2.size();
    }

    template <typename D1, typename D2, typename... DN>
    constexpr auto sameDimension(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2,
                                 const Interface_Vector<DN>&... dn) noexcept
    {
        return sameDimension(d1.impl(), d2.impl()) && sameDimension(d2.impl(), dn.impl()...);
    }

    //################################################################

    template <typename DERIVED>
    constexpr auto sameStructure(const Interface_Vector<DERIVED>&) noexcept
    {
        return true;
    }

    /** @ingroup Kiss_LinAlg_Vector_Group
        @brief Check vector structure
        @relates Interface_Vector

        @note also works for any number of vectors
    */
    template <typename D1, typename D2>
    constexpr auto sameStructure(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2) noexcept
    {
        /** Default is false */
        return false;
    }

    template <typename D1, typename D2, typename... DN>
    constexpr auto sameStructure(const Interface_Vector<D1>& d1, const Interface_Vector<D2>& d2,
                                 const Interface_Vector<DN>&... dn) noexcept
    {
        return sameStructure(d1, d2) && sameStructure(d2, dn...);
    }
}
