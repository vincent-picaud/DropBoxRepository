#pragma once

#include <Kiss_LinAlg/crtp.hpp>
#include <Kiss_LinAlg/indexType.hpp>

namespace Kiss
{
  template <typename DERIVED = CRTP_NoDerivedClassTag>
  class Interface_Vector;

} /* Kiss */
