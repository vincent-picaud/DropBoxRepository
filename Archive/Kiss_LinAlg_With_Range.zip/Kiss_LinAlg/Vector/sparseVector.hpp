/** @ingroup Kiss_LinAlg_Vector_Group
    @file   
    @brief SparseVector header file
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Sat Apr 30 08:55:05 CEST 2016
*/
#include <Kiss_LinAlg/Vector/sparseVector_implementation.hpp>
