/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Sat Apr 30 09:03:01 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Vector/denseVector_fwd.hpp>
#include <Kiss_LinAlg/MemoryBlock/sharedMemoryBlock_fwd.hpp>

namespace Kiss
{

    // TODO SFINEA
    template <typename DATA_DENSEVECTOR, typename ENABLE = void>
    class SparseVector_Implementation;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    // Define the vector type used to store index
    //
    // CAVEAT
    // 1/ SparseVector store a __constant__ DenseVector of indices
    //    --> use __const Index_t__
    //
    // 2/ This dense vector is __shared__ across SparseVector instance
    //    --> use a SharedMemoryBlock<T>
    //
    using SparseVector_Index_DenseVector_Const_Type =
        DenseVector_Implementation<Index_t, Size_t, std::integral_constant<Index_t, 1>,
                                   SharedMemoryBlock<const Index_t>>;

    // This type is defined for user convenience to allow him
    // to construct (mutable Index_t) the sparsity pattern
    //
    using SparseVector_Index_DenseVector_Type =
        DenseVector_Implementation<Index_t, Size_t, std::integral_constant<Index_t, 1>, SharedMemoryBlock<Index_t>>;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

} /* Kiss */
