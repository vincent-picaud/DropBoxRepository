#pragma once

#include <Kiss_LinAlg/Vector/sparseVector_fwd.hpp>

#include <Kiss_LinAlg/Vector/interface_sparseVector.hpp>

#include <Kiss_LinAlg/Vector/denseVector.hpp>
#include <Kiss_LinAlg/Vector/sparseVector_map.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>

namespace Kiss
{

    template <typename DATA_DENSEVECTOR>
    struct CRTP_TypeTraits<SparseVector_Implementation<DATA_DENSEVECTOR>>
    {
        static_assert(DenseVector_Well_Defined<DATA_DENSEVECTOR>::value, "");

        using ElementType = typename DATA_DENSEVECTOR::ElementType;
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Sparse vector Implementation
         @extends Interface_SparseVector
    */
    template <typename DATA_DENSEVECTOR>
    class SparseVector_Implementation<DATA_DENSEVECTOR,
                                      std::enable_if_t<DenseVector_Well_Defined<DATA_DENSEVECTOR>::value>> final
#ifndef DOXYGEN_DOC
        : public Interface_SparseVector<SparseVector_Implementation<DATA_DENSEVECTOR>>
#endif
    {
        template <typename OTHER_DATA_DENSEVECTOR, typename ENABLE>
        friend class SparseVector_Implementation;

       public:
        using SelfType = SparseVector_Implementation;
        using ExactType = typename SelfType::ExactType;
        using TraitsType = CRTP_TypeTraits<ExactType>;

        using ElementType = typename TraitsType::ElementType;

       public:
        SparseVector_Implementation() : size_(0), index_denseVector_(), data_denseVector_()
        {
            assert(check_invariant());
        }

        SparseVector_Implementation(const Size_t size, SparseVector_Index_DenseVector_Const_Type&& index_denseVector,
                                    DATA_DENSEVECTOR&& data_denseVector)
            : size_(size)
            , index_denseVector_(std::move(index_denseVector))
            , data_denseVector_(std::move(data_denseVector))
        {
            assert(check_invariant());
        }

        SparseVector_Implementation(SelfType&& toMove) = default;

        /** Initialization with a given size

            Caveat this constructor is delete, as explained in @ref DenseVector_Implementation
        */
        SparseVector_Implementation(const Size_t size, const Size_t nonZero_size) = delete;

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // INTERFACE
        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        Size_t size() const noexcept { return size_; };
        Size_t nonZero_size() const noexcept { return data_denseVector_.size(); }

        auto& operator[](const Index_t idx) const noexcept { return data_denseVector_[idx]; }

        auto index(const Index_t nonZero_idx) const noexcept { return index_denseVector_[nonZero_idx]; }

        auto& operator=(const SelfType& toCopy) const noexcept
        {
            assert(this != &toCopy);
            assert(index_denseVector_ == toCopy.index_denseVector_);

            cwise_copy(data_denseVector_, toCopy.data_denseVector_);

            return *this;
        }

        template <typename OTHER_DERIVED>
        auto& operator=(const Interface_SparseVector<OTHER_DERIVED>& toCopy) const noexcept
        {
            assert(index_denseVector_ == toCopy.index_denseVector_);

            cwise_copy(data_denseVector_, toCopy.data_denseVector_);

            return *this;
        }

        auto& operator=(const ElementType& toCopy) const noexcept
        {
            cwise_filling(data_denseVector_, toCopy);

            return *this;
        }

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        auto view() const noexcept
        {
            return create_sparseVector(size(), index_denseVector_.view_const(), data_denseVector_.view());
        }
        auto view_const() const noexcept
        {
            return create_sparseVector(size(), index_denseVector_.view_const(), data_denseVector_.view_const());
        }

        auto index_view_const() const noexcept { return index_denseVector_.view_const(); };

        auto data_view() const noexcept { return data_denseVector_.view(); };
        auto data_view_const() const noexcept { return data_denseVector_.view_const(); };

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        bool check_invariant() const noexcept
        {
            bool ok = true;
            ok &= (data_denseVector_.size() == index_denseVector_.size());
            if(data_denseVector_.size() > 0)
            {
                ok &= cwise_min(index_denseVector_) >= 0;
                ok &= cwise_max(index_denseVector_) < size_;
            }
            return ok;
        }

       protected:
        Size_t size_;
        SparseVector_Index_DenseVector_Const_Type index_denseVector_;
        DATA_DENSEVECTOR data_denseVector_;

        //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /** @internal */
        friend constexpr auto& impl_get_index_denseVector(const SelfType& self) noexcept
        {
            return self.index_denseVector_;
        };

        /** @internal */
        friend constexpr auto& impl_get_data_denseVector(const SelfType& self) noexcept
        {
            return self.data_denseVector_;
        };
    };


        // template <typename DATA_DENSEVECTOR, typename OTHER_DATA_DENSEVECTOR>
        // constexpr auto sameStructure(const SparseVector_Implementation<DATA_DENSEVECTOR>& self,
        //                              const SparseVector_Implementation<OTHER_DATA_DENSEVECTOR>& other) noexcept
        // {
        //     return (self.size() == other.size()) &&
        //            (impl_get_index_denseVector(self) == impl_get_index_denseVector(other));
        // }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * @ingroup Kiss_LinAlg_Vector_Group
     *
     * @brief Create a sparse vector
     *
     * @relates SparseVector_Implementation
     */
    template <typename DATA_DENSEVECTOR>
    auto create_sparseVector(const Size_t size, const SparseVector_Index_DenseVector_Const_Type& nonZero_index,
                             Interface_DenseVector<DATA_DENSEVECTOR>&& data_denseVector)
    {

        return SparseVector_Implementation<DATA_DENSEVECTOR>(size, nonZero_index.view_const(),
                                                             std::move(data_denseVector.impl()));
    }

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /**
     * @ingroup Kiss_LinAlg_Vector_Group
     *
     * @brief Default Sparse Vector Type
     *
     * @relates SparseVector_Implementation
     */
    template <typename T>
    using SparseVector = SparseVector_Implementation<Vector<T>>;

    /**  @ingroup Kiss_LinAlg_Vector_Group
         @brief Create a dynamic sparse vector
         @relates SparseVector_Implementation
    */
    template <typename T>
    auto create_sparseVector(const Size_t size, const SparseVector_Index_DenseVector_Const_Type& nonZero_index)
    {
        return SparseVector<T>(size, nonZero_index.view_const(), create_vector<T>(nonZero_index.size()));
    }
}
