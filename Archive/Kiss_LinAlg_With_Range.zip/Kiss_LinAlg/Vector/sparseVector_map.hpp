/** @ingroup Kiss_XXX
    @file
    @brief XXX
    @author Vincent Picaud (vincent.picaud@cea.fr)
    @date Fri Apr 29 15:39:57 CEST 2016
*/

#pragma once

#include <Kiss_LinAlg/Vector/interface_sparseVector_fwd.hpp>
#include <Kiss_LinAlg/Vector/denseVector_map.hpp>

namespace Kiss
{
    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (v_i,w_i....)
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename SPARSEVECTOR_FIRST, typename... SPARSEVECTOR_TAIL>
    void map(const LAMBDA& lambda, const Interface_SparseVector<SPARSEVECTOR_FIRST>& sparseVector_first,
             const Interface_SparseVector<SPARSEVECTOR_TAIL>&... sparseVector_tail)
    {
        assert(sameStructure(sparseVector_first.impl(), sparseVector_tail.impl()...));

        map(lambda, sparseVector_first.data_view(), sparseVector_tail.data_view()...);
    }

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (i,v_i) -> void
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename SPARSEVECTOR>
    void indexed_map(const LAMBDA& lambda, const Interface_SparseVector<SPARSEVECTOR>& sparseVector)
    {
        // Use DenseVector map on Index & Value
        map(
            [&](const Index_t& idx, const auto& value_idx)
            {
                lambda(idx, value_idx);
            },
            sparseVector.index_view_const(), sparseVector.data_view());
    }

} /* Kiss */
