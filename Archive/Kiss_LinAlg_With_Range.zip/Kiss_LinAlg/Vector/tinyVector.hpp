#pragma once

#include <Kiss_LinAlg/Vector/denseVector_implementation.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_rawPtr.hpp>

namespace Kiss
{
    /**  @ingroup Kiss_LinAlg_Vector_Group
           @brief Tiny dense vector
           @relates DenseVector_Implementation
      */
    template <typename T, Size_t SIZE>
    using TinyVector =
        DenseVector_Implementation<std::integral_constant<Index_t, 0>, std::integral_constant<Size_t, SIZE>,
                                   std::integral_constant<Index_t, 1>, TinyMemoryBlock<T, SIZE> >;
}
