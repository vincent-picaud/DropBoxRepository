#pragma once

#include <Kiss_LinAlg/Vector/interface_vector_fwd.hpp>

namespace Kiss
{

    //
    //////////////////////////////////////////////////////////////////
    //
    // Lambda (v_i,w_i....)
    //
    //////////////////////////////////////////////////////////////////
    //
    template <typename LAMBDA, typename... Dn>
    auto map(const LAMBDA& lambda, const Interface_Vector<Dn>&... dn)
    {
        return map(lambda, dn.impl()...);
    }
}
