#pragma once

#include <Kiss_LinAlg/macro.hpp>

#include <type_traits>
#include <cassert>

namespace Kiss
{

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief Define CRTP idiom type traits
    */
    struct CRTP_NoDerivedClassTag final
    {
    };

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief Define CRTP idiom type traits
    */
    template <typename DERIVED>
    struct CRTP_TypeTraits;

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief Define CRTP idiom
    */
    template <typename DERIVED = CRTP_NoDerivedClassTag>
    class CRTP_Base
    {

        using SelfType = CRTP_Base;

       public:
        /** Exact type */
        using ExactType = DERIVED;

       public:
        /** Prevent initialization if ExactType is not **final**  */
        constexpr CRTP_Base() noexcept { static_assert(std::is_final<ExactType>::value, "Avoid object slicing"); }

        /** Returns (const) interface implementation */
        constexpr decltype(auto) impl() const noexcept { return static_cast<const ExactType&>(*this); }
        /**  Returns interface implementation */
        constexpr decltype(auto) impl() noexcept { return static_cast<ExactType&>(*this); }
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief An helper to retrieve BaseType
    */
    template <template <typename> class THIS, typename DERIVED, template <typename> class BASE>
    using CRTP_Find_BaseType = BASE<typename std::conditional<std::is_same<DERIVED, CRTP_NoDerivedClassTag>::value,
                                                              THIS<CRTP_NoDerivedClassTag>, DERIVED>::type>;

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief Static interface check, false
    */
    template <typename TOCHECK, template <typename /* DERIVED */> class CRTP_Interface, typename ENABLE = void>
    struct Is_CRTP_Interface : std::integral_constant<bool, false>
    {
    };

    /** @ingroup Kiss_LinAlg_CRTP_Group
        @brief Static interface check, true
    */
    template <typename TOCHECK, template <typename /* DERIVED */> class CRTP_Interface>
    struct Is_CRTP_Interface<TOCHECK, CRTP_Interface,
                             typename std::enable_if<std::is_base_of<CRTP_Interface<typename TOCHECK::ExactType>,
                                                                     typename TOCHECK::ExactType>::value>::type>
        : std::integral_constant<bool, true>
    {
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Inplace operators +=, -= etc...
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    MACRO_DECLARE_CWISE_INPLACE_OP_ALL(CRTP_Base);

} /* Kiss */
