/** @todo
	-# Weel defined a definir comme integral_constant -> permet d'utiliser pleinement propagation des static
    -# Vue a finir pour Crs_Matrix & SparseVector
    -# Prendre en comptre MatrixShapre pour  Crs_Matrix
    -# Creer Ccs_Matrix (quand Crs_Matrix ets OK)
*/

/** @mainpage
 *
 * # Regex qurey-replace-regexp
 * @code
 * I_size(\([^)]\)) -> \1.I_size()
 * @endcode
 *
 * Attention when using **regexp-builder** \ must be replaced by \\ 
 * Do not forget to remove " and \\ -> \ when using query-replace-regexp
 *
 * Another example: check_index(m,toto) -> m.check_index(toto)
 * check_index(\([^,]+\),\([^)]+\)) -> \1.check_index(\2)
 *
 * # "Exprimental" design
 * ## MemoryBlock and MemoryStructure
 * - MemoryStructure is a base object defining memory pattern to store data,
 *   see @ref Kiss_LinAlg_MemoryStructure_Group
 * - MemoryBlock is a base object to allocate, serialize... memory block or even raw pointers (for views).
 *   See @ref Kiss_LinAlg_MemoryBlock_Group for futher details
 *
 * ## Heavy use of CRTP + differed interface definition
 * @anchor Kiss_LinAlg_Finalize_Section
 *
 * Consider
 * @code
 * template<DERIVED>
 * void doComputation(const Interfac_Matrix<DERIVED>& matrix)
 * {
 *     // Here default implementation
 * }
 * @endcode
 * also consider
 * @code
 * template<DERIVED>
 * void foo(const Interfac_Matrix<DERIVED>& matrix)
 * {
 *     doComputation(matrix);
 * }
 * @endcode
 * The problem is: __how to be sure that we use the most specialized version of doComputation??__
 * 
 * For instance if you have specialized __doComputation__ for DenseMatrix type
 * @code
 * template<DERIVED>
 * void doComputation(const Interface_DenseMatrix<DERIVED>& matrix)
 * {
 *     // Here specialized implementation
 * }
 * @endcode
 * a call to __foo__ will still use the __default implementation__.
 *
 * The currently used solution is as follow:
 * @code
 * namespace Impl {
 *   template<DERIVED>
 *   void doComputation(const Interfac_Matrix<DERIVED>& matrix)
 *   {
 *     // Here default implementation
 *   }
 * }
 * //...
 * namespace Impl {
 *   template<DERIVED>
 *   void doComputation(const Interfac_DenseMatrix<DERIVED>& matrix)
 *   {
 *     // Here specialized implementation
 *   }
 * }
 * @endcode
 * then define a special file __doComputation_finalize.hpp__ you have to *include* at the __very end__
 * (just before instantation, in cpp files mainly)
 * @code
 * namespace Impl {
 *   template<DERIVED>
 *   void doComputation(const CRTP_Base<DERIVED>& matrix)
 *   {
 *     static_assert(!std::is_same<DERIVED,DERIVED>::value, // differed false
 *                   "Missing specialization!");
 *   }
 * }
 * void doComputation(const Interface_Matrix<DERIVED>& matrix)
 * {
 *     Impl::doComputation(matrix.impl()); // Jump to inheritance bound
 * }
 * @endcode
 *
 * The file @ref map_finalize.hpp follows this rule.
 *
 * This not a _lightweight_ solution, but I have not found other way...
 *
 * To lightened this we provide a @ref Kiss_LinAlg_Global_Finalize_File_Group "global finalize file"
 *
 * ## Mix between Static/Dynamic literal type
 *
 * Based on @ref DynStatValue<> . Advantage does not "block" a special
 * value used to tag static/dynamic value.  Example: Eigen use __-1__
 * to tag __dynamic size__. Here the difference is tied to a different
 * type, not a different value.
 *
 * Moreover the file @ref integral_constant_manip.hpp define a __static arithmetic__
 * that is __more general__ and __less restricted__ than the use of __constexpr__
 *
 * ## Constness
 * Containers mimic pointer declaration semantic:
 *
 * Pointer  | Container       | ElementType |
 * ---------|-----------------|-------------|
 * T*       | Vector<T>       | T           |
 * T* const | const Vector<T> | T           |
 * const T* | Vector<const T> | const T     |
 *
 * Hence:
 *
 * @code
 * Vector<const T> v_const;
 * const Vector<T> const_v;
 * const_v[5]=3;       // valid
 * v_const[5]=3;       // NOT valid
 * v_const.resize(20); // valid
 * const_v.resize(20); // NOT valid
 * @endcode
 *
 * The idea is that:
 * @code
 * const Vector<T> v;
 * @endcode
 * has a a constant @b structure (can be resized etc...)
 *
 * @code
 * Vector<const T> v;
 * @endcode
 * has constant @b component
 *
 * ### CAVEAT View in TypeTraits
 *
 * ## Constructor and type
 * Because we can generate a lot of different type, we follow the following scheme:
 * @snippet Kiss_LinAlg/Matrix/denseMatrix.hpp ConstructorAndType
 *
 * ## Copy constructor
 * ### Move memory block
 * For efficiency reason we do not want to **deep-copy** memory block. Generally we only use **move**
 * @snippet Kiss_LinAlg/Vector/denseVector.hpp DenseVector_MoveMemoryBlock
 *
 * ### Do not try to provide full-cases copy constructor
 *
 * **use deported multi-dispatch* instead:
 *
 * The origin of the problem with copy constructors is that you have __two fixed types to manage__:
 * - the __created object__
 * - the __object to copy__
 * and both are  __generally of different types__: the __created object__ must have __offset=0__ and optimized
 *__strides__ for instance.
 *
 * Managing the __two arbitrary types at the same time__ is really tricky!
 *
 * To perform a copy it is much more easier to use a function like these ones:
 * @snippet Kiss_LinAlg/Matrix/denseMatrix.hpp HowToImplementCopyConstructor
 *
 * These functions __control the output type__ and the right type to create is them natural.
 *
 * ** Another advantage is that you reduce __coupling__ between header files**
 *
 * # Rules
 * ## MemoryBlock
 * - @b delete copy constructor and assignment operator...
 *
 * Reason: too inefficient, use the associated structur to only copy relevant components
 *
 * Example
 * @code
 * TinyMemoryBlock(const TinyMemoryBlock<T, CAPACITY>& toCopy) = delete;
 * TinyMemoryBlock<T, CAPACITY>& operator=(const TinyMemoryBlock<T, CAPACITY>& toCopy) = delete;
 * @endcode
 *
 * ## Containers (MemoryBlock, Vector...)
 * - ElementType can be either __T__ or __const T__ 
 *
 * ## Static interface
 * - Use @b auto and @b decltype(auto), reasons:
 *    - this turns run-time errors into compile-time errors
 *
 * ## Ranges
 * ### Must be easy and cheap to copy
 * - algorithms like @ref cwise_copy() receive a @b constant @b reference, reasons:
 *     - Interface_Range must be easy to copy
 *     - Similar to iterator in std lib
 *     - Can catch rvalue
 *
 * ### Range are temporaries and often copied
 *
 * -> Use __raw pointers__ in function like __create_range(T* p,...)__
 * -> Do __NOT__ use stuff like shared_ptr etc...
 *
 * ### Try as much as possible to stick to std::literal_type
 * - This a necessary condition for static loop unrolling
 *
 * # Traps
 * ## pointer arithmetic is unsigned!
 * Expressions like
 * @code
 * p_front_(p),
 * p_back_(p + (size - 1) * stride
 * @endcode
 * must be discarded because if @b size=0 then
 * @code
 * p_front_ = 0x0
 * p_back_0 = xfffffffffffffffc
 * @endcode
 * and
 * @code
 * is_empty() { return p_front_>p_back_; };
 * @endcode
 * return @b false
 *
 * Unfortunately I have no other alternative than to add a test
 * @code
 * if(size_==0) {
 *    p_back_  = nullptr;
 *    p_front_ = p_back_ + 1;
 * }
 * else {
 *    p_front_ = p;
 *    p_back_  = p + (size - 1) * stride;
 * }
 * @endcode
 * this bug was present in @ref Interface_Range and @ref Interface_VectorStructure
 */

/** @section Kiss_LinAlg_Section Kiss Math Module
 */

//================================================================

/** @defgroup Kiss_LinAlg_CRTP_Group Static interface (CRTP)
    @brief Heavy use of the CRTP idiom
 */

//================================================================

/** @defgroup Kiss_LinAlg_Index_Group Integer, Index, Size... related stuff
    @brief Integer, Index, Size... related stuff
 */

//================================================================

/** @defgroup Kiss_LinAlg_Meta_Group Meta programming
    @brief Meta programming
*/

//________________________________________________________________

/** @ingroup Kiss_LinAlg_Meta_Group
    @defgroup Kiss_LinAlg_Meta_DynStat_Group Dynamic/Static cohabitation
    @brief Dynamic/Static cohabitation

    An attempt to factorize code for dynamic/static size, stride etc...
*/

//================================================================

/** @defgroup Kiss_LinAlg_Tag_And_Enum_Group Tag objects and enums
    @brief Tag objects and enums
*/

//================================================================

/** @defgroup Kiss_LinAlg_MemoryStructure_Group Memory Structure
    @brief Memory Structure


*/

//________________________________________________________________

/** @ingroup Kiss_LinAlg_MemoryStructure_Group
    @defgroup Kiss_LinAlg_MemoryStructure_Group Interface
    @brief Interface
*/

//================================================================

/** @defgroup Kiss_LinAlg_MemoryBlock_Group Memory Block
    @brief Memory Block

    # Constness

    Miminic pointer behavior:
    const_1 T* const_2  <-> const_2 memoryBlock<const_1 T>

    const_1 means constant @b componenent
    const_2 means constant @b structure

    See:
    @snippet test/MemoryBlock/check_memoryBlock.cpp Const_Property

*/

//================================================================

/** @defgroup Kiss_LinAlg_Range_Group Range
    @brief Range
*/

//________________________________________________________________

/** @ingroup Kiss_LinAlg_Range_Group Range
    @defgroup Kiss_LinAlg_Details_Range_Group Details
    @brief Details
*/


//________________________________________________________________

/** @ingroup Kiss_LinAlg_Range_Group
    @defgroup Kiss_LinAlg_Range_Algorithms_Group Algorithms
    @brief Algorithms
*/

//________________

/** @ingroup Kiss_LinAlg_Range_Algorithm_Group
    @defgroup Kiss_LinAlg_Range_CWise_Group Componenent wise operations
    @brief Componenent wise operations
    @deprecated
*/

//================================================================

/** @defgroup Kiss_LinAlg_CWise_Group CWise operations
    @brief CWise operations
*/

//==================================================

/** @defgroup Kiss_LinAlg_Vector_Group Vector
    @brief Vector
*/

//==================================================

/** @defgroup Kiss_LinAlg_Matrix_Group Matrix
    @brief Matrix
*/
