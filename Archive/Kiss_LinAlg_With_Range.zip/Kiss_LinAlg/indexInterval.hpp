#pragma once

#include <Kiss_LinAlg/indexType.hpp>
#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

// #include <boost/serialization/nvp.hpp>

namespace Kiss
{
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // IndexInterval
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @ingroup Kiss_LinAlg_Index_Group
        @brief Strongly typed IndexInterval

        Strong typing allows a better control on (static/dynamic) values for
        bounds, size...

        usage example:
        @snippet test/check_indexInterval.cpp ConstExpr
        @snippet test/check_indexInterval.cpp UpperBoundTypeDeduction
    */
    template <typename LOWERBOUND_TYPE = Index_t, typename SIZE_TYPE = Size_t>
    class IndexInterval
    {
       public:
        using LowerBoundType = DynStatValue<LOWERBOUND_TYPE>;
        using SizeType = DynStatValue<SIZE_TYPE>;
        //! @todo remove me!
        using is_static_lowerBound = typename LowerBoundType::is_static;
        using is_static_size = typename SizeType::is_static;
        using is_static_upperBound =
            std::conditional_t<is_static_lowerBound::value && is_static_size::value, std::true_type, std::false_type>;

       public:
        constexpr IndexInterval() noexcept = default;
        constexpr IndexInterval(const Index_t lowerBound, const Size_t size) noexcept : lowerBound_(lowerBound),
                                                                                        size_(size)
        {
            assert(size >= 0);
        }

        constexpr SIZE_TYPE size() const { return size_; }
        constexpr auto is_empty() const noexcept { return size_ <= Static_Integer<0>; }

        constexpr LOWERBOUND_TYPE lowerBound() const noexcept { return lowerBound_; };
        constexpr auto upperBound() const noexcept { return lowerBound() + size() - Static_Integer<1>; };

       protected:
        LowerBoundType lowerBound_;
        SizeType size_;
    };

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Constructors
    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    /** @ingroup Kiss_LinAlg_Index_Group
        @brief Creates a IndexInterval from its lowerBound & size
        @relates IndexInterval
    */
    template <typename LOWERBOUND_TYPE, typename SIZE_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, LOWERBOUND_TYPE, SIZE_TYPE> >
    constexpr auto create_indexInterval_lb_size(const LOWERBOUND_TYPE lowerBound, const SIZE_TYPE size) noexcept
    {
        return IndexInterval<LOWERBOUND_TYPE, SIZE_TYPE>(lowerBound, size);
    }

    template <typename LOWERBOUND_TYPE, typename UPPERBOUND_TYPE,
              typename = SFINEA_DynStatArgument<Integer_Common_t, LOWERBOUND_TYPE, UPPERBOUND_TYPE> >
    constexpr auto create_indexInterval_lb_ub(const LOWERBOUND_TYPE lowerBound,
                                              const UPPERBOUND_TYPE upperBound) noexcept
    {
        return create_indexInterval_lb_size(lowerBound, upperBound - lowerBound + Static_Integer<1>);
    }
}
