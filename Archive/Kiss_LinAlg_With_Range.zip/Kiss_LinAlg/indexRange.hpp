// // A NETTOYER!!!
// #pragma once

// #include <Kiss_LinAlg/indexType.hpp>

// #include <type_traits>
// #include <cassert>
// #include <limits>
// #include <iostream>

// #include <boost/serialization/nvp.hpp>

// namespace Kiss
// {

//     //!@{
//     /**
//      * @ingroup Core_Group
//      * @brief Avoid confusion between size & bounds
//      *
//      * @code
//      * IndexRange(LowerBound,Size)
//      * IndexRange(LowerBound,UpperBound)
//      * @endcode
//      *
//      */
//     class Size
//     {
//        public:
//         constexpr operator Size_t() const;

//         constexpr explicit Size(const Size_t size);

//        private:
//         Size_t size_;
//     };

//     class LowerBound
//     {

//        public:
//         constexpr operator Index_t() const;

//         constexpr explicit LowerBound(const Index_t lowerBound);

//        private:
//         Index_t lowerBound_;
//     };

//     class UpperBound
//     {
//        public:
//         constexpr operator Index_t() const;

//         constexpr explicit UpperBound(const Index_t upperBound);

//        private:
//         Index_t upperBound_;
//     };
//     //!@}

//     ////////////////////////////////////////////////////

//     class IndexRange;

//     /**
//      * @ingroup Core_Group
//      * @brief Returns a scaled index range \f$ \alpha \rrbracket a,b \llbracket \f$
//      *
//      * @note this subroutine handles the \f$ \alpha<0 \f$ case
//      */
//     template <typename SCALAR>
//     constexpr typename std::enable_if<std::numeric_limits<SCALAR>::is_integer, IndexRange>::type
//         operator*(const SCALAR& scalar, const IndexRange& range);

//     /**
//      * @ingroup Core_Group
//      * @brief Screen output
//      */
//     static inline std::ostream& operator<<(std::ostream& out, const IndexRange& range);

//     /**
//      * @ingroup Core_Group
//      * @brief An index range of the form \f$ \rrbracket a,b \llbracket \f$
//      */
//     class IndexRange
//     {
//        public:
//         constexpr IndexRange();
//         constexpr IndexRange(const Size_t& size);
//         constexpr IndexRange(const LowerBound& lowerBound, const Size& size);
//         constexpr IndexRange(const LowerBound& lowerBound, const UpperBound& upperBound);

//         constexpr Size_t size() const;
//         constexpr void resize(const Size_t size);

//         constexpr bool operator==(const IndexRange& toCompare) const;
//         constexpr bool operator!=(const IndexRange& toCompare) const;

//         constexpr IndexRange operator+(const Index_t& translate) const;
//         constexpr IndexRange operator-(const Index_t& translate) const;

//         constexpr IndexRange translate_to_zero() const;

//         constexpr bool is_empty() const;

//         constexpr Index_t begin() const;
//         constexpr Index_t end() const;

//         constexpr Index_t lowerBound() const;
//         constexpr Index_t upperBound() const;

//         /** (lb+ub)/2
//          */
//         constexpr Index_t mid() const;

//         /** @brief Returns the left part of the relative complement
//          *
//          * The relative complement is \f$ B\\A=\{ x \in B | x \notin A \} \f$
//          *
//          * Here @b *this is \f$ B \f$.
//          *
//          * The problem is that \f$ B\\A \f$ can be two intervals, here we return the left one (possibly empty; i.d.
//          *size=0)
//          */
//         constexpr IndexRange left_relative_complement(const IndexRange& A) const;
//         /** @copydoc left_relative_complement */
//         constexpr IndexRange right_relative_complement(const IndexRange& A) const;

//         /** @brief Checks if ranges intersection if not empty
//          */
//         constexpr bool intercepts(const IndexRange& range) const;

//         /** @brief Checks if a range contains a index
//          */
//         constexpr bool contains(const Index_t& index) const;

//         /** @brief Checks if a range contains another range
//          */
//         constexpr bool contains(const IndexRange& range) const;

//         /** @brief Returns intersection of two ranges
//          */
//         constexpr IndexRange intersection(const IndexRange& other) const;

//         /** @brief Returns the smallest range containing the two initial ranges
//          */
//         constexpr IndexRange merge(const IndexRange& other) const;

//         //////////////////////////////////////////////////// Private

//        private:
//         friend class boost::serialization::access;

//         template <class Archive>
//         inline void serialize(Archive& ar, const unsigned int version);

//        private:
//         Size_t size_;
//         Index_t index_;
//     };

//     //****************************************************************
//     //****************************************************************
//     //****************************************************************

//     constexpr Size::operator Size_t() const { return size_; };

//     constexpr Size::Size(const Size_t size) : size_(size) { assert(size >= 0); }

//     ////////////////////////////////////////////////////

//     constexpr LowerBound::operator Index_t() const { return lowerBound_; };

//     constexpr LowerBound::LowerBound(const Index_t lowerBound) : lowerBound_(lowerBound) {}

//     ////////////////////////////////////////////////////

//     constexpr UpperBound::operator Index_t() const { return upperBound_; };

//     constexpr UpperBound::UpperBound(const Index_t upperBound) : upperBound_(upperBound) {}

//     ////////////////////////////////////////////////////

//     constexpr IndexRange::IndexRange() : size_(), index_(0) {}

//     constexpr IndexRange::IndexRange(const Size_t& size) : size_(size), index_(0) {}

//     constexpr IndexRange::IndexRange(const LowerBound& lowerBound, const Size& size) : size_(size), index_(lowerBound)
//     {
//     }

//     constexpr IndexRange::IndexRange(const LowerBound& lowerBound, const UpperBound& upperBound)
//         : size_(upperBound - lowerBound + 1), index_(lowerBound)
//     {
//     }

//     constexpr Size_t IndexRange::size() const { return size_; };

//     constexpr void IndexRange::resize(const Size_t size)
//     {
//         assert(size >= 0);
//         size_ = size;
//     };

//     constexpr bool IndexRange::operator==(const IndexRange& toCompare) const
//     {
//         return (size_ == toCompare.size_) && (index_ == toCompare.index_);
//     }

//     constexpr bool IndexRange::operator!=(const IndexRange& toCompare) const { return !(*this == toCompare); }

//     constexpr IndexRange IndexRange::operator+(const Index_t& translate) const
//     {
//         return IndexRange(LowerBound(index_ + translate), Size(size_));
//     }

//     constexpr IndexRange IndexRange::operator-(const Index_t& translate) const
//     {
//         return IndexRange(LowerBound(index_ - translate), Size(size_));
//     }

//     constexpr IndexRange IndexRange::translate_to_zero() const { return IndexRange(size_); }

//     constexpr bool IndexRange::is_empty() const { return size_ == 0; };

//     constexpr Index_t IndexRange::begin() const { return index_; };
//     constexpr Index_t IndexRange::end() const { return begin() + size_; };

//     constexpr Index_t IndexRange::lowerBound() const { return begin(); }
//     constexpr Index_t IndexRange::upperBound() const { return end() - 1; }

//     constexpr Index_t IndexRange::mid() const { return (upperBound() + lowerBound()) / 2; }

//     constexpr IndexRange IndexRange::left_relative_complement(const IndexRange& A) const
//     {
//         const Index_t lb = lowerBound();
//         const Index_t ub = std::min(upperBound(), A.lowerBound() - 1);

//         return IndexRange(LowerBound(lb), Size(std::max((Index_t)0, ub - lb + 1)));
//     }

//     constexpr IndexRange IndexRange::right_relative_complement(const IndexRange& A) const
//     {
//         const Index_t lb = std::max(lowerBound(), A.upperBound() + 1);
//         const Index_t ub = upperBound();

//         return IndexRange(LowerBound(lb), Size(std::max((Index_t)0, ub - lb + 1)));
//     }

//     constexpr bool IndexRange::intercepts(const IndexRange& range) const
//     {
//         return !((begin() >= range.end()) || (range.begin() >= end()));
//     };

//     constexpr bool IndexRange::contains(const Index_t& index) const { return (begin() <= index) && (index < end()); };

//     constexpr bool IndexRange::contains(const IndexRange& range) const
//     {
//         return ((range.size() == 0) && (range.lowerBound() >= 0) && (range.lowerBound() <= size())) ||
//                (contains(range.lowerBound()) && contains(range.upperBound()));
//     };

//     constexpr IndexRange IndexRange::intersection(const IndexRange& other) const
//     {
//         const Index_t _begin = std::max(begin(), other.begin());
//         const Index_t _end = std::min(end(), other.end());
//         const Size_t _size = std::max((Index_t)0, _end - _begin);

//         return IndexRange(LowerBound(_begin), Size(_size));
//     }

//     constexpr IndexRange IndexRange::merge(const IndexRange& other) const
//     {
//         const Index_t _begin = std::min(begin(), other.begin());
//         const Index_t _end = std::max(end(), other.end());
//         const Size_t _size = _end - _begin;

//         return IndexRange(LowerBound(_begin), Size(_size));
//     }

//     template <class Archive>
//     void IndexRange::serialize(Archive& ar, const unsigned int /*version*/)
//     {
//         ar& BOOST_SERIALIZATION_NVP(size_);
//         ar& BOOST_SERIALIZATION_NVP(index_);
//     }

//     ////////////////////////////////////////////////////

//     template <typename SCALAR>
//     constexpr typename std::enable_if<std::numeric_limits<SCALAR>::is_integer, IndexRange>::type
//         operator*(const SCALAR& scalar, const IndexRange& range)
//     {
//         const Index_t lb = scalar * ((scalar > 0) ? range.lowerBound() : range.upperBound());
//         const Index_t ub = scalar * ((scalar > 0) ? range.upperBound() : range.lowerBound());

//         return IndexRange(LowerBound(lb), UpperBound(ub));
//     };

//     std::ostream& operator<<(std::ostream& out, const IndexRange& range)
//     {
//         return (out << "[" << range.begin() << "," << range.end() << "[");
//     };

// } /* Kiss */
