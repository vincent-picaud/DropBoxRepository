#pragma once

#include <cstdint>

namespace Kiss
{
  typedef int32_t Integer_Common_t;  //!< Common type used
  typedef Integer_Common_t Index_t;  //!< Represent an index
  typedef Integer_Common_t Size_t;   //!< Represent a size (must be >=0, but unsigned type: easier arithmetic)
}
