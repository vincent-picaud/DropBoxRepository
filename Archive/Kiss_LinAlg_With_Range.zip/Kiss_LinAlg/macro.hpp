#pragma once

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// +=, -=, ... operators
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// CAVEAT: important to define this for CRTP base class -> impl() jump
// to the final leafs of the inheritance tree. Hence we are __sure__
// to do not miss any available specialization

#define MACRO_DECLARE_CWISE_INPLACE_OP(OBJECT, INPLACE_OP)                                 \
    /** @brief Operator overloading */                                                     \
    template <typename DERIVED>                                                            \
    constexpr auto& operator INPLACE_OP(const OBJECT<DERIVED>& object,                     \
                                        const typename DERIVED::ElementType& arg) noexcept \
    {                                                                                      \
        return object.impl() INPLACE_OP arg;                                               \
    }

#define MACRO_DEFINE_CWISE_INPLACE_OP(OBJECT, INPLACE_OP)                                  \
    /** @brief Operator overloading */                                                     \
    template <typename DERIVED>                                                            \
    constexpr auto& operator INPLACE_OP(const OBJECT<DERIVED>& object,                     \
                                        const typename DERIVED::ElementType& arg) noexcept \
    {                                                                                      \
        map(                                                                               \
            [&](auto& self_i)                                                              \
            {                                                                              \
                self_i INPLACE_OP arg;                                                     \
            },                                                                             \
            object);                                                                       \
                                                                                           \
        return object;                                                                     \
    }

#define MACRO_ALL_INPLACE_OP(WHAT, OBJECT) \
    WHAT(OBJECT, += );                     \
    WHAT(OBJECT, *= );                     \
    WHAT(OBJECT, /= );                     \
    WHAT(OBJECT, -= );

#define MACRO_DECLARE_CWISE_INPLACE_OP_ALL(OBJECT) MACRO_ALL_INPLACE_OP(MACRO_DECLARE_CWISE_INPLACE_OP, OBJECT);
#define MACRO_DEFINE_CWISE_INPLACE_OP_ALL(OBJECT) MACRO_ALL_INPLACE_OP(MACRO_DEFINE_CWISE_INPLACE_OP, OBJECT);
