
Put your figures here (one_figure.png file for instance)

They can be included in the doxygen doc with:

/**
 * @image html figures/one_figure.png
 */

