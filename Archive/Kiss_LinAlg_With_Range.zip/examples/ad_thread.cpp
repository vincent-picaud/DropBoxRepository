// Test and prepare thread safe ad

#define Kiss_AD_BOOST_SPECIALFUNCTIONS_ON

#include <Kiss_LinAlg/indexType.hpp>
//#include <Kiss_LinAlg/crtp.hpp>

#include <iostream>
#include <thread>
#include <vector>
#include <stack>
#include <cstring>  // for memcpy
#include <cassert>
#include <cstdio>  // for printf
#include <cmath>

#ifdef Kiss_AD_BOOST_SPECIALFUNCTIONS_ON
#include <boost/math/special_functions/gamma.hpp>
#include <boost/math/special_functions/digamma.hpp>
#endif

using namespace Kiss;

/////////////////////
// A VECTOR OF POD //
/////////////////////

/** @ingroup AD_ExtraDoc_Group
    A vector of PODs (Plain Old Data)

    @note The initial implementation used std::vector but this leads to a non negligible
    performance bottle neck (more than 30% !). The same observation is found in https://github.com/rjhogan/Adept.
    This is the reason why this small vector container mimicking std::vector is introduced.
*/
template <typename POD_TYPE>
class AD_POD_Vector
{
    static_assert(std::is_pod<POD_TYPE>::value, "");

   public:
    explicit AD_POD_Vector(const Size_t size) : p_(new POD_TYPE[size]), size_(size), capacity_(size) {}
    ~AD_POD_Vector() { delete[] p_; };

    Size_t size() const noexcept { return size_; };

    Size_t memory_size(bool include_this = true) const noexcept
    {
        // CAVEAT: actual size is maybe bigger as we use size() and not capacity()
        return size() * sizeof(POD_TYPE) + (include_this ? sizeof(*this) : 0);
    };

    void reserve(Size_t new_capacity)
    {
        if(new_capacity > capacity_)
        {
            new_capacity = std::max(new_capacity, 2 * capacity_);
            POD_TYPE* new_p = new POD_TYPE[new_capacity];
            std::memcpy(new_p, p_, sizeof(POD_TYPE) * size_);
            delete[] p_;
            p_ = new_p;
            capacity_ = new_capacity;
        }
    }

    void resize(const Size_t new_size)
    {
        assert(new_size >= 0);
        if(new_size > capacity_)
        {
            reserve(new_size);
        }
        size_ = new_size;
    }

    void increase_size(const Size_t size_increment) { resize(size_ + size_increment); }

    POD_TYPE* data() noexcept { return p_; };
    const POD_TYPE* data() const noexcept { return p_; };

    const POD_TYPE& operator[](const Index_t idx) const noexcept
    {
        assert(check_index(idx));
        return p_[idx];
    }
    POD_TYPE& operator[](const Index_t idx) noexcept
    {
        assert(check_index(idx));
        return p_[idx];
    }

    void fill(const POD_TYPE& pod) noexcept { std::fill(data(), data() + size(), pod); }

    const POD_TYPE& back() const noexcept { return this->operator[](size_ - 1); }
    POD_TYPE& back() noexcept { return this->operator[](size_ - 1); }

    void push_back(const POD_TYPE& toCopy)
    {
        resize(size_ + 1);
        back() = toCopy;
    }
    bool check_index(const Index_t idx) const noexcept { return (idx >= 0) && (idx < size_); };

   protected:
    POD_TYPE* p_;
    Size_t size_, capacity_;

    /** Screen output */
    friend std::ostream& operator<<(std::ostream& out, const AD_POD_Vector<POD_TYPE>& toPrint)
    {
        for(Index_t i = 0; i < toPrint.size(); i++)
        {
            out << "\n" << i << ":" << toPrint[i];
        }
        return out;
    }
};

/////////////////////////
// FORWARD DECLARATION //
/////////////////////////

template <typename SCALAR>
class AD_Tape;

template <typename SCALAR>
class AD_Scalar;

template <typename EXPRESSION>
class AD_Expression;

// Required for friend declarations
// Reason: we wanted to protect gradient_contribution() method
//
enum class AD_UnaryOpEnum;
template <AD_UnaryOpEnum OP, typename ARG>
class AD_UnaryOp;

enum class AD_BinaryOpEnum;
template <AD_BinaryOpEnum OP, typename ARG_0, typename ARG_1>
class AD_BinaryOp;

enum class AD_LeftBindedBinaryOpEnum;
template <AD_LeftBindedBinaryOpEnum, typename ARG_0, typename ARG_1>
class AD_LeftBindedBinaryOp;

enum class AD_RightBindedBinaryOpEnum;
template <AD_RightBindedBinaryOpEnum, typename ARG_0, typename ARG_1>
class AD_RightBindedBinaryOp;

#define SALAD_MACRO_FRIEND_DECL()                                                     \
    template <typename LOCAL_SCALAR>                                                  \
    friend class AD_Scalar;                                                           \
    template <typename LOCAL_SCALAR>                                                  \
    friend class AD_Expression;                                                       \
    template <typename LOCAL_SCALAR>                                                  \
    friend class AD_Tape;                                                             \
    template <AD_UnaryOpEnum LOCAL_OP, typename LOCAL_ARG>                            \
    friend class AD_UnaryOp;                                                          \
    template <AD_BinaryOpEnum LOCAL_OP, typename LOCAL_ARG_0, typename LOCAL_ARG_1>   \
    friend class AD_BinaryOp;                                                         \
    template <AD_LeftBindedBinaryOpEnum, typename LOCAL_ARG_0, typename LOCAL_ARG_1>  \
    friend class AD_LeftBindedBinaryOp;                                               \
    template <AD_RightBindedBinaryOpEnum, typename LOCAL_ARG_0, typename LOCAL_ARG_1> \
    friend class AD_RightBindedBinaryOp;

///////////////////////////
// AD_Variations<SCALAR> //
///////////////////////////

/** @ingroup AD_UserInterface_Group
    A wrapper to store results of gradient/directional derivative computations

    This object is returned by functions like:
    - @ref AD_grad()
    - @ref AD_partialDerivative()
    - @ref AD_directionalDerivative()
*/
template <typename SCALAR>
class AD_Variations
{
    using SelfType = AD_Variations;

   public:
    explicit AD_Variations(const Size_t size) : ad_variations_(size) {}

    AD_Variations(const SelfType&) = default;
    AD_Variations(SelfType&&) noexcept = default;
    SelfType& operator=(const SelfType&) = default;
    SelfType& operator=(SelfType&&) noexcept = default;

    decltype(auto) size() const noexcept { return ad_variations_.size(); };

    decltype(auto) operator[](const Index_t idx) const noexcept { return ad_variations_[idx]; }
    decltype(auto) operator[](const Index_t idx) noexcept { return ad_variations_[idx]; }
    decltype(auto) operator[](const AD_Scalar<SCALAR>& variable) const noexcept
    {
        return SelfType::operator[](variable.index());
    }
    decltype(auto) operator[](const AD_Scalar<SCALAR>& variable) noexcept
    {
        return SelfType::operator[](variable.index());
    };
    decltype(auto) fill(const SCALAR& scalar) noexcept { return ad_variations_.fill(scalar); };

   protected:
    AD_POD_Vector<SCALAR> ad_variations_;

    /** Screen output */
    friend std::ostream& operator<<(std::ostream& out, const SelfType& toPrint)
    {
        for(Index_t i = 0; i < toPrint.ad_variations_.size(); i++)
        {
            out << "\n" << i << ":" << toPrint.ad_variations_[i];
        }
        return out;
    }
};

//////////
// TAPE //
//////////

constexpr Index_t AD_Invalid_Variable_Index = -1;

// CAVEAT: keep synchronized with
// template <>
// thread_local typename AD_Tape<float>::All_Tapes_Type AD_Tape<float>::all_tapes_{}
// ...
//
template <typename SCALAR>
constexpr bool
    AD_Check_Supported_Scalar = (std::is_same<SCALAR, float>::value) || (std::is_same<SCALAR, double>::value);

template <typename SCALAR>
struct AD_GradientComponent
{
    SCALAR value;   // \partial_i \phi
    Index_t index;  // i
};

template <typename SCALAR>
class AD_Tape
{
    static_assert(AD_Check_Supported_Scalar<SCALAR>, "");

    SALAD_MACRO_FRIEND_DECL();

   protected:
    using SelfType = AD_Tape;

   public:
    AD_Tape() : row_index_(Initial_Capacity::value), gradientComponent_(Initial_Capacity::value)
    {
        row_index_.resize(1);
        row_index_[0] = 0;
        gradientComponent_.resize(0);
        all_tapes_.push(this);
        //        std::cerr << "\n" << __PRETTY_FUNCTION__ << std::endl;
        assert(check_invariant());
    }

    ~AD_Tape()
    {
        //        std::cerr << "\n" << __PRETTY_FUNCTION__ << std::endl;
        assert(!all_tapes_.empty());
        all_tapes_.pop();
    };

    AD_Tape(const SelfType&) = delete;
    AD_Tape(SelfType&&) = delete;

    //~~~~~~~~~~~~~~~~

    // Number of variables
    Size_t size() const noexcept
    {
        assert(row_index_.size() > 0);
        return row_index_.size() - 1;
    };
    Size_t memory_size(bool include_this = true) const noexcept
    {
        return row_index_.memory_size(false) + gradientComponent_.memory_size(false) +
               (include_this ? sizeof(*this) : 0);
    }

    // Reverse mode
    AD_Variations<SCALAR> compute_gradient(const AD_Scalar<SCALAR>& func) const
    {
        assert(func.is_registred());

        AD_Variations<SCALAR> buffer(size());
        assert(buffer.size() == size());
        buffer.fill(SCALAR(0));
        buffer[func] = SCALAR(1);

        // Use reverse mode (adjoint)
        for(Index_t current_idx = func.index(); current_idx >= 0; --current_idx)
        {
            // For inplace computation of buffer <- U.buffer where
            // 1/ U upper triangular
            // 2/ REVERSE order
            // we need to save diagonal term  when grad_index == current_idx
            // However it is, a priori, faster to avoid this test and systematically
            // use a component_buffer
            //
            // (if current_idx run from 0 to size, direct order, no
            // such saving would be necessary)
            //
            const auto component_buffer = buffer[current_idx];
            buffer[current_idx] = 0;

            if(component_buffer != 0)  // Hogan trick
            {
                for(Index_t gradientComponent_idx = row_index_[current_idx],
                            gradientComponent_end = row_index_[current_idx + 1];
                    gradientComponent_idx < gradientComponent_end; gradientComponent_idx++)
                {
                    buffer[gradientComponent_[gradientComponent_idx].index] +=
                        gradientComponent_[gradientComponent_idx].value * component_buffer;
                }
            }
        }

        return buffer;
    }

    static SelfType* current_tape()
    {
        assert(!all_tapes_.empty());
        return all_tapes_.top();
    };

   protected:
    Index_t create_new_entry(const Size_t gradientComponent_size)
    {
        const Index_t column_offset = row_index_.back();
        row_index_.push_back(column_offset + gradientComponent_size);
        gradientComponent_.increase_size(gradientComponent_size);
        return column_offset;
    }

    void create_variable(AD_Scalar<SCALAR>& ad_scalar, const SCALAR& value)
    {
        ad_scalar.set_value(value);
        ad_scalar.set_index(size());

        const Index_t column_offset = create_new_entry(1);
        gradientComponent_[column_offset].value = 1;
        gradientComponent_[column_offset].index = ad_scalar.index();
        assert(check_invariant());
    }

    template <typename EXPRESSION>
    void create_variable(AD_Scalar<SCALAR>& ad_scalar, const AD_Expression<EXPRESSION>& ad_expression)
    {
        const Index_t column_offset = create_new_entry(AD_Expression<EXPRESSION>::Variable_Size::value);
        auto p_gradientComponent = &gradientComponent_[column_offset];
        ad_expression.gradient_contribution(p_gradientComponent, 1);

        // CAVEAT: overwrite ad_scalar with new value at the end ->
        // avoid ALIASING problem
        ad_scalar.set_value(ad_expression.value());
        ad_scalar.set_index(size() - 1);

        assert(check_invariant());
    }

    bool check_invariant() noexcept
    {
        return (row_index_.size() > 0) && (row_index_[0] == 0) &&
               (row_index_[row_index_.size() - 1] == gradientComponent_.size());
    }

    //~~~~~~~~~~~~~~~~

    using Initial_Capacity = std::integral_constant<Size_t, 1024>;

    AD_POD_Vector<Index_t> row_index_;
    AD_POD_Vector<AD_GradientComponent<SCALAR>> gradientComponent_;

    typedef std::stack<AD_Tape<SCALAR>*> All_Tapes_Type;
    thread_local static All_Tapes_Type all_tapes_;

    //~~~~~~~~~~~~~~~~

    friend std::ostream& operator<<(std::ostream& out, const SelfType& toPrint)
    {
        // Usage example: dot -Tps graph1.dot -o graph1.ps

        auto node_name = [](const Index_t i)
        {
            return "v_" + std::to_string(i);
        };

        constexpr Size_t buffer_size = 10;
        static char buffer[buffer_size];

        out << "\ndigraph ad_tape {";
        const Size_t size = toPrint.size();
        for(Index_t i = 0; i < size; i++)
        {
            out << "\n" << node_name(i);
            for(Index_t j = toPrint.row_index_[i]; j < toPrint.row_index_[i + 1]; j++)
            {
                std::snprintf(buffer, buffer_size, "%0.2f", toPrint.gradientComponent_[j].value);

                out << "\n" << node_name(toPrint.gradientComponent_[j].index) << "->" << node_name(i)
                    << " [label=" << buffer << "]";
            }
        }
        out << "\n}";
        return out;
    }
};

// CAVEAT: relates to AD_Check_Supported_Scalar<SCALAR>
template <>
thread_local typename AD_Tape<float>::All_Tapes_Type AD_Tape<float>::all_tapes_{};
template <>
thread_local typename AD_Tape<double>::All_Tapes_Type AD_Tape<double>::all_tapes_{};

// Some syntax sugars
//
template <typename SCALAR>
decltype(auto) ad_current_tape()
{
    return AD_Tape<SCALAR>::current_tape();
};
template <typename SCALAR>
decltype(auto) ad_compute_gradient(const AD_Scalar<SCALAR>& func)
{
    return ad_current_tape<SCALAR>()->compute_gradient(func);
}

////////////////////////////////
// EXPRESSION TEMPLATE ENGINE //
////////////////////////////////

template <typename EXPRESSION>
struct AD_Traits;

struct AD_Expression_Tag
{
};

template <typename EXPRESSION>
struct Is_AD_Expression : std::integral_constant<bool, std::is_base_of<AD_Expression_Tag, EXPRESSION>::value>
{
};

/** @ingroup AD_ExtraDoc_Group
    @brief Base static interface
    @anchor AD_Expression_Anchor
 */
template <typename EXPRESSION>
class AD_Expression : AD_Expression_Tag
{
    SALAD_MACRO_FRIEND_DECL();

   protected:
    using SelfType = AD_Expression<EXPRESSION>;
    using TraitsType = AD_Traits<EXPRESSION>;

   public:
    using Variable_Size = typename TraitsType::Variable_Size;
    using Scalar_Type = typename TraitsType::Scalar_Type;

   public:
    const EXPRESSION& cast() const noexcept { return static_cast<const EXPRESSION&>(*this); }

    const Scalar_Type& value() const noexcept { return cast().value(); }
    static AD_Tape<Scalar_Type>* current_tape() noexcept { return AD_Tape<Scalar_Type>::current_tape(); }

   protected:
    void gradient_contribution(AD_GradientComponent<Scalar_Type>*& p_gradientComponent,
                               const Scalar_Type& multiplier) const noexcept
    {
        cast().gradient_contribution(p_gradientComponent, multiplier);
    }
};

///////////////
// AD_SCALAR //
///////////////

template <typename SCALAR>
struct AD_Traits<AD_Scalar<SCALAR>>
{
    static_assert(AD_Check_Supported_Scalar<SCALAR>, "");

    using Variable_Size = std::integral_constant<Size_t, 1>;
    using Scalar_Type = SCALAR;
};

template <typename SCALAR>
class AD_Scalar : public AD_Expression<AD_Scalar<SCALAR>>
{
    SALAD_MACRO_FRIEND_DECL();

   public:
    using SelfType = AD_Scalar;
    using Variable_Size = typename SelfType::Variable_Size;
    using Scalar_Type = typename SelfType::Scalar_Type;

   public:
    /** Default constructor

        Do not register, id index=invalid the variable in the tape
        yet.
    */
    AD_Scalar() = default;

    /** Creates a new variable and register it */
    explicit AD_Scalar(const SCALAR& value) { SelfType::current_tape()->create_variable(*this, value); }

    AD_Scalar(const AD_Scalar<SCALAR>&) = default;
    AD_Scalar(AD_Scalar<SCALAR>&&) = default;

    template <typename EXPR>
    AD_Scalar(const AD_Expression<EXPR>& expr)
    {
        SelfType::current_tape()->create_variable(this, expr);
    }

    /** Change variable value */
    SelfType& operator=(const SCALAR& value)
    {
        SelfType::current_tape()->create_variable(*this, value);

        return *this;
    }

    template <typename EXPR>
    SelfType& operator=(const AD_Expression<EXPR>& expr)
    {
        SelfType::current_tape()->create_variable(*this, expr);
        return *this;
    }

// SelfType& operator=(const SelfType& expr) = default;

#define INPLACE_OP(OP)                                        \
    /** Compound assignment of an @ref AD_Expression<> */     \
    template <typename EXPR>                                  \
    SelfType& operator OP##=(const AD_Expression<EXPR>& expr) \
    {                                                         \
        *this = *this OP expr;                                \
        return *this;                                         \
    }                                                         \
                                                              \
    /** Compound assignment of a Scalar */                    \
    SelfType& operator OP##=(const SCALAR& scalar)            \
    {                                                         \
        *this = *this OP scalar;                              \
        return *this;                                         \
    }

    INPLACE_OP(+);
    INPLACE_OP(-);
    INPLACE_OP(*);
    INPLACE_OP(/ );
#undef INPLACE_OP

    const SCALAR& value() const noexcept { return value_; };
    Index_t index() const noexcept { return variable_index_; }
    bool is_registred() const noexcept { return index() != AD_Invalid_Variable_Index; };

   protected:
    void gradient_contribution(AD_GradientComponent<SCALAR>*& p_gradientComponent, const SCALAR& multiplier) const
        noexcept
    {
        // CAVEAT: do not skip null multiplier
        //
        // REASONS:
        // 1/ AD_Tape assumes contiguous data and Variable_Size size is computed at compile time
        // 2/ this insures a constant sparsity pattern
        //
        assert(index() != AD_Invalid_Variable_Index);
        p_gradientComponent->value = multiplier;
        p_gradientComponent->index = index();
        ++p_gradientComponent;
    }

    void set_value(const SCALAR& value) noexcept { value_ = value; }
    void set_index(Index_t variable_index) noexcept { variable_index_ = variable_index; }

   protected:
    SCALAR value_;
    Index_t variable_index_{AD_Invalid_Variable_Index};
};

//////////////////////////
// COMPARISON OPERATORS //
//////////////////////////

#define IMP_COMPARISON(OP)                                                                    \
    template <typename ARG_0, typename ARG_1>                                                 \
    bool operator OP(const AD_Expression<ARG_0>& arg_0, const AD_Expression<ARG_1>& arg_1)    \
    {                                                                                         \
        return arg_0.value() OP arg_1.value();                                                \
    }                                                                                         \
                                                                                              \
    template <typename ARG>                                                                   \
    bool operator OP(const typename ARG::Scalar_Type& arg_0, const AD_Expression<ARG>& arg_1) \
    {                                                                                         \
        return arg_0 OP arg_1.value();                                                        \
    }                                                                                         \
                                                                                              \
    template <typename ARG>                                                                   \
    bool operator OP(const AD_Expression<ARG>& arg_0, const typename ARG::Scalar_Type& arg_1) \
    {                                                                                         \
        return arg_0.value() OP arg_1;                                                        \
    }

IMP_COMPARISON(== );
IMP_COMPARISON(!= );
IMP_COMPARISON(<= );
IMP_COMPARISON(>= );
IMP_COMPARISON(< );
IMP_COMPARISON(> );

#undef IMP_COMPARISON

///////////////////
// UNARY OP EXPR //
///////////////////

template <AD_UnaryOpEnum OP, typename ARG>
struct AD_Traits<AD_UnaryOp<OP, ARG>>
{
    typedef std::integral_constant<Size_t, ARG::Variable_Size::value> Variable_Size;
    typedef typename ARG::Scalar_Type Scalar_Type;
};

#define IMP_UNARY_OP(OP, OP_ENUM, VALUE, MULTIPLIER_DIFF)                                     \
    template <typename ARG>                                                                   \
    class AD_UnaryOp<OP_ENUM, ARG> : public AD_Expression<AD_UnaryOp<OP_ENUM, ARG>>           \
    {                                                                                         \
        SALAD_MACRO_FRIEND_DECL();                                                            \
                                                                                              \
       public:                                                                                \
        typedef AD_UnaryOp<OP_ENUM, ARG> SelfType;                                            \
        typedef AD_Expression<AD_UnaryOp<OP_ENUM, ARG>> BaseType;                             \
                                                                                              \
        typedef std::integral_constant<Size_t, BaseType::Variable_Size::value> Variable_Size; \
        typedef typename BaseType::Scalar_Type Scalar_Type;                                   \
                                                                                              \
       public:                                                                                \
        AD_UnaryOp(const ARG& _arg) : arg_(_arg), value_(VALUE){};                            \
                                                                                              \
        const ARG& arg() const noexcept { return arg_; };                                     \
                                                                                              \
        const Scalar_Type& value() const noexcept { return value_; }                          \
                                                                                              \
       protected:                                                                             \
        void gradient_contribution(AD_GradientComponent<Scalar_Type>*& p_gradientComponent,   \
                                   Scalar_Type multiplier) const noexcept                     \
        {                                                                                     \
            arg().gradient_contribution(p_gradientComponent, MULTIPLIER_DIFF);                \
        }                                                                                     \
                                                                                              \
       protected:                                                                             \
        const ARG& arg_;                                                                      \
                                                                                              \
        const Scalar_Type value_;                                                             \
    };                                                                                        \
                                                                                              \
    template <typename ARG>                                                                   \
    auto OP(const AD_Expression<ARG>& arg)                                                    \
    {                                                                                         \
        return AD_UnaryOp<OP_ENUM, ARG>(arg.cast());                                          \
    }

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

enum class AD_UnaryOpEnum
{
    Minus_Expr,
    Plus_Expr,

    Sin_Expr,
    Cos_Expr,
    Tan_Expr,

    ASin_Expr,
    ACos_Expr,
    ATan_Expr,

    Exp_Expr,
    Log_Expr,

    Sinh_Expr,
    Cosh_Expr,
    Tanh_Expr,

    ASinh_Expr,
    ACosh_Expr,
    ATanh_Expr,

    Sqrt_Expr,

    Erf_Expr,

    Abs_Expr

#ifdef Kiss_AD_BOOST_SPECIALFUNCTIONS_ON
    ,
    TGamma_Expr,  // TGamma = true gamma (by opposition to logGamma)
    LGamma_Expr   // LogGamma
#endif
};

//~~~~~~~~~~~~~~~~-------------------------

#ifdef Kiss_AD_BOOST_SPECIALFUNCTIONS_ON
// using boost::math::lgamma;
// using boost::math::tgamma;
// template <typename TYPE>
// auto lgamma(const TYPE& x, const std::enable_if_t<AD_Supported_Type_v<TYPE>>* p = nullptr)
// {
//     return boost::math::lgamma(x);
// };

// template <typename TYPE>
// auto tgamma(const TYPE& x, const std::enable_if_t<AD_Supported_Type_v<TYPE>>* p = nullptr)
// {
//     return boost::math::tgamma(x);
// };
#endif

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(operator-, AD_UnaryOpEnum::Minus_Expr, -arg().value(), -multiplier);
IMP_UNARY_OP(operator+, AD_UnaryOpEnum::Plus_Expr, arg().value(), multiplier);

IMP_UNARY_OP(sin, AD_UnaryOpEnum::Sin_Expr, sin(arg().value()), multiplier* cos(arg().value()));

IMP_UNARY_OP(cos, AD_UnaryOpEnum::Cos_Expr, cos(arg().value()), -multiplier* sin(arg().value()));

IMP_UNARY_OP(tan, AD_UnaryOpEnum::Tan_Expr, tan(arg().value()), multiplier / (pow(cos(arg().value()), 2)));

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(asin, AD_UnaryOpEnum::ASin_Expr, asin(arg().value()), multiplier / sqrt(1 - pow(arg().value(), 2)));

IMP_UNARY_OP(acos, AD_UnaryOpEnum::ACos_Expr, acos(arg().value()), -multiplier / sqrt(1 - pow(arg().value(), 2)));

IMP_UNARY_OP(atan, AD_UnaryOpEnum::ATan_Expr, atan(arg().value()), multiplier / (1 + pow(arg().value(), 2)));

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(exp, AD_UnaryOpEnum::Exp_Expr, exp(arg().value()), multiplier* value());

IMP_UNARY_OP(log, AD_UnaryOpEnum::Log_Expr, log(arg().value()), multiplier / arg().value());

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(sinh, AD_UnaryOpEnum::Sinh_Expr, sinh(arg().value()), multiplier* cosh(arg().value()));

IMP_UNARY_OP(cosh, AD_UnaryOpEnum::Cosh_Expr, cosh(arg().value()), multiplier* sinh(arg().value()));

IMP_UNARY_OP(tanh, AD_UnaryOpEnum::Tanh_Expr, tanh(arg().value()), multiplier / pow(cosh(arg().value()), 2));

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(asinh, AD_UnaryOpEnum::ASinh_Expr, asinh(arg().value()), multiplier / sqrt(pow(arg().value(), 2) + 1));

IMP_UNARY_OP(acosh, AD_UnaryOpEnum::ACosh_Expr, acosh(arg().value()), multiplier / sqrt(pow(arg().value(), 2) - 1));

IMP_UNARY_OP(atanh, AD_UnaryOpEnum::ATanh_Expr, atanh(arg().value()), multiplier / (1 - pow(arg().value(), 2)));

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(sqrt, AD_UnaryOpEnum::Sqrt_Expr, sqrt(arg().value()), multiplier / (2 * value()));

//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(erf, AD_UnaryOpEnum::Erf_Expr, erf(arg().value()),
             multiplier * 2 * exp(-pow(arg().value(), 2)) / sqrt(M_PI));
//~~~~~~~~~~~~~~~~

IMP_UNARY_OP(abs, AD_UnaryOpEnum::Abs_Expr, abs(arg().value()), multiplier*((value() >= 0) ? multiplier : -multiplier));

//================ Boost Special Functions

#ifdef Kiss_AD_BOOST_SPECIALFUNCTIONS_ON
IMP_UNARY_OP(tgamma, AD_UnaryOpEnum::TGamma_Expr, boost::math::tgamma(arg().value()),
             (multiplier * value() * boost::math::digamma(arg().value())));
IMP_UNARY_OP(lgamma, AD_UnaryOpEnum::LGamma_Expr, boost::math::lgamma(arg().value()),
             (multiplier * boost::math::digamma(arg().value())));
#endif

//================ Boost Special Functions END

#undef IMP_UNARY_OP

/////////////////////////
// BINARY OP EXPR_EXPR //
/////////////////////////

/** @ingroup AD_ExtraDoc_Group
    AD_BinaryOp op traits
*/
template <AD_BinaryOpEnum OP, typename ARG_0, typename ARG_1>
struct AD_Traits<AD_BinaryOp<OP, ARG_0, ARG_1>>
{
    static_assert(std::is_same<typename ARG_0::Scalar_Type, typename ARG_1::Scalar_Type>::value,
                  "Does not support mixed type!");

    typedef std::integral_constant<Size_t, ARG_0::Variable_Size::value + ARG_1::Variable_Size::value> Variable_Size;
    typedef typename ARG_0::Scalar_Type Scalar_Type;  // Is identical to ARG_1::Scalar_Type
};

#define IMP_BINARY_OP(OP, OP_ENUM, VALUE, MULTIPLIER_DIFF_0, MULTIPLIER_DIFF_1)                                  \
    template <typename ARG_0, typename ARG_1>                                                                    \
    class AD_BinaryOp<OP_ENUM, ARG_0, ARG_1> : public AD_Expression<AD_BinaryOp<OP_ENUM, ARG_0, ARG_1>>          \
    {                                                                                                            \
        SALAD_MACRO_FRIEND_DECL();                                                                               \
                                                                                                                 \
       protected:                                                                                                \
        using SelfType = AD_BinaryOp;                                                                            \
                                                                                                                 \
       public:                                                                                                   \
        using Variable_Size = typename SelfType::Variable_Size;                                                  \
        using Scalar_Type = typename SelfType::Scalar_Type;                                                      \
                                                                                                                 \
       public:                                                                                                   \
        AD_BinaryOp(const ARG_0& _arg_0, const ARG_1& _arg_1) : arg_0_(_arg_0), arg_1_(_arg_1), value_(VALUE){}; \
                                                                                                                 \
        const ARG_0& arg_0() const noexcept { return arg_0_; };                                                  \
        const ARG_1& arg_1() const noexcept { return arg_1_; };                                                  \
                                                                                                                 \
        const Scalar_Type& value() const noexcept { return value_; }                                             \
                                                                                                                 \
        void gradient_contribution(AD_GradientComponent<Scalar_Type>*& p_gradientComponent,                      \
                                   Scalar_Type multiplier) const noexcept                                        \
        {                                                                                                        \
            arg_1().gradient_contribution(p_gradientComponent, MULTIPLIER_DIFF_1);                               \
            arg_0().gradient_contribution(p_gradientComponent, MULTIPLIER_DIFF_0);                               \
        }                                                                                                        \
                                                                                                                 \
       protected:                                                                                                \
        const ARG_0& arg_0_;                                                                                     \
        const ARG_1& arg_1_;                                                                                     \
                                                                                                                 \
        const Scalar_Type value_;                                                                                \
    };                                                                                                           \
                                                                                                                 \
    template <typename ARG_0, typename ARG_1>                                                                    \
    auto OP(const AD_Expression<ARG_0>& arg_0, const AD_Expression<ARG_1>& arg_1)                                \
    {                                                                                                            \
        return AD_BinaryOp<OP_ENUM, ARG_0, ARG_1>(arg_0.cast(), arg_1.cast());                                   \
    }

enum class AD_BinaryOpEnum
{
    Plus_Expr_Expr,
    Minus_Expr_Expr,
    Product_Expr_Expr,
    Divide_Expr_Expr,
    // Extra functions
    Min_Expr_Expr,
    Max_Expr_Expr
};

IMP_BINARY_OP(operator*, AD_BinaryOpEnum::Product_Expr_Expr, arg_0().value() * arg_1().value(),
              multiplier* arg_1().value(), multiplier* arg_0().value());

IMP_BINARY_OP(operator/, AD_BinaryOpEnum::Divide_Expr_Expr, arg_0().value() / arg_1().value(),
              multiplier / arg_1().value(), -arg_0().value() / (arg_1().value() * arg_1().value()) * multiplier);

IMP_BINARY_OP(operator+, AD_BinaryOpEnum::Plus_Expr_Expr, arg_0().value() + arg_1().value(), multiplier, multiplier);

IMP_BINARY_OP(operator-, AD_BinaryOpEnum::Minus_Expr_Expr, arg_0().value() - arg_1().value(), multiplier, -multiplier);

IMP_BINARY_OP(max, AD_BinaryOpEnum::Max_Expr_Expr,
              ((arg_0().value() > arg_1().value()) ? arg_0().value() : arg_1().value()),
              multiplier*((arg_0().value() > arg_1().value()) ? 1 : 0),
              multiplier*((arg_0().value() > arg_1().value()) ? 0 : 1));

IMP_BINARY_OP(min, AD_BinaryOpEnum::Min_Expr_Expr,
              ((arg_0().value() < arg_1().value()) ? arg_0().value() : arg_1().value()),
              multiplier*((arg_0().value() < arg_1().value()) ? 1 : 0),
              multiplier*((arg_0().value() < arg_1().value()) ? 0 : 1));

#undef IMP_BINARY_OP

///////////////////////////
// BINARY OP SCALAR_EXPR //
///////////////////////////

enum class AD_LeftBindedBinaryOpEnum
{
    Product_Scalar_Expr,
    Divide_Scalar_Expr,
    Plus_Scalar_Expr,
    Minus_Scalar_Expr
};

template <AD_LeftBindedBinaryOpEnum OP, typename ARG_0, typename ARG_1>
struct AD_Traits<AD_LeftBindedBinaryOp<OP, ARG_0, ARG_1>>
{
    static_assert(AD_Check_Supported_Scalar<ARG_0>, "Expected a Scalar (nesting not allowed)");
    static_assert(Is_AD_Expression<ARG_1>::value, "Expected an AD_Expression");

    typedef typename ARG_1::Scalar_Type Scalar_Type;
    typedef std::integral_constant<Size_t, ARG_1::Variable_Size::value> Variable_Size;

    static_assert(std::is_convertible<ARG_0, Scalar_Type>::value, "Incompatible scalar");
};

#define IMP_LEFTBINDED_BINARY_OP(OP, OP_ENUM, VALUE, MULTIPLIER_DIFF_1)                                 \
    template <typename ARG_0, typename ARG_1>                                                           \
    class AD_LeftBindedBinaryOp<OP_ENUM, ARG_0, ARG_1>                                                  \
        : public AD_Expression<AD_LeftBindedBinaryOp<OP_ENUM, ARG_0, ARG_1>>                            \
    {                                                                                                   \
        SALAD_MACRO_FRIEND_DECL();                                                                      \
                                                                                                        \
       public:                                                                                          \
        typedef AD_LeftBindedBinaryOp<OP_ENUM, ARG_0, ARG_1> SelfType;                                  \
        typedef AD_Expression<SelfType> BaseType;                                                       \
                                                                                                        \
        typedef std::integral_constant<Size_t, BaseType::Variable_Size::value> Variable_Size;           \
        typedef typename BaseType::Scalar_Type Scalar_Type;                                             \
                                                                                                        \
       public:                                                                                          \
        AD_LeftBindedBinaryOp(const ARG_0& _arg_0, const ARG_1& _arg_1)                                 \
            : arg_0_(_arg_0), arg_1_(_arg_1), value_(VALUE){};                                          \
                                                                                                        \
        const ARG_0& arg_0() const noexcept { return arg_0_; };                                         \
        const ARG_1& arg_1() const noexcept { return arg_1_; };                                         \
                                                                                                        \
        const Scalar_Type& value() const noexcept { return value_; }                                    \
                                                                                                        \
        void gradient_contribution(AD_GradientComponent<Scalar_Type>*& p_current,                       \
                                   const Scalar_Type& multiplier = 1) const noexcept                    \
        {                                                                                               \
            arg_1().gradient_contribution(p_current, MULTIPLIER_DIFF_1);                                \
        }                                                                                               \
                                                                                                        \
       protected:                                                                                       \
        const ARG_0& arg_0_;                                                                            \
        const ARG_1& arg_1_;                                                                            \
                                                                                                        \
        const Scalar_Type value_;                                                                       \
    };                                                                                                  \
                                                                                                        \
    template <typename ARG_1>                                                                           \
    auto operator OP(const typename ARG_1::Scalar_Type& arg_0, const AD_Expression<ARG_1>& arg_1)       \
    {                                                                                                   \
        return AD_LeftBindedBinaryOp<OP_ENUM, typename ARG_1::Scalar_Type, ARG_1>(arg_0, arg_1.cast()); \
    }

IMP_LEFTBINDED_BINARY_OP(*, AD_LeftBindedBinaryOpEnum::Product_Scalar_Expr, arg_0() * arg_1().value(),
                         multiplier* arg_0());
IMP_LEFTBINDED_BINARY_OP(/, AD_LeftBindedBinaryOpEnum::Divide_Scalar_Expr, arg_0() / arg_1().value(),
                         -multiplier* arg_0() / (pow(arg_1().value(), 2)));
IMP_LEFTBINDED_BINARY_OP(+, AD_LeftBindedBinaryOpEnum::Plus_Scalar_Expr, arg_0() + arg_1().value(), multiplier);
IMP_LEFTBINDED_BINARY_OP(-, AD_LeftBindedBinaryOpEnum::Minus_Scalar_Expr, arg_0() - arg_1().value(), -multiplier);

#undef IMP_LEFTBINDED_BINARY_OP

///////////////////////////
// BINARY OP EXPR_SCALAR //
///////////////////////////

template <AD_RightBindedBinaryOpEnum OP, typename ARG_0, typename ARG_1>
struct AD_Traits<AD_RightBindedBinaryOp<OP, ARG_0, ARG_1>>
{
    static_assert(Is_AD_Expression<ARG_0>::value, "Expected an AD_Expression");
    static_assert(AD_Check_Supported_Scalar<ARG_1>, "Expected a Scalar (nesting not allowed)");

    typedef std::integral_constant<Size_t, ARG_0::Variable_Size::value> Variable_Size;
    typedef typename ARG_0::Scalar_Type Scalar_Type;

    static_assert(std::is_convertible<ARG_1, Scalar_Type>::value, "Incompatible scalar");
};

#define IMP_RIGHTBINDED_BINARY_OP(OP, OP_ENUM, VALUE, MULTIPLIER_DIFF_0)                                 \
    template <typename ARG_0, typename ARG_1>                                                            \
    class AD_RightBindedBinaryOp<OP_ENUM, ARG_0, ARG_1>                                                  \
        : public AD_Expression<AD_RightBindedBinaryOp<OP_ENUM, ARG_0, ARG_1>>                            \
    {                                                                                                    \
        SALAD_MACRO_FRIEND_DECL();                                                                       \
                                                                                                         \
       public:                                                                                           \
        typedef AD_RightBindedBinaryOp<OP_ENUM, ARG_0, ARG_1> SelfType;                                  \
        typedef AD_Expression<SelfType> BaseType;                                                        \
                                                                                                         \
        typedef std::integral_constant<Size_t, BaseType::Variable_Size::value> Variable_Size;            \
        typedef typename BaseType::Scalar_Type Scalar_Type;                                              \
                                                                                                         \
       public:                                                                                           \
        AD_RightBindedBinaryOp(const ARG_0& _arg_0, const ARG_1& _arg_1)                                 \
            : arg_0_(_arg_0), arg_1_(_arg_1), value_(VALUE){};                                           \
                                                                                                         \
        const ARG_0& arg_0() const noexcept { return arg_0_; };                                          \
        const ARG_1& arg_1() const noexcept { return arg_1_; };                                          \
                                                                                                         \
        const Scalar_Type& value() const noexcept { return value_; }                                     \
                                                                                                         \
        void gradient_contribution(AD_GradientComponent<Scalar_Type>*& p_current,                        \
                                   const Scalar_Type& multiplier = 1) const noexcept                     \
        {                                                                                                \
            arg_0().gradient_contribution(p_current, MULTIPLIER_DIFF_0);                                 \
        }                                                                                                \
                                                                                                         \
       protected:                                                                                        \
        const ARG_0& arg_0_;                                                                             \
        const ARG_1& arg_1_;                                                                             \
                                                                                                         \
        const Scalar_Type value_;                                                                        \
    };                                                                                                   \
                                                                                                         \
    template <typename ARG_0>                                                                            \
    auto operator OP(const AD_Expression<ARG_0>& arg_0, const typename ARG_0::Scalar_Type& arg_1)        \
    {                                                                                                    \
        return AD_RightBindedBinaryOp<OP_ENUM, ARG_0, typename ARG_0::Scalar_Type>(arg_0.cast(), arg_1); \
    }

enum class AD_RightBindedBinaryOpEnum
{
    Product_Expr_Scalar,
    Divide_Expr_Scalar,
    Plus_Expr_Scalar,
    Minus_Expr_Scalar
};

IMP_RIGHTBINDED_BINARY_OP(*, AD_RightBindedBinaryOpEnum::Product_Expr_Scalar, arg_0().value() * arg_1(),
                          multiplier* arg_1());
IMP_RIGHTBINDED_BINARY_OP(/, AD_RightBindedBinaryOpEnum::Divide_Expr_Scalar, arg_0().value() / arg_1(),
                          multiplier / arg_1());
IMP_RIGHTBINDED_BINARY_OP(+, AD_RightBindedBinaryOpEnum::Plus_Expr_Scalar, arg_0().value() + arg_1(), multiplier);
IMP_RIGHTBINDED_BINARY_OP(-, AD_RightBindedBinaryOpEnum::Minus_Expr_Scalar, arg_0().value() - arg_1(), multiplier);

#undef IMP_RIGHTBINDED_BINARY_OP

void test()
{
    typedef double T;

    AD_Tape<T> tape;
    AD_Scalar<T> x(2);
    x = tgamma(x * x + sin(x));

    std::cout << "\n" << tape;
    std::cout << "\n" << ad_compute_gradient(x);
}

int main()
{
    test();
    return 0;
    typedef double T;

    AD_Tape<T> t1;
    std::cout << "\n mem " << t1.memory_size();

    {
        AD_Tape<T> t2;

        assert(AD_Tape<T>::current_tape() == &t2);
    }
    assert(AD_Tape<T>::current_tape() == &t1);

    AD_Scalar<T> x(3), y(2), z(5);
    AD_Scalar<T> x2(x);

    asm("#BEGIN");
    z = x * (y + x);
    z = x * (z + x);
    z = z * (y + x) * z * (y + x);
    z = z + 4;
    z = 4 + z;
    z += 4;
    z = z * exp(sin(z));
    //    z = tgamma(z);
    asm("#END");
    std::cout << "\n" << *AD_Tape<T>::current_tape();

    ad_compute_gradient(z);

    std::cout << "\n" << ad_compute_gradient(z);
    //   std::cout << "\n" << t1.compute_gradient(z);
    std::cout << "\n mem " << t1.memory_size();

    AD_POD_Vector<double> v1(0), v2(50);
    std::cout << "\n mem " << v1.memory_size();
    std::cout << "\n mem " << v2.memory_size();

    return 0;
}
