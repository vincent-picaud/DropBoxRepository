#include <Kiss_LinAlg/Vector/tinyVector.hpp>
//#include <Kiss_LinAlg/Range/cwise.hpp>
#include <Kiss_LinAlg/Range/range_map.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>


using namespace Kiss;

// g++ -std=c++14 -O3 -DNDEBUG -S -I/IS006139/home/pix/GitHub/Kiss_LinAlg/ ../../examples/bench.cpp -o bench.asm

int main()
{
    // constexpr Size_t N = 10;
    // TinyVector<float, N> v;
    // float v_comp[N];

    // asm("#BEGIN_FILL");
    // for(Index_t i = 0, i_size = v.size(); i < i_size; i++)
    // {
    //     v[i] = i;
    // }
    // asm("#END_FILL");

    // asm("#BEGIN_FILL_COMP");
    // for(Index_t i = 0, i_size = N; i < i_size; i++)
    // {
    //     v_comp[i] = i;
    // }
    // asm("#END_FILL_COMP");

    // // asm("#BEGIN_VAR_SUM");
    // // float var_sum = 0;
    // // map(
    // //     [&var_sum](const auto& v_i)
    // //     {
    // //       //        v_i += 4 * v_i;
    // //       var_sum += v_i;
    // //     },
    // //     range(v));
    // // asm("#END_VAR_SUM");

    // asm("#BEGIN_VAR_SUM_COMP");
    // float var_sum_comp = 0;
    // for(Index_t i = 0, i_size = N; i < i_size; i++)
    // {
    //     // v_comp[i] += 4 * v_comp[i];
    //     var_sum_comp += v_comp[i];
    // }
    // asm("#END_VAR_SUM_COMP");

    // // std::cerr << "\n" << var_sum << " " << (N - 1) * N / 2;
    // // std::cerr << "\n" << var_sum_comp << " " << (N - 1) * N / 2;

    // asm("#BEGIN_SUM");
    // const auto _sum_ = cwise_sum(v.range());
    // asm("#END_SUM");

    // std::cerr << "\nsum:" << _sum_;

    // asm("#BEGIN_MAX");
    // const auto _max_ = cwise_max(v.range());
    // asm("#END_MAX");

    // std::cerr << "\nmax:" << _max_;
}
