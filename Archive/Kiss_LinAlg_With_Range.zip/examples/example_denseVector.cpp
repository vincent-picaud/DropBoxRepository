#include <Kiss_LinAlg/Vector/denseVector.hpp>
#include <Kiss_LinAlg/Vector/denseVector_map.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>



using namespace Kiss;

template <typename DERIVED>
void toto(const Interface_Vector<DERIVED>& test)
{
    test = 2016;
}

int main()
{
    dynStat_assert(std::integral_constant<bool, true>());
    dynStat_assert(true);

    auto v(create_vector<int>(10));
    auto v2(create_vector<double>(10));

    v[5] = 5;
    v2 = 2.5;

    toto(v);

    v = v2;

    //  std::cout << v.range();

    front(v.range()) = 30;

    std::cout << v;
}
