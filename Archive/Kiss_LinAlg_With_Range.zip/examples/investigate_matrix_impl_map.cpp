#include <Kiss_LinAlg/Vector/tinyVector.hpp>

using namespace Kiss;

int main(int argc, char* argv[])
{

    // TinyMatrix<int, 3, 5, MatrixShape_UpperTriangular> MM;

    // Size_t mc = 0;
    // map(
    //     [&mc](auto& m)
    //     {
    //         m = ++mc;
    //     },
    //     MM);

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    TinyVector<int, 3> V;

    Size_t c = 0;
    map(
        [&c](auto& m)
        {
            m = ++c;
        },
        V);

    return 0;
}
