#include <Kiss_LinAlg/Matrix/tinyMatrix.hpp>
#include <Kiss_LinAlg/Matrix/denseMatrix.hpp>
#include <Kiss_LinAlg/Matrix/denseMatrix_map.hpp>
#include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock.hpp>
#include <Kiss_LinAlg/Range/range_oneElement.hpp>

using namespace Kiss;

// g++ -std=c++14 -O3 -DNDEBUG -S -I/IS006139/home/pix/GitHub/Kiss_LinAlg/
// /IS006139/home/pix/GitHub/Kiss_LinAlg/examples/matrix.cpp -o ~/Temp/matrix.asm

template <typename MATRIXSHAPE_TYPE>
void demo()
{
    constexpr Size_t I_SIZE = 4;
    constexpr Size_t J_SIZE = 8;

    TinyMatrix<int, I_SIZE, J_SIZE, MATRIXSHAPE_TYPE> M;

    M = -10;

    M.view(3, _) = 1;

    std::cout << "\n" << M;

    M.view(_, 3) = 2;

    std::cout << "\n" << M;

    M.transposed_view().view(3, _) = 3;

    std::cout << "\n" << M;

    M.transposed_view().view(_, 3) = 4;

    std::cout << "\n" << M;
}

int main()
{
   	auto M=create_matrix<double>(5,6);

    // UniqueMemoryBlock<const double> m(10);

    // UniqueMemoryBlock<const double> m2(std::move(m));

    // // std::cout << "\nFULL";
    // // demo<MatrixShape_Full>();

    // // std::cout << "\nSYMMETRIC";
    // // demo<MatrixShape_UpperUnitTriangular>();

    return 0;
}
