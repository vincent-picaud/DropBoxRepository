#include <Kiss_LinAlg/Vector/tinyVector.hpp>
#include <Kiss_LinAlg/Matrix/tinyMatrix.hpp>
#include <Kiss_LinAlg/Meta/logical.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock.hpp>
#include <Kiss_LinAlg/Matrix/denseMatrix.hpp>



#include <memory>
#include <vector>
#include <iomanip>

using namespace Kiss;

// g++ -std=c++14 -O3 -S -I/IS006139/home/pix/GitHub/Kiss_LinAlg/ ../../examples/bench.cpp -o bench.asm

template <typename T>
void printType()
{
    std::cerr << "\n" << __PRETTY_FUNCTION__;
}

template <typename DERIVED>
constexpr Size_t toto(const Interface_MemoryBlock<DERIVED>& memoryBlock) noexcept
{
    return capacity(memoryBlock);
}

struct Loop_I_J_Lower
{
    Loop_I_J_Lower(int* p, int I_size, int J_size, int I_stride, int J_stride)
        : p_(p), I_size_(I_size), J_size_(J_size), I_stride_(I_stride), J_stride_(J_stride)
    {
    }

    bool is_empty() { return I_count_ == I_size_; }

    void pop()
    {
        assert(I_count_ < I_size_);
        if((J_count_ < I_count_) && (J_count_ + 1 < J_size_))
        {
            p_ += J_stride_;
            ++J_count_;
        }
        else
        {
            p_ += I_stride_ - J_count_ * J_stride_;
            J_count_ = 0;
            ++I_count_;
        }
    }

    int& front() { return *p_; }

    int* p_;
    int I_size_, J_size_, I_stride_, J_stride_;
    int I_count_{0}, J_count_{0};
};

struct Loop_I_J_LowerStrict
{
    Loop_I_J_LowerStrict(int* p, int I_size, int J_size, int I_stride, int J_stride)
        : p_(p + I_stride), I_size_(I_size), J_size_(J_size), I_stride_(I_stride), J_stride_(J_stride)
    {
    }

    bool is_empty() { return (I_count_ == I_size_) || (J_count_ == J_size_); }

    void pop()
    {
        assert(I_count_ < I_size_);

        if((J_count_ + 1 < I_count_) && (J_count_ + 1 < J_size_))
        {
            p_ += J_stride_;
            ++J_count_;
        }
        else
        {
            p_ += I_stride_ - J_count_ * J_stride_;
            J_count_ = 0;
            ++I_count_;
        }
    }

    int& front() { return *p_; }

    int* p_;
    int I_size_, J_size_, I_stride_, J_stride_;
    int I_count_{1}, J_count_{0};
};

struct Loop_I_J_Upper
{
    Loop_I_J_Upper(int* p, int I_size, int J_size, int I_stride, int J_stride)
        : p_(p), I_size_(I_size), J_size_(J_size), I_stride_(I_stride), J_stride_(J_stride)
    {
    }

    bool is_empty() { return (I_count_ == I_size_) || (I_count_ == J_size_); }

    void pop()
    {
        assert(I_count_ < I_size_);
        if(J_count_ + 1 < J_size_)
        {
            p_ += J_stride_;
            ++J_count_;
        }
        else
        {
            p_ = p_ - (J_size_ - I_count_ - 1) * J_stride_ + I_stride_ + J_stride_;

            ++I_count_;
            J_count_ = I_count_;
        }
    }

    int& front() { return *p_; }

    int* p_;
    int I_size_, J_size_, I_stride_, J_stride_;
    int I_count_{0}, J_count_{0};
};

struct Loop_I_J_UpperStrict
{
    Loop_I_J_UpperStrict(int* p, int I_size, int J_size, int I_stride, int J_stride)
        : p_(p + J_stride), I_size_(I_size), J_size_(J_size), I_stride_(I_stride), J_stride_(J_stride)
    {
    }

    bool is_empty() { return (I_count_ == I_size_) || (I_count_ + 1 == J_size_); }

    void pop()
    {
        assert(I_count_ < I_size_);
        if(J_count_ + 1 < J_size_)
        {
            p_ += J_stride_;
            ++J_count_;
        }
        else
        {
            p_ = p_ - (J_size_ - I_count_ - 2) * J_stride_ + I_stride_ + J_stride_;

            ++I_count_;
            J_count_ = I_count_ + 1;
        }
    }

    int& front() { return *p_; }

    int* p_;
    int I_size_, J_size_, I_stride_, J_stride_;
    int I_count_{0}, J_count_{1};
};

struct Loop_I_J_All
{
    constexpr Loop_I_J_All(int* p, int I_size, int J_size, int I_stride, int J_stride) noexcept
        : p_(p),
          I_size_(I_size),
          J_size_(J_size),
          I_stride_(I_stride),
          J_stride_(J_stride),
          I_count_(0),
          J_count_(0),
          delta_(I_stride_ - (J_size_ - 1) * J_stride_)
    {
    }

    constexpr bool is_empty() noexcept { return I_count_ == I_size_; }

    constexpr void pop() noexcept
    {
        assert(I_count_ < I_size_);
        if(J_count_ < J_size_ - 1)
        {
            p_ += J_stride_;
            ++J_count_;
        }
        else
        {
            p_ += delta_;
            J_count_ = 0;
            ++I_count_;
        }
    }

    constexpr int& front() const noexcept { return *p_; }

    int* p_;
    const int I_size_, J_size_, I_stride_, J_stride_;
    int I_count_, J_count_;
    const int delta_;
};

void test_Loop_I_J()
{
    constexpr int I_size = 15, J_size = 4;
    constexpr int I_stride = 2, J_stride = I_size * I_stride + 2;

    std::vector<int> buffer(I_size * I_stride + J_size * J_stride);

    //  Loop_I_J_UpperStrict loop(&buffer[0], I_size, J_size, I_stride, J_stride);
    // Loop_I_J_UpperStrict loop(&buffer[0], J_size, I_size, J_stride, I_stride);
    Loop_I_J_All loop(&buffer[0], I_size, J_size, I_stride, J_stride);

    int c = 0;
    asm("#BEGIN");
#pragma omp simd
    // while(!loop.is_empty())
    // {
    //   ++c;
    //   loop.front() = c;
    //   loop.pop();
    //  }

    for(int i = 0; i < I_size; i++)
    {

        for(int j = 0; j < J_size; j++)
        {
            ++c;
            buffer[i * I_stride + j * J_stride] = c;
        }
    }
    asm("#END");
    for(int i = 0; i < I_size; i++)
    {

        std::cout << "\n";
        for(int j = 0; j < J_size; j++)
        {
            std::cout << std::setw(4) << buffer[i * I_stride + j * J_stride];
        }
    }

    std::cout << "\nFinal c=" << c;
}

// const auto lambda_add = [](auto& a, const auto& b)
// {
//   a += b;
// };

// const auto lambda_add = [](double& a, const double& b)
// {
//   a += b;
// };

int main()
{
    test_Loop_I_J();
    // return 0;

    // std::unique_ptr<const int[]>(new int[10]);

    // const UniqueMemoryBlock<const int> c_c_v(5);
    // UniqueMemoryBlock<int> v(5);
    // data(v)[2] = 2;
    // UniqueMemoryBlock<int> w(std::move(v));
    // std::cout << "\n" << capacity(v);
    // std::cout << "\n" << capacity(w);
    // std::cout << "\nData\n" << range(v);
    // std::cout << "\nData\n" << range(w);
    // //  std::cout << "\nData\n" << range(v);

    // //  UniqueMemoryBlock<int> wc(w);
    // //  assert(data(wc)[2] == 2);

    // std::conjunction<std::true_type, std::true_type>::value;
    // static_assert(std::conjunction<>::value, "");

    // constexpr Size_t static_size = 10;
    // TinyMemoryBlock<double, static_size> m1;

    // constexpr Size_t cp = toto(m1);

    // //  static_assert(std::is_same<const double, decltype(*data(m1))>::value, "");

    // printType<decltype(*data(m1))>();

    TinyMatrix<int, 3, 5, MatrixShape_UpperTriangular> MM;
    // MM(2, 1) = 2;
    // std::cout << "\n" << MM;
    // transposed_view(MM)(0, 2) = 4;
    // std::cout << "\n" << transposed_view(MM);

    Size_t c = 0;
    map(
        [&c](auto& m)
        {
            m = ++c;
        },
        MM);
    std::cout << "\n" << MM << "\nc=" << c << "\n";

    c = 0;
    map(
        [&c](auto& m)
        {
            m = --c;
        },
        MM.transposed_view());
	
    std::cout << "\n" << MM << "\nc=" << c << "\n";

    // TinyMatrix_ColumnMajor<int, 3, 5, MatrixShape_UpperTriangular> cM_MM;
    // TinyMatrix_RowMajor<int, 3, 5, MatrixShape_UpperTriangular> rM_MM;

    // map(
    //     [](auto& dest, const auto& source)
    //     {
    //       dest = source;
    //     },
    //     cM_MM, MM);

    // std::cout << "\n" << cM_MM;

    // map(
    //     [](auto& dest, const auto& source)
    //     {
    //       dest = source;
    //     },
    //     rM_MM, MM);

    // std::cout << "\n" << rM_MM;

    // c = 0;
    // map(
    //     [&c](auto& m)
    //     {
    //       m = ++c;
    //     },
    //     cM_MM);
    // std::cout << "\ncolMajor" << cM_MM << "\nc=" << c << "\n";

    // c = 0;
    // map(
    //     [&c](auto& m)
    //     {
    //       m = ++c;
    //     },
    //     rM_MM);
    // std::cout << "\nrowMajor" << rM_MM << "\nc=" << c << "\n";

    // auto zob = create_copy(rM_MM);

    // std::cout << "\nzob" << zob;

    Matrix<double> m;
}
