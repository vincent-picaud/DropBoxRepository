#include "gtest/gtest.h"
#include <Kiss_LinAlg/Matrix/denseMatrix.hpp>
#include <Kiss_LinAlg/Matrix/crsMatrix_implementation.hpp>
#include <Kiss_LinAlg/Vector/denseVector.hpp>
#include <Kiss_LinAlg/indexRange.hpp>

#include <Kiss_LinAlg/Matrix/crsMatrix_map.hpp>

#include <map>

using namespace Kiss;

template <typename T>
void printType()
{
    std::cerr << "\n" << __PRETTY_FUNCTION__;
}

TEST(Check_crsMatrix, Basic)
{
    typedef int T;
    std::map<Index_t, std::map<Index_t, T>> IJ_map;
    const size_t n = 6, m = 6;
    for(Index_t i = 1; i + 1 < n; i++)
    {
        // for(Index_t j = 1; j + 1 < m; j++)
        // {
        //     IJ_map[i][j] += 4;

        //     IJ_map[i][j - 1] -= 1;
        //     IJ_map[i][j + 1] -= 1;
        //     // IJ_map[i - 1][j] -= 1;
        //     // IJ_map[i + 1][j] -= 1;
        // }

        IJ_map[i][i] += 4;

        IJ_map[i][i - 1] -= 1;
        IJ_map[i][i + 1] -= 1;
        IJ_map[i - 1][i] -= 1;
        IJ_map[i + 1][i] -= 1;
    }
    IJ_map[0];
    IJ_map[n - 1];

    // Now create sparse structure
    //
    auto I_begin = create_vector<Index_t>(n + 1);

    Size_t nonZero_size = 0;
    Index_t i = 0;
    for(const auto& row : IJ_map)
    {
        I_begin[i] = nonZero_size;
        nonZero_size += row.second.size();
        ++i;
    }
    I_begin[i] = nonZero_size;

    auto J_index = create_vector<Index_t>(nonZero_size);
    auto data = create_vector<T>(nonZero_size);
    Index_t k = 0;
    for(const auto& row : IJ_map)
    {
        for(const auto& col : row.second)
        {

            J_index[k] = col.first;
            data[k] = col.second;
            ++k;
        }
    }

    CrsMatrix_Implementation<Vector<T>> M(n, m, I_begin.view_const(), J_index.view_const(), data.view());
    std::cerr << M;

    auto index_vector = create_vector<Index_t>(10);
    cwise_linearSequence(index_vector, 0, 1);

    std::cerr << "\n" << index_vector;
    std::cerr << "\n" << index_vector.view(create_indexInterval_lb_ub(3, 5));

    printType<decltype(index_vector.view(create_indexInterval_lb_ub(3, 5)))>();
    printType<decltype(index_vector.view(create_indexInterval_lb_ub(Static_Integer<3>, Static_Integer<5>)))>();

    std::cerr << "\nZob" << M.view_const(2, _);

    M.view(2, _)[2] = 2352;
    std::cerr << M;

    EXPECT_TRUE(sameStructure(M, M));
    EXPECT_TRUE(sameStructure(M, M, M));

    std::cerr << cwise_max(M);
    M += 1;
    std::cerr << "\n" << cwise_max(M);
    std::cerr << "\n" << M;
}
