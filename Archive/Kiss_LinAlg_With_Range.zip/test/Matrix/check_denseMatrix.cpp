#include "gtest/gtest.h"

#include <Kiss_LinAlg/Matrix/tinyMatrix.hpp>
#include <Kiss_LinAlg/Matrix/denseMatrix.hpp>


using namespace Kiss;

TEST(Check_DenseMatrix, Basic)
{
    constexpr Size_t I_SIZE = 4;
    constexpr Size_t J_SIZE = 5;

    auto M = create_matrix<double, MatrixShape_UpperTriangular>(4, 5);
    auto M2 = create_matrix<double>(4, 5);

    std::cerr << "\n" << M;

    TinyMatrix<int, I_SIZE, J_SIZE, MatrixShape_UpperTriangular> tinyM;

    std::cerr << "\n" << tinyM.view_const();

    // TinyMatrix<int, I_SIZE, J_SIZE, MatrixShape_UpperTriangular> tinyM2(tinyM);
    // std::cerr << "\n" << tinyM2;

    auto tinyM_cpy = create_copy(tinyM);

    std::cerr << "\nZOB\n" << tinyM_cpy;

    auto M_cpy = create_copy(M);

    std::cerr << "\nZOB\n" << M_cpy;
}

TEST(Check_DenseMatrix, DynStat)
{
    constexpr Size_t I_SIZE = 4;
    constexpr Size_t J_SIZE = 5;

    TinyMatrix<double, I_SIZE, J_SIZE> M;

    EXPECT_TRUE(is_integral_constant<decltype(M.I_size())>::value);
}

TEST(Check_DenseMatrix, Inplace_Operators)
{
    constexpr Size_t SIZE = 5;

    auto M = create_matrix<int, MatrixShape_UpperTriangular>(SIZE, SIZE);

    M = 0;
    M += 1;
    EXPECT_TRUE(cwise_sum(M) == SIZE * (SIZE + 1) / 2);

    M *= 4;
    EXPECT_TRUE(cwise_sum(M) == 4 * SIZE * (SIZE + 1) / 2);
}
