// #include "gtest/gtest.h"

// #include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
// #include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr.hpp>
// #include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock.hpp>

// using namespace Kiss;
// constexpr Size_t CAPACITY = 10;

// template <typename TYPE>
// struct FinalClass_MemoryBlock;

// template <typename T>
// struct FinalClass_MemoryBlock<TinyMemoryBlock<T, CAPACITY>> : public ::testing::Test
// {
//     typedef TinyMemoryBlock<T, CAPACITY> MemoryBlockType;

//     virtual void SetUp() {}
//     virtual void TearDown() {}

//     MemoryBlockType memoryBlock_;
// };

// template <typename T>
// struct FinalClass_MemoryBlock<TinyMemoryBlock_RawPtr<T, CAPACITY>> : public ::testing::Test
// {
//     typedef TinyMemoryBlock_RawPtr<T, CAPACITY> MemoryBlockType;

//     virtual void SetUp() {}
//     virtual void TearDown() {}

//    private:
//     T buffer[CAPACITY]{};

//    public:
//     MemoryBlockType memoryBlock_{buffer};
// };

// template <typename T>
// struct FinalClass_MemoryBlock<MemoryBlock_RawPtr<T>> : public ::testing::Test
// {
//     typedef MemoryBlock_RawPtr<T> MemoryBlockType;

//     virtual void SetUp() {}
//     virtual void TearDown() {}

//    private:
//     T buffer[CAPACITY]{};

//    public:
//     MemoryBlockType memoryBlock_{buffer, CAPACITY};
// };

// template <typename T>
// struct FinalClass_MemoryBlock<UniqueMemoryBlock<T>> : public ::testing::Test
// {
//     typedef UniqueMemoryBlock<T> MemoryBlockType;

//     virtual void SetUp() {}
//     virtual void TearDown() {}

//    public:
//     MemoryBlockType memoryBlock_{CAPACITY};
// };

// typedef ::testing::Types<TinyMemoryBlock<int, CAPACITY>, TinyMemoryBlock<const int, CAPACITY>,
//                          TinyMemoryBlock_RawPtr<int, CAPACITY>, TinyMemoryBlock_RawPtr<const int, CAPACITY>,
//                          MemoryBlock_RawPtr<int>, MemoryBlock_RawPtr<const int>, UniqueMemoryBlock<int>,
//                          UniqueMemoryBlock<const int>> FinalClass_MemoryBlockType;

// TYPED_TEST_CASE(FinalClass_MemoryBlock, FinalClass_MemoryBlockType);

// template <typename T>
// void printType()
// {
//     std::cerr << "\n" << __PRETTY_FUNCTION__;
// }

// /** @addtogroup Kiss_LinAlg_MemoryBlock_Group

//     # Interface UTest
//     ## Must have ElementType member
//     @snippet check_memoryBlock.cpp Interface_ElementType
//     ## Must have StorableType member
//     @snippet check_memoryBlock.cpp Interface_StorableType
//     ## Must have a capacity functionality
//     @snippet check_memoryBlock.cpp Interface_Capacity
//     ## Must have a data functionality
//     @snippet check_memoryBlock.cpp Interface_Data
//     ## Must have a range functionality
//     @snippet check_memoryBlock.cpp Interface_Range
//     ## Must have a cwise_copy functionality
//     @snippet check_memoryBlock.cpp Interface_Cwise_Copy
//  */
// TYPED_TEST(FinalClass_MemoryBlock, Interface)
// {
//     typedef TypeParam MemoryBlockType;
//     MemoryBlockType& memoryBlock = this->memoryBlock_;

//     //! [[Interface_ElementType]]
//     EXPECT_TRUE((std::is_same<typename MemoryBlockType::ElementType,
//                               std::remove_cv_t<typename MemoryBlockType::ElementType>>::value));
//     //! [[Interface_ElementType]]

//     //! [[Interface_StorableType]]
//     EXPECT_TRUE((Is_CRTP_Interface<typename MemoryBlockType::StorableType, Interface_MemoryBlock>::value));
//     //! [[Interface_StorableType]]

//     //! [[Interface_Capacity]]
//     EXPECT_TRUE(memoryBlock.capacity() == CAPACITY);
//     //! [[Interface_Capacity]]

//     //! [[Interface_Data]]
//     EXPECT_TRUE((std::is_same<std::remove_const_t<std::remove_pointer_t<decltype(memoryBlock.data())>>,
//                               typename MemoryBlockType::ElementType>::value));
//     //! [[Interface_Data]]

//     //! [[Interface_Range]]
//     EXPECT_TRUE(range(memoryBlock).Is_Forward_Range());

//     EXPECT_TRUE((std::is_const<std::remove_pointer_t<decltype(memoryBlock.data())>>::value
//                      ? range(memoryBlock).Is_Read_Range()
//                      : range(memoryBlock).Is_Write_Range()));

//     //================

//     EXPECT_TRUE(range_const(memoryBlock).Is_Forward_Range());

//     EXPECT_TRUE(range_const(memoryBlock).Is_Read_Range());
//     EXPECT_TRUE(!range_const(memoryBlock).Is_Write_Range());
//     //! [[Interface_Range]]

//     //! [[Interface_Cwise_Copy]]
//     typename MemoryBlockType::StorableType dest(memoryBlock.capacity());
//     cwise_copy(dest, memoryBlock);
//     //! [[Interface_Cwise_Copy]]
// }

// TEST(Check_MemoryBlock, Trivial)
// {
//     constexpr Size_t static_size = 10;

//     TinyMemoryBlock<double, static_size> m1, m2;

//     constexpr Size_t n = capacity(m1);  // Must compile
//     EXPECT_TRUE(n == static_size);

//     m1.data()[static_size / 2] = 2;
//     m2.data()[static_size / 2] = 4;

//     EXPECT_TRUE(m1.data()[static_size / 2] != m2.data()[static_size / 2]);
//     cwise_copy(m1, m2);
//     EXPECT_TRUE(m1.data()[static_size / 2] == m2.data()[static_size / 2]);

//     // Experiment...
//     // (see TinyMemoryBlock<double, static_size>::TinyMemoryBlock() )
//     //
//     static_assert(std::is_literal_type<TinyMemoryBlock<double, static_size>>::value, "");
// }

// TEST(Check_MemoryBlock, ConstProperty)
// {
//     //! [[Const_Property]]
//     constexpr Size_t static_size = 10;

//     TinyMemoryBlock<double, static_size> m_m_array;
//     const TinyMemoryBlock<double, static_size> c_m_array{};
//     TinyMemoryBlock<const double, static_size> m_c_array{};
//     const TinyMemoryBlock<const double, static_size> c_c_array{};

//     EXPECT_TRUE(std::is_const<std::remove_pointer_t<const double*>>::value);

//     EXPECT_TRUE(!std::is_const<std::remove_pointer_t<decltype(data(m_m_array))>>::value);
//     EXPECT_TRUE(!std::is_const<std::remove_pointer_t<decltype(data(c_m_array))>>::value);
//     EXPECT_TRUE(std::is_const<std::remove_pointer_t<decltype(data(m_c_array))>>::value);
//     EXPECT_TRUE(std::is_const<std::remove_pointer_t<decltype(data(c_c_array))>>::value);
//     //! [[Const_Property]]
// }

// TEST(Check_MemoryBlock, Const_Range_Property)
// {
//     //! [[Const_Range_Property]]
//     constexpr Size_t static_size = 10;

//     TinyMemoryBlock<double, static_size> m_m_array{};
//     const TinyMemoryBlock<double, static_size> c_m_array{};
//     TinyMemoryBlock<const double, static_size> m_c_array{};
//     const TinyMemoryBlock<const double, static_size> c_c_array{};

//     EXPECT_TRUE(!std::is_const<std::remove_reference_t<decltype(front(range(m_m_array)))>>::value);
//     EXPECT_TRUE(!std::is_const<std::remove_reference_t<decltype(front(range(c_m_array)))>>::value);
//     EXPECT_TRUE(std::is_const<std::remove_reference_t<decltype(front(range(m_c_array)))>>::value);
//     EXPECT_TRUE(std::is_const<std::remove_reference_t<decltype(front(range(c_c_array)))>>::value);
//     //! [[Const_Range_Property]]
// }

// TEST(Check_MemoryBlock, Constructor)
// {
//     constexpr Size_t static_size = 10;

//     TinyMemoryBlock<double, static_size> m1;

//     // Could work, but we do not want to provide it (not efficient)
//     // TinyMemoryBlock<double, static_size> m2(view_const(m1));
// }
