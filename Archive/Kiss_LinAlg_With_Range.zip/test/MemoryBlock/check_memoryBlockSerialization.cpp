#include "gtest/gtest.h"

#include <Kiss_LinAlg/MemoryBlock/uniqueMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/memoryBlock_rawPtr.hpp>

#include <fstream>
#include <type_traits>

// include headers that implement a archive in simple text format
#include <boost/archive/text_oarchive.hpp>
#include <boost/archive/text_iarchive.hpp>

using namespace Kiss;


TEST(check_memoryBlockSerialization, uniqueMemoryBlock)
{
    const Size_t n = 10;
    UniqueMemoryBlock<const int> m1(10);
    auto v_m1 = m1.view();

    // for(int i = 0; i < n; i++)
    // {

    //     m1.data()[i] = i;
    // }

    // save data to archive
    {
        std::ofstream ofs("filename");
        boost::archive::text_oarchive oa(ofs);

        oa << m1;
//        oa << v_m1;
    }

    // load data
    UniqueMemoryBlock<const int> m2;
    {
        std::ifstream ifs("filename");
        boost::archive::text_iarchive ia(ifs);
        ia >> m2;
    }

    std::cerr << "\n" << m2.range();
    std::cerr << "\n" << v_m1.range();
}
