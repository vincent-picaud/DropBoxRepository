#include "gtest/gtest.h"

#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock.hpp>
#include <Kiss_LinAlg/MemoryBlock/tinyMemoryBlock_rawPtr.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>


using namespace Kiss;

TEST(Check_MemoryBlock_Array, TestViewAndStorage)
{
    TinyMemoryBlock<int, 10> a;
    for(int i = 0; i < 10; i++)
    {
        a.data()[i] = 2 * i + 1;
    };

    std::cerr << "\n" << a;

    int t[20] = {4, 5, 6, 7, 8, 9, 0, 1, 2, 3};
    auto ta = TinyMemoryBlock_RawPtr<int, 10>(t);

    std::cerr << "\n" << ta;

    std::cerr << "\n" << ta.view_const();
    std::cerr << "\n" << ta.view();

    auto v_ta = ta.view();
    //  auto v_ta = view_const();
    cwise_copy(v_ta, a);

    //  std::cerr << "\n" << storable(view_const());
}
