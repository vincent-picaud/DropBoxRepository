#include "gtest/gtest.h"

#include <Kiss_LinAlg/MemoryBlock/sharedMemoryBlock.hpp>

#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include <fstream>

using namespace Kiss;

TEST(check_sharedMemoryBlock, basic)
{
    Size_t n = 10;
    SharedMemoryBlock<int> m(n);
    EXPECT_EQ(m.capacity(), n);
    EXPECT_EQ(m.use_count(), 1);

    SharedMemoryBlock<int> m2(std::move(m));
    EXPECT_EQ(m.capacity(), n);
    EXPECT_EQ(m2.capacity(), n);
    EXPECT_EQ(m.use_count(), 2);

    for(int i = 0; i < n; i++)
    {

        m.data()[i] = i;
    }

    // save data to archive
    {
        std::ofstream ofs("filename");
        boost::archive::xml_oarchive oa(ofs);

        oa << BOOST_SERIALIZATION_NVP(m);
        oa << BOOST_SERIALIZATION_NVP(m2);
    }

    //    load data
    SharedMemoryBlock<int> loaded_m;
    SharedMemoryBlock<int> loaded_m2;
    {
        std::ifstream ifs("filename");
        boost::archive::xml_iarchive ia(ifs);
        ia >> BOOST_SERIALIZATION_NVP(loaded_m);
        ia >> BOOST_SERIALIZATION_NVP(loaded_m2);
    }
    EXPECT_EQ(loaded_m.capacity(), n);
    EXPECT_EQ(loaded_m2.capacity(), n);
    EXPECT_EQ(loaded_m.use_count(), 2);

    auto shared_1 = loaded_m.view();
    EXPECT_EQ(loaded_m.use_count(), 3);

    auto shared_2 = loaded_m.view_const();
    EXPECT_EQ(loaded_m.use_count(), 4);

    shared_1.data()[2] = 3;

	EXPECT_EQ(loaded_m2.use_count(), 4);
    loaded_m.reset();
	EXPECT_EQ(loaded_m.use_count(), 0);
    EXPECT_EQ(loaded_m2.use_count(), 3);

}
