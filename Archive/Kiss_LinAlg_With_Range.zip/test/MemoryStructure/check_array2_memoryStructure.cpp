#include "gtest/gtest.h"

#include <Kiss_LinAlg/MemoryStructure/array2_memoryStructure.hpp>
#include <Kiss_LinAlg/Meta/printType.hpp>

using namespace Kiss;

TEST(array2_memorystructure, dynstat_offset_2)
{
    typedef Array2_MemoryStructure<std::integral_constant<Index_t, 0>, std::integral_constant<Size_t, 10>,
                                   std::integral_constant<Size_t, 6>, std::integral_constant<Index_t, 1>,
                                   std::integral_constant<Index_t, 10>> MemoryStructureType;

    MemoryStructureType toTest;

    EXPECT_TRUE((is_integral_constant<decltype(toTest.I_stride())>::value));
    EXPECT_TRUE((is_integral_constant<decltype(toTest.J_stride())>::value));
    EXPECT_TRUE((is_integral_constant<decltype(toTest.offset())>::value));
    EXPECT_FALSE((is_integral_constant<decltype(toTest.offset_index(3, 4))>::value));
    EXPECT_TRUE((is_integral_constant<decltype(toTest.offset_index(Static_Integer<3>, Static_Integer<4>))>::value));
    EXPECT_TRUE(toTest.offset_index(3, 4) == toTest.offset_index(Static_Integer<3>, Static_Integer<4>));
}
