#include "gtest/gtest.h"

#include <Kiss_LinAlg/MemoryStructure/array_memoryStructure.hpp>
#include <Kiss_LinAlg/Meta/printType.hpp>

using namespace Kiss;

// TEST(array_memorystructure, dynstat_offset)
// {

//     typedef std::integral_constant<Index_t, 2> Two;
//     auto two = Two::value;

//     // EXPECT_FALSE((is_integral_constant<decltype((0 == 1) ? Two() : two)>::value));
//     // EXPECT_TRUE((is_integral_constant<decltype((0 == 0) ? Two() : two)>::value));

//     EXPECT_TRUE(is_integral_constant<Two>::value);
//     EXPECT_TRUE((std::is_same<Index_t, decltype(two)>::value));

//     auto offset_Two = compute_array_offset(Two(), Two(), Two(), Two());
//     auto offset_Two_mixed = compute_array_offset(Two(), two, Two(), Two());
//     auto offset_two = compute_array_offset(two, two, two, two);

//     EXPECT_TRUE(is_integral_constant<decltype(offset_Two)>::value);
//     EXPECT_FALSE(is_integral_constant<decltype(offset_Two_mixed)>::value);
//     EXPECT_FALSE(is_integral_constant<decltype(offset_two)>::value);

//     EXPECT_TRUE(offset_Two == 6);
//     EXPECT_TRUE(offset_Two_mixed == 6);
//     EXPECT_TRUE(offset_two == 6);

//     printType(Two());
// }

TEST(array_memorystructure, dynstat_offset_2)
{
    typedef Array_MemoryStructure<std::integral_constant<Index_t, 0>, std::integral_constant<Size_t, 10>,
                                  std::integral_constant<Index_t, 1>> TinyVectorStructureType;

    TinyVectorStructureType toTest;

    EXPECT_TRUE((is_integral_constant<decltype(toTest.stride())>::value));
    EXPECT_TRUE((is_integral_constant<decltype(toTest.offset())>::value));
    EXPECT_FALSE((is_integral_constant<decltype(toTest.offset_index(3))>::value));
    EXPECT_TRUE((is_integral_constant<decltype(toTest.offset_index(Static_Integer<3>))>::value));
    EXPECT_TRUE(toTest.offset_index(3) == toTest.offset_index(Static_Integer<3>));

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ IMPORTANT

    //
    // CAVEAT
    //
    // This DOESNOT WORK because Static_Integer<0> and
    // toTest.offset_index(toTest.size() - Static_Integer<1>) are
    // potentially DIFFERENT types, EVEN if
    // toTest.offset_index(toTest.size() - Static_Integer<1>) is
    // std::integral_constant<Index_t, OTHER_VALUE!=0>
    // -> hence when can not use (?:) ternary operator
    // We have defined integral_constant_min/max for theses cases:
    //
    EXPECT_FALSE((is_integral_constant<decltype(toTest.size() == Static_Integer<0>
                                                    ? Static_Integer<0>
                                                    : toTest.offset_index(toTest.size() - Static_Integer<1>))>::value));

    EXPECT_TRUE((
        is_integral_constant<decltype(
            integral_constant_max(Static_Integer<0>, toTest.offset_index(toTest.size() - Static_Integer<1>)))>::value));

    // This technique is used HERE:
    EXPECT_TRUE((is_integral_constant<decltype(toTest.required_capacity())>::value));

    //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    EXPECT_TRUE((is_integral_constant<decltype(toTest.check_index((Static_Integer<1> + Static_Integer<1>)*(
                     Static_Integer<1> + Static_Integer<1> + Static_Integer<1>)*(Static_Integer<1> + Static_Integer<1> +
                                                                                 Static_Integer<1>)))>::value));

    EXPECT_TRUE(toTest.check_index((Static_Integer<1> + Static_Integer<1>)));
    EXPECT_FALSE(toTest.check_index(
        (Static_Integer<1> + Static_Integer<1>)*(Static_Integer<1> + Static_Integer<1> + Static_Integer<1>)*(
            Static_Integer<1> + Static_Integer<1> + Static_Integer<1>)));
}
