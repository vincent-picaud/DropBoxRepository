#include "gtest/gtest.h"

#include <Kiss_LinAlg/Meta/dynStatValue.hpp>

using namespace Kiss;

TEST(Check_DynStatValue, Basic)
{
  //! [[Basic]]
  constexpr DynStatValue<int> dyn(1);
  EXPECT_FALSE(decltype(dyn)::is_static());
  EXPECT_TRUE(dyn == 1);

  constexpr DynStatValue<std::integral_constant<int, 1>> stat(1);
  EXPECT_TRUE(decltype(stat)::is_static());
  EXPECT_TRUE(stat == 1);
  //! [[Basic]]
}
