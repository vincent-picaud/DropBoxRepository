#include "gtest/gtest.h"

#include <Kiss_LinAlg/Meta/integral_constant_manip.hpp>
#include <Kiss_LinAlg/Meta/is_integral_constant.hpp>

using namespace Kiss;

template <typename T>
void printType()
{
    std::cerr << "\n" << __PRETTY_FUNCTION__;
}

TEST(check_integral_constant_manip, OperatorOverloading)
{
    // EXPECT_TRUE((std::is_same<double, Integral_Constant_Common_Type<double, const double>::type>::value));

    EXPECT_TRUE((std::is_same<int, decltype(5 + std::integral_constant<int, 2>())>::value));
    EXPECT_TRUE((std::is_same<std::integral_constant<int, 5 + 2>,
                              decltype(std::integral_constant<int, 5>() + std::integral_constant<int, 2>())>::value));
    EXPECT_TRUE((std::is_same<int, decltype(std::integral_constant<int, 2>() + 5)>::value));

    printType<decltype(std::integral_constant<int, 5>() + std::integral_constant<int, 2>())>();
}



TEST(check_integral_constant_manip, Integral_Constant_Min)
{
    EXPECT_TRUE(integral_constant_min(1, 2) == 1);
    EXPECT_TRUE(integral_constant_min(Static_Integer<1>, Static_Integer<0>) == 0);
    EXPECT_TRUE(integral_constant_min(Static_Integer<1>, 1) == 1);
    EXPECT_TRUE(integral_constant_min(2, Static_Integer<1>) == 1);

    EXPECT_FALSE(is_integral_constant<decltype(integral_constant_min(1, 2))>::value);
    EXPECT_TRUE(is_integral_constant<decltype(integral_constant_min(Static_Integer<1>, Static_Integer<0>))>::value);
}
