#include "gtest/gtest.h"

#include <Kiss_LinAlg/Meta/is_integral_constant.hpp>

using namespace Kiss;

TEST(Check_Is_Integral_Constant, Basic)
{
  //! [[Basic]]
  // Check type
  EXPECT_FALSE((is_integral_constant<double>::value));
  EXPECT_TRUE((is_integral_constant<std::integral_constant<int, 2>>::value));

  // Use of value_type field
  EXPECT_TRUE((std::is_same<typename is_integral_constant<double>::value_type, double>::value));
  EXPECT_TRUE((std::is_same<typename is_integral_constant<std::integral_constant<int, 2>>::value_type, int>::value));
  //! [[Basic]]
}
