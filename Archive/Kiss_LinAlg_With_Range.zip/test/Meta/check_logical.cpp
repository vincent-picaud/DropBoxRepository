#include "gtest/gtest.h"

#include <Kiss_LinAlg/Meta/logical.hpp>

using namespace Kiss;

TEST(check_logical, basic)
{
    EXPECT_TRUE(conjunction(true, true, true));
    EXPECT_FALSE(conjunction(true, true, false));
}
