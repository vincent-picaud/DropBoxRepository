#include "gtest/gtest.h"

#include <Kiss_LinAlg/Range/array_range.hpp>
#include <Kiss_LinAlg/Range/range_iterator.hpp>
#include <Kiss_LinAlg/Range/range_map.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>


using namespace Kiss;

constexpr Size_t N = 16;

template <typename TYPE>
struct Interface_Range_Generator;

template <typename T>
struct Interface_Range_Generator<Array_Range<T>> : public ::testing::Test
{
  typedef Array_Range<T> Interface_RangeType;

  virtual void SetUp() { range_ = std::unique_ptr<Interface_RangeType>(new Interface_RangeType(&buffer_[0], N, 1)); }
  virtual void TearDown() {}

  std::array<T, N> buffer_;
  std::unique_ptr<Interface_RangeType> range_;
};

typedef ::testing::Types<Array_Range<double>> Interface_RangeType_CommonInterface_Test;
TYPED_TEST_CASE(Interface_Range_Generator, Interface_RangeType_CommonInterface_Test);

/** @defgroup Interface_RangeInterface_Group Interface_Range interface group
    @brief Interface_Range interface group
*/
TYPED_TEST(Interface_Range_Generator, Common_Interface)
{
  const TypeParam& const_range(*this->range_);
  TypeParam& range(*this->range_);

  EXPECT_TRUE((std::is_same<typename TypeParam::ElementType, typename TypeParam::ElementType>::value));

  EXPECT_TRUE(!is_empty(const_range));
  EXPECT_TRUE(!is_empty(const_range, range, const_range));

  EXPECT_TRUE(!at_least_one_is_empty(const_range, range, const_range));
}

// Test Read/Forward Interface_Range
//
typedef ::testing::Types<Array_Range<double>> Interface_RangeType_Read_Forward_Test;
TYPED_TEST_CASE(Interface_Range_Generator, Interface_RangeType_Read_Forward_Test);

TYPED_TEST(Interface_Range_Generator, Interface_RangeType_Read_Forward_Test)
{
  EXPECT_TRUE(TypeParam::Is_Read_Range());
  EXPECT_TRUE(TypeParam::Is_Forward_Range());

  const TypeParam& const_range(*this->range_);
  TypeParam& range(*this->range_);

  EXPECT_TRUE((std::is_same<typename TypeParam::ElementType, typename TypeParam::ElementType>::value));
  EXPECT_TRUE(!is_empty(const_range));

  this->buffer_[0] = 10;
  EXPECT_TRUE(front(const_range) == 10);

  // Must compile
  TypeParam r(range);
  popFront(r, r);
  this->buffer_[2] = 5;
  EXPECT_TRUE(front(r) == 5);

  map(
      [](const auto& toPrint)
      {
        std::cerr << "\n" << toPrint;
      },
      range);
}

// Test Write/Forward Interface_Range
//
typedef ::testing::Types<Array_Range<double>> Interface_RangeType_Write_Forward_Test;
TYPED_TEST_CASE(Interface_Range_Generator, Interface_RangeType_Write_Forward_Test);

TYPED_TEST(Interface_Range_Generator, Interface_RangeType_Write_Forward_Test)
{
  EXPECT_TRUE(TypeParam::Is_Write_Range());
  EXPECT_TRUE(TypeParam::Is_Forward_Range());

  const TypeParam& const_range(*this->range_);
  TypeParam& range(*this->range_);

  EXPECT_TRUE((std::is_same<typename TypeParam::ElementType, typename TypeParam::ElementType>::value));
  EXPECT_TRUE(!is_empty(const_range));

  this->buffer_[0] = 0;
  front(range) = 10;
  EXPECT_TRUE(this->buffer_[0] == 10);

  popFront(range);
}
