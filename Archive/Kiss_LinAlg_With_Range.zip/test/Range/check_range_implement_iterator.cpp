#include <gtest/gtest.h>

#include <Kiss_LinAlg/Range/range_iterator.hpp>
#include <Kiss_LinAlg/Range/range_oneElement.hpp>
#include <Kiss_LinAlg/Range/range_map.hpp>
#include <Kiss_LinAlg/CWise/cwise_base.hpp>



#include <array>
#include <vector>

using namespace Kiss;
// using namespace std;

TEST(Check_range_Iterator, Array)
{
    constexpr Size_t N = 12;
    typedef std::array<double, N> ArrayType;
    ArrayType array_dest, array_source;

    auto range_dest = create_range(array_dest);
    auto range_source = create_range(static_cast<const ArrayType&>(array_source));
    EXPECT_TRUE((!is_empty(range_dest)));
    EXPECT_TRUE((!is_empty(range_source)));

    EXPECT_TRUE(range_dest.Is_Read_Range());
    EXPECT_TRUE(range_dest.Is_Write_Range());
    EXPECT_TRUE(range_source.Is_Read_Range());
    EXPECT_TRUE(!range_source.Is_Write_Range());

    Index_t i = 0;
    for(auto& s : array_source)
    {
        s = ++i;
    }

    cwise_copy(range_dest, range_source);
    std::cerr << "\n" << range_dest;
    EXPECT_TRUE(array_dest == array_source);

    // Mix with vector
    std::vector<int> v(N, 0);

    cwise_copy(create_range(v), range_source);
    std::cerr << "\nv:" << create_range(v);
    cwise_copy(create_reverse_range(v), range_source);
    std::cerr << "\nv:" << create_range(v);

    cwise_copy(create_reverse_range(v), Range_OneElement<double>(5));
    std::cerr << "\nv:" << create_range(v);
}

