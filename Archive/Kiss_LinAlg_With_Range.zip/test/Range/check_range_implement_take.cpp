#include <gtest/gtest.h>

#include <Kiss_LinAlg/Range/range_take.hpp>
#include <Kiss_LinAlg/Range/range_iterator.hpp>



#include <array>
#include <vector>

using namespace Kiss;
// using namespace std;

TEST(Check_range_Take, Basic)
{
    std::vector<double> V(10);
    auto v_range = create_range(V);
    auto restricted_v_range = take(5, v_range);
	restricted_v_range.clone();
	
    std::cerr << "\n" << restricted_v_range;
}
