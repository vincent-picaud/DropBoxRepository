#include "gtest/gtest.h"

#include <Kiss_LinAlg/Range/array_range.hpp>

using namespace Kiss;

TEST(Check_Range_New, Const)
{
  double fake[10];
  const double const_fake[10]{};

  auto m_m_range = create_array_range(fake, 1, 1);
  const auto c_m_range = create_array_range(fake, 1, 1);

  auto m_c_range = create_array_range(const_fake, 1, 1);
  const auto c_c_range = create_array_range(const_fake, 1, 1);

  EXPECT_TRUE(!std::is_const<std::remove_reference_t<decltype(front(m_m_range))>>::value);
  EXPECT_TRUE(!std::is_const<std::remove_reference_t<decltype(front(c_m_range))>>::value);
  EXPECT_TRUE(std::is_const<std::remove_reference_t<decltype(front(m_c_range))>>::value);
  EXPECT_TRUE(std::is_const<std::remove_reference_t<decltype(front(c_c_range))>>::value);
}
