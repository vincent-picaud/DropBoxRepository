#include <gtest/gtest.h>

#include <Kiss_LinAlg/Range/range_take.hpp>
#include <Kiss_LinAlg/Range/range_iterator.hpp>
#include <Kiss_LinAlg/Range/range_oneElement.hpp>



#include <array>
#include <vector>

using namespace Kiss;
// using namespace std;

TEST(Check_Range_OneElement, Value_vs_Ref)
{
  //! [[Value_vs_Ref]]
  double x = 1;
  auto oneElement = create_range_oneElement(x);
  auto ref_oneElement = create_range_oneElement_reference(x);
  EXPECT_TRUE(front(oneElement) == 1);
  EXPECT_TRUE(front(ref_oneElement) == 1);
  x = 2;
  EXPECT_TRUE(front(oneElement) == 1);
  EXPECT_TRUE(front(ref_oneElement) == 2);
  //! [[Value_vs_Ref]]
}
