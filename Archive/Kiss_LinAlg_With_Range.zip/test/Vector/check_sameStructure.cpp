#include "gtest/gtest.h"



#include <Kiss_LinAlg/Vector/sparseVector.hpp>



using namespace Kiss;

TEST(check_sameStructure, sparseVector)
{
    SparseVector<double> sv1, sv2;

    EXPECT_TRUE(sameStructure(sv1, sv2));
}
