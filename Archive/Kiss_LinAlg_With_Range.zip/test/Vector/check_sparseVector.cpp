#include "gtest/gtest.h"

#include <Kiss_LinAlg/Vector/denseVector.hpp>
#include <Kiss_LinAlg/Vector/sparseVector.hpp>

#include <Kiss_LinAlg/Module/LinearAlgebra/euclidean.hpp>

using namespace Kiss;

TEST(check_sparseVector, basic)
{
    // toto
    auto index_vector = create_vector<Index_t>(5);
    cwise_linearSequence(index_vector, 3, 5);
    auto sv = create_sparseVector(200, index_vector.view_const(), create_vector<double>(5));
    auto index_vector2 = create_vector<Index_t>(5);
    index_vector2 = index_vector;
    auto sv2 = create_sparseVector(200, index_vector2.view_const(), create_vector<double>(5));
    //    decltype(sv) sv2;

    sv = 0;
    std::cerr << "\n" << sv;

    sv2 = sv;
    std::cerr << "\n" << sv2;
}

TEST(check_sparseVector, dot)
{
    const Size_t n = 10;

    auto v1 = create_vector<Index_t>(n);
    v1 = 2;

    EXPECT_FALSE((is_registred_scalar<decltype(v1)>::value));
    EXPECT_TRUE((is_registred_scalar<Index_t>::value));

    // 2 Scalars
    EXPECT_EQ(dot(1., 2), 2.);

    // 2 DenseVector
    EXPECT_EQ(dot(v1, v1), n * 2 * 2);

    // Create 1 sparse vector
    //
    auto index_vector = create_vector<Index_t>(n / 2);
    cwise_linearSequence(index_vector, 3, 1);
    auto sv = create_sparseVector<Index_t>(n, index_vector.view_const());
    sv = 2;

    // 1 DenseVector & 1 SparseVector
    EXPECT_EQ(dot(v1, sv), sv.nonZero_size() * 2 * 2);
    // 1 SparseVector & 1 DenseVector
    EXPECT_EQ(dot(sv, v1), sv.nonZero_size() * 2 * 2);
    // For the moment, missing specialization... TODO
       EXPECT_EQ(dot(sv, sv), sv.nonZero_size() * 2 * 2);

    std::cerr << "\nSparse" << sv;
    sv+=2;
    std::cerr << "\nSparse" << sv;
    std::cerr << "\nDense" << v1;
}

// template <typename D1, typename D2>
// bool test_sameStructure(const Interface_Vector<D1>& v1, const Interface_Vector<D2>& v2)
// {
//     return sameStructure(v1, v2);
// }

// TEST(check_sparseVector, sameStructure_propagation)
// {
//     auto v1 = create_vector<Index_t>(5);
//     EXPECT_TRUE(test_sameStructure(v1, v1));
// }
