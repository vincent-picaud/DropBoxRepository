#include "gtest/gtest.h"

#include <Kiss_LinAlg/Vector/tinyVector.hpp>
#include <Kiss_LinAlg/Meta/as_const.hpp>


using namespace Kiss;

constexpr Size_t N = 10;

TEST(Check_TinyVector, Integral_Constant)
{

    TinyVector<int, 10> v;

    EXPECT_TRUE(is_integral_constant<decltype(v.size())>::value);

    // Must not compile:    v[Static_Integer<12>];
    v[Static_Integer<2>];
}

TEST(Check_TinyVector, View)
{
    TinyVector<int, 10> v;
    v = 1;
    std::cerr << v;
    std::cerr << v.view();
    v.view() = 2;
    std::cerr << v.view_const();

    // Check offset
    //
    static_assert(is_integral_constant<decltype(v.stride())>::value, "");

    //  constexpr Size_t v_size = v.view(create_indexInterval(create_lowerBound<2>(), create_size<3>())).size();

    // This work
    //    constexpr Size_t v_size = create_indexInterval(create_lowerBound<2>(), create_size<3>()).size();
}
