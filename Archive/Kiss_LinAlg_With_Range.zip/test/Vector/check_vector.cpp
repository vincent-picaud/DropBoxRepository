#include "gtest/gtest.h"

#include <Kiss_LinAlg/Vector/denseVector.hpp>
#include <Kiss_LinAlg/Meta/printType.hpp>

using namespace Kiss;

TEST(check_vector, view)
{
    const Size_t n = 10;

    typedef DenseVector_Implementation<Index_t, Size_t, std::integral_constant<Index_t, 3>, SharedMemoryBlock<double>>
        VectorType;
    typedef typename VectorType::VectorStructureType VectorStructureType;
    typedef typename VectorType::MemoryBlockType MemoryBlockType;

    VectorStructureType vectorStructure(2, n, 3);
    MemoryBlockType memoryBlock(vectorStructure.required_capacity());

    VectorType v(vectorStructure, std::move(memoryBlock));

    cwise_linearSequence(v, 1, 4);

    EXPECT_TRUE(v[0] == 1);
    EXPECT_TRUE(v[n - 1] == 1 + 4 * (n - 1));

    const auto v_view_3_5_static = v.view(create_indexInterval_lb_ub(Static_Integer<3>, Static_Integer<5>));
    const auto v_view_3_5_dynamic = v.view(create_indexInterval_lb_ub(3, 5));

    EXPECT_TRUE(v_view_3_5_static == v_view_3_5_dynamic);
    EXPECT_TRUE(v_view_3_5_static.size() == create_indexInterval_lb_ub(Static_Integer<3>, Static_Integer<5>).size());
    EXPECT_TRUE(v_view_3_5_static[0] == v[3]);
    EXPECT_TRUE(v_view_3_5_static[2] == v[5]);

    std::cerr << "\n" << v_view_3_5_static;
}

TEST(check_vector, Operator)
{
    Size_t n = 10;
    auto v = create_vector<int>(n);
    v = 0;
    EXPECT_TRUE(cwise_sum(v) == 0);

    v += 1;
    EXPECT_TRUE(cwise_sum(v) == n);
    EXPECT_TRUE(std::is_const<std::remove_reference_t<decltype(v += 1)>>::value);
    // v -= 2;
    // EXPECT_TRUE(cwise_sum(v) == -n);

    printType<decltype(create_vector(/* dynamic offset */
                                     Index_t(),
                                     /* dynamic size */
                                     Size_t(),
                                     /* static stride=1 */
                                     Static_Integer<1>, // CAVEAT: not Static_Integer<1>() !!! (which is an Index_t)
                                     /* shared memory block */
                                     SharedMemoryBlock<double>()))>();
}
