#include "gtest/gtest.h"

#include <Kiss_LinAlg/crtp.hpp>

using namespace Kiss;

TEST(Demo, Trivial) {}
