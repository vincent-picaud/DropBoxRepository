#include "gtest/gtest.h"

#include <Kiss_LinAlg/indexInterval.hpp>

#include <array>

using namespace Kiss;

TEST(check_indexinterval, integral_constant)
{
    auto interval = create_indexInterval_lb_size(Static_Integer<5>, 6);

    EXPECT_TRUE((is_integral_constant<decltype(interval.lowerBound())>::value));
}

TEST(check_indexinterval, empty)
{
    //! [[ConstExpr]]
    constexpr auto interval = create_indexInterval_lb_size(Static_Integer<5>, 6);

    EXPECT_TRUE(decltype(interval)::is_static_lowerBound());
    EXPECT_FALSE(decltype(interval)::is_static_size());

    // Even if we used 6
    // this must compile thanks to the use constexpr
    //
    std::array<int, interval.size()> t;

    // Maybe it is safer to explicitly use a static size
    //
    auto interval2 = create_indexInterval_lb_size(Static_Integer<5>, Static_Integer<6>);

    EXPECT_TRUE(decltype(interval2)::is_static_lowerBound());
    EXPECT_TRUE(decltype(interval2)::is_static_size());

    // Does not works anymore (even if size() is constexpr)
    //  std::array<int, interval2.size()> t2;
    // another safer way (once the static type is defined)
    std::array<int, decltype(interval2)::SizeType::value> t3;
    //! [[ConstExpr]]

    //! [[UpperBoundTypeDeduction]]
    // Examine all the 4 combinations
    //
    {
        auto tmp = create_indexInterval_lb_ub(Static_Integer<5>, Static_Integer<5>);
        EXPECT_TRUE(decltype(tmp)::is_static_lowerBound());
        EXPECT_TRUE(decltype(tmp)::is_static_size());
        EXPECT_TRUE(decltype(tmp)::is_static_upperBound());
    }

    {
        auto tmp = create_indexInterval_lb_ub(3, Static_Integer<5>);
        EXPECT_FALSE(decltype(tmp)::is_static_lowerBound());
        EXPECT_FALSE(decltype(tmp)::is_static_size());
        EXPECT_FALSE(decltype(tmp)::is_static_upperBound());
    }

    {
        auto tmp = create_indexInterval_lb_ub(3, 3);
        EXPECT_FALSE(decltype(tmp)::is_static_lowerBound());
        EXPECT_FALSE(decltype(tmp)::is_static_size());
        EXPECT_FALSE(decltype(tmp)::is_static_upperBound());
    }

    {
        auto tmp = create_indexInterval_lb_ub(Static_Integer<3>, 3);
        EXPECT_TRUE(decltype(tmp)::is_static_lowerBound());
        EXPECT_FALSE(decltype(tmp)::is_static_size());
        EXPECT_FALSE(decltype(tmp)::is_static_upperBound());
    }
    //! [[UpperBoundTypeDeduction]]
}
